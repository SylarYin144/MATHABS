#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import os
import io, base64
import textwrap
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk # Importar FigureCanvasTkAgg
from matplotlib.ticker import LogFormatterSciNotation, LogFormatterExponent, ScalarFormatter # Para formato de ejes log
from matplotlib.lines import Line2D # Para leyendas personalizadas
import warnings
import scipy.stats as stats
from scipy.optimize import curve_fit, fsolve
import statsmodels.api as sm
from statsmodels.nonparametric.smoothers_lowess import lowess

# -------------------------------
# IMPORTS PARA FLASK (versión web)
# -------------------------------
from flask import Flask, request, render_template_string, redirect, url_for, session, flash
from werkzeug.utils import secure_filename

# -------------------------------
# IMPORTS PARA TKINTER (versión desktop)
# -------------------------------
import tkinter as tk
from tkinter import ttk, filedialog, scrolledtext, messagebox # Añadir messagebox
import shutil
import traceback # Añadido para logging
from patsy import dmatrix

# Importar el componente de filtro
try:
    from MATLAB_filter_component import FilterComponent
except ImportError:
    messagebox.showerror("Error de Importación", "No se pudo importar FilterComponent.")
    FilterComponent = None

# ==============================
# Código de la aplicación WEB (Flask)
# ==============================
def run_flask_app():
    app = Flask(__name__)
    app.secret_key = 'tu_clave_secreta'  # Cambia esto por una clave segura

    # Configuración de carpeta de subida
    UPLOAD_FOLDER = 'uploads'
    if not os.path.exists(UPLOAD_FOLDER):
        os.makedirs(UPLOAD_FOLDER)
    app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

    @app.route('/', methods=['GET', 'POST'])
    def upload_file():
        if request.method == 'POST':
            if 'excel_file' not in request.files:
                flash("No se encontró el archivo")
                return redirect(request.url)
            file = request.files['excel_file']
            if file.filename == '':
                flash("No se seleccionó ningún archivo")
                return redirect(request.url)
            if file:
                filename = secure_filename(file.filename)
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(filepath)
                session['filepath'] = filepath
                return redirect(url_for('configure'))
        return render_template_string('''
        <!doctype html>
        <html>
          <head>
            <title>Cargar Archivo Excel</title>
          </head>
          <body>
            <h1>Cargar Archivo Excel</h1>
            <form method="post" enctype="multipart/form-data">
              <input type="file" name="excel_file">
              <input type="submit" value="Subir">
            </form>
          </body>
        </html>
        ''')

    @app.route('/configure', methods=['GET'])
    def configure():
        filepath = session.get('filepath', None)
        if not filepath or not os.path.exists(filepath):
            return redirect(url_for('upload_file'))
        try:
            df = pd.read_excel(filepath)
        except Exception as e:
            return "Error al leer el archivo: " + str(e)
        summary_text = summarize_data(df)
        columns = list(df.columns)
        return render_template_string('''
        <!doctype html>
        <html>
          <head>
            <title>Configuración de Filtros</title>
            <style>
              .container { display: flex; }
              .left { flex: 1; padding: 10px; }
              .right { flex: 2; padding: 10px; border-left: 1px solid #ccc; }
            </style>
          </head>
          <body>
            <h1>Resumen del Archivo Subido</h1>
            <pre>{{ summary_text }}</pre>
            <hr>
            <h2>Configura los Filtros y Parámetros de Gráfica</h2>
            <form method="post" action="{{ url_for('process') }}">
              <label>Variable de Caso:</label>
              <select name="var">
                {% for col in columns %}
                  <option value="{{ col }}">{{ col }}</option>
                {% endfor %}
              </select><br><br>
              
              <label>Filtro (coma para múltiples o guion para rango):</label>
              <input type="text" name="filter"><br><br>
              
              <label>Tipo de Variable:</label>
              <select name="tipo">
                <option value="Cuantitativa">Cuantitativa</option>
                <option value="Cualitativa">Cualitativa</option>
              </select><br><br>
              
              <label>Etiquetas Personalizadas:</label>
              <input type="text" name="etiquetas" placeholder="Ej: 1:Bajo,2:Medio,3:Alto"><br>
              <small>(Formato: valor:etiqueta, separados por coma)</small><br><br>
              
              <label>Excluir casillas en blanco en estadísticas:</label>
              <input type="checkbox" name="exclude_blank"><br><br>
              
              <h3>Filtros Adicionales (Opcionales)</h3>
              <label>Variable 2:</label>
              <select name="var2">
                <option value="">--Ninguno--</option>
                {% for col in columns %}
                  <option value="{{ col }}">{{ col }}</option>
                {% endfor %}
              </select>
              <label>Filtro 2:</label>
              <input type="text" name="filter2"><br><br>
              
              <label>Variable 3:</label>
              <select name="var3">
                <option value="">--Ninguno--</option>
                {% for col in columns %}
                  <option value="{{ col }}">{{ col }}</option>
                {% endfor %}
              </select>
              <label>Filtro 3:</label>
              <input type="text" name="filter3"><br><br>
              
              <label>Variable 4:</label>
              <select name="var4">
                <option value="">--Ninguno--</option>
                {% for col in columns %}
                  <option value="{{ col }}">{{ col }}</option>
                {% endfor %}
              </select>
              <label>Filtro 4:</label>
              <input type="text" name="filter4"><br><br>
              
              <h3>Parámetros de Gráfica</h3>
              <label>DPI:</label>
              <input type="text" name="dpi" value="100"><br><br>
              <label>Ancho (px):</label>
              <input type="text" name="width" value="1000"><br><br>
              <label>Alto (px):</label>
              <input type="text" name="height" value="600"><br><br>
              <label>Color gráfico:</label>
              <input type="text" name="color" value="skyblue"><br><br>
              <label>Color borde:</label>
              <input type="text" name="edge_color" value="black"><br><br>
              <label>Color mediana:</label>
              <input type="text" name="mediana_color" value="red"><br><br>

              <label>Número de barras (histograma):</label>
              <input type="number" name="hist_bins" value="20" min="1"><br><br>

              <!-- CONTROLES ADICIONALES DE ESTILO -->
              <label>Título Gráfica:</label>
              <input type="text" name="title" placeholder="Mi título"><br><br>
              <label>Tamaño Título:</label>
              <input type="text" name="title_size" value="14"><br><br>
              <label>Color Título:</label>
              <input type="text" name="title_color" value="black"><br><br>
              
              <label>Etiqueta Eje X:</label>
              <input type="text" name="xlabel" placeholder="Eje X"><br><br>
              <label>Tamaño X:</label>
              <input type="text" name="xlabel_size" value="10"><br><br>
              <label>Color X:</label>
              <input type="text" name="xlabel_color" value="black"><br><br>

              <label>Etiqueta Eje Y:</label>
              <input type="text" name="ylabel" placeholder="Eje Y"><br><br>
              <label>Tamaño Y:</label>
              <input type="text" name="ylabel_size" value="10"><br><br>
              <label>Color Y:</label>
              <input type="text" name="ylabel_color" value="black"><br><br>
              
              <label>X limits (min,max):</label>
              <input type="text" name="xlim" placeholder="0,100"><br><br>
              <label>Y limits (min,max):</label>
              <input type="text" name="ylim" placeholder="0,1"><br><br>
              <label>X ticks (coma sep):</label>
              <input type="text" name="xticks" placeholder="0,20,40"><br><br>
              <label>Y ticks (coma sep):</label>
              <input type="text" name="yticks" placeholder="0,0.5,1"><br><br>

              <label>Mostrar cuadrícula:</label>
              <input type="checkbox" name="grid" checked><br><br>
              <label>Mostrar info N y filtros:</label>
              <input type="checkbox" name="show_info" checked><br><br>
              
              <label>Anotar Pearson/Spearman global:</label>
              <input type="checkbox" name="plot_corr"><br><br>
              
              <input type="submit" value="Aplicar Filtros/Estadísticas">
            </form>
            <br>
            <a href="{{ url_for('upload_file') }}">Cargar otro archivo</a>
          </body>
        </html>
        ''', summary_text=summary_text, columns=columns)

    def summarize_data(df):
        summary_lines = []
        n_vars = df.shape[1]
        n_rows = df.shape[0]
        summary_lines.append("Resumen del archivo subido:")
        summary_lines.append(f"  Número de variables (columnas): {n_vars}")
        summary_lines.append(f"  Número de registros (filas): {n_rows}")
        summary_lines.append("")
        for col in df.columns:
            series = df[col]
            valid_count = series.count()
            summary_lines.append(f"Variable: {col}")
            summary_lines.append(f"  Tipo: {series.dtype}")
            summary_lines.append(f"  Valores válidos: {valid_count}")
            if pd.api.types.is_numeric_dtype(series):
                try:
                    mean_val = series.mean()
                    mode_val = series.mode().iloc[0] if not series.mode().empty else "N/A"
                    summary_lines.append(f"  Promedio: {mean_val:.2f}")
                    summary_lines.append(f"  Moda: {mode_val}")
                except Exception:
                    summary_lines.append("  Error al calcular estadísticas numéricas.")
            else:
                freq = series.value_counts(dropna=True)
                summary_lines.append("  Frecuencia de etiquetas (top 10):")
                for label, count in freq.head(10).items():
                    perc = (count / valid_count * 100) if valid_count > 0 else 0
                    summary_lines.append(f"    {label}: {count} ({perc:.2f}%)")
            summary_lines.append("")
        return "\n".join(summary_lines)

    @app.route('/process', methods=['POST'])
    def process():
        filepath = session.get('filepath', None)
        if not filepath or not os.path.exists(filepath):
            return redirect(url_for('upload_file'))
        try:
            df = pd.read_excel(filepath)
        except Exception as e:
            return "Error al leer el archivo: " + str(e)

        # Lectura de formularios
        var = request.form.get("var")
        filtro = request.form.get("filter", "").strip()
        tipo = request.form.get("tipo")
        etiquetas = request.form.get("etiquetas", "").strip()
        exclude_blank = True if request.form.get("exclude_blank") == "on" else False

        var2 = request.form.get("var2", "").strip()
        filter2 = request.form.get("filter2", "").strip()
        var3 = request.form.get("var3", "").strip()
        filter3 = request.form.get("filter3", "").strip()
        var4 = request.form.get("var4", "").strip()
        filter4 = request.form.get("filter4", "").strip()

        try:
            dpi = int(request.form.get("dpi", "100"))
            width = int(request.form.get("width", "1000"))
            height = int(request.form.get("height", "600"))
        except Exception as e:
            return "Error en los parámetros de gráfica: " + str(e)

        color = request.form.get("color", "skyblue")
        edge_color = request.form.get("edge_color", "black")
        mediana_color = request.form.get("mediana_color", "red")

        hist_bins_raw = request.form.get("hist_bins", "").strip()
        try:
            hist_bins = int(hist_bins_raw) if hist_bins_raw else 20
        except (TypeError, ValueError):
            hist_bins = 20
        if hist_bins < 1:
            hist_bins = 1

        # Nuevos controles de estilo
        title = request.form.get("title", "")
        title_size = int(request.form.get("title_size", "14"))
        title_color = request.form.get("title_color", "black")

        xlabel = request.form.get("xlabel", "")
        xlabel_size = int(request.form.get("xlabel_size", "10"))
        xlabel_color = request.form.get("xlabel_color", "black")

        ylabel = request.form.get("ylabel", "")
        ylabel_size = int(request.form.get("ylabel_size", "10"))
        ylabel_color = request.form.get("ylabel_color", "black")

        xlim_raw = request.form.get("xlim", "").strip()
        ylim_raw = request.form.get("ylim", "").strip()
        xticks_raw = request.form.get("xticks", "").strip()
        yticks_raw = request.form.get("yticks", "").strip()

        grid_on = True if request.form.get("grid") == "on" else False
        show_info = True if request.form.get("show_info") == "on" else False
        plot_corr = True if request.form.get("plot_corr") == "on" else False

        def resolve_plot_text(user_value, default_value):
            if user_value is None:
                return default_value
            if user_value == "":
                return default_value
            stripped = user_value.strip()
            if stripped == "":
                return ""
            return stripped

        # Función de filtrado idéntica a la de escritorio
        def apply_filter_criteria(df, var, filtro):
            if not filtro:
                return df
            if "-" in filtro:
                parts = filtro.split("-")
                if len(parts) == 2:
                    try:
                        lower = float(parts[0].strip())
                        upper = float(parts[1].strip())
                        return df[(df[var] >= lower) & (df[var] <= upper)]
                    except Exception:
                        return df
                else:
                    return df
            elif "," in filtro:
                parts = [p.strip() for p in filtro.split(",")]
                vals = []
                for p in parts:
                    try:
                        vals.append(float(p))
                    except:
                        vals.append(p)
                return df[df[var].isin(vals)]
            else:
                try:
                    val = float(filtro)
                except:
                    val = filtro
                return df[df[var] == val]

        # Aplicar filtros
        df_filtered = df.copy()
        df_filtered = apply_filter_criteria(df_filtered, var, filtro)
        if var2 and filter2:
            df_filtered = apply_filter_criteria(df_filtered, var2, filter2)
        if var3 and filter3:
            df_filtered = apply_filter_criteria(df_filtered, var3, filter3)
        if var4 and filter4:
            df_filtered = apply_filter_criteria(df_filtered, var4, filter4)

        # Conteo de observaciones
        n_obs = df_filtered[var].count() if exclude_blank else len(df_filtered[var])

        result_text = ""
        graph_img = None

        # Estadísticas y gráfico
        if tipo == "Cuantitativa":
            resumen = df_filtered[var].describe().to_string()
            mediana = df_filtered[var].median()
            freq_series = df_filtered[var].value_counts(dropna=exclude_blank)
            freq_df = pd.DataFrame({
                'Count': freq_series,
                'Percentage': (freq_series / n_obs * 100).round(2)
            })
            if not exclude_blank:
                n_blank = len(df_filtered[var]) - df_filtered[var].count()
                result_text = (f"Resumen de {var}:\n{resumen}\n\nMediana: {mediana}\n\n"
                               f"Frecuencia de valores:\n{freq_df.to_string()}\n\n"
                               f"Casillas en blanco: {n_blank}")
            else:
                result_text = f"Resumen de {var}:\n{resumen}\n\nMediana: {mediana}\n\nFrecuencia de valores:\n{freq_df.to_string()}"

            # Generar histograma
            plt.figure(figsize=(width/dpi, height/dpi), dpi=dpi)
            plt.hist(df_filtered[var].dropna(), bins=hist_bins, color=color, edgecolor=edge_color)
            resolved_title = resolve_plot_text(title, f"Histograma de {var}")
            plt.title(resolved_title, fontsize=title_size, color=title_color)
            resolved_xlabel = resolve_plot_text(xlabel, var)
            plt.xlabel(resolved_xlabel, fontsize=xlabel_size, color=xlabel_color)
            resolved_ylabel = resolve_plot_text(ylabel, "Frecuencia")
            plt.ylabel(resolved_ylabel, fontsize=ylabel_size, color=ylabel_color)
            plt.axvline(mediana, color=mediana_color, linestyle="dashed", linewidth=2, label=f"Mediana: {mediana}")
            plt.legend()

            # Límites y ticks
            if xlim_raw:
                try:
                    lo, hi = [float(v) for v in xlim_raw.split(",")]
                    plt.xlim(lo, hi)
                except:
                    pass
            if ylim_raw:
                try:
                    lo, hi = [float(v) for v in ylim_raw.split(",")]
                    plt.ylim(lo, hi)
                except:
                    pass
            if xticks_raw:
                try:
                    ticks = [float(v) for v in xticks_raw.split(",")]
                    plt.xticks(ticks)
                except:
                    pass
            if yticks_raw:
                try:
                    ticks = [float(v) for v in yticks_raw.split(",")]
                    plt.yticks(ticks)
                except:
                    pass

            # Cuadrícula
            plt.grid(grid_on)

            # Anotaciones de Pearson/Spearman global
            if plot_corr and n_obs > 1:
                try:
                    r_p, _ = stats.pearsonr(df_filtered[var].dropna(), df_filtered[var].dropna())
                    r_s, _ = stats.spearmanr(df_filtered[var].dropna(), df_filtered[var].dropna())
                    plt.annotate(f"Pearson: {r_p:.3f}\nSpearman: {r_s:.3f}",
                                 xy=(0.05, 0.05), xycoords="axes fraction",
                                 fontsize=10, ha="left", va="bottom",
                                 bbox=dict(boxstyle="round", facecolor="white", alpha=0.5))
                except:
                    pass

            # Mostrar info de n y filtros
            if show_info:
                info_text = f"n = {n_obs}\nFiltros: {var}={filtro}"
                if var2 and filter2: info_text += f", {var2}={filter2}"
                if var3 and filter3: info_text += f", {var3}={filter3}"
                if var4 and filter4: info_text += f", {var4}={filter4}"
                plt.annotate(info_text, xy=(0.95, 0.95), xycoords="axes fraction",
                             fontsize=8, ha="right", va="top",
                             bbox=dict(boxstyle="round", facecolor="white", alpha=0.5))

            plt.tight_layout()
            buf = io.BytesIO()
            plt.savefig(buf, format='png')
            buf.seek(0)
            graph_img = base64.b64encode(buf.getvalue()).decode('utf-8')
            plt.close()

        elif tipo == "Cualitativa":
            freq_series = df_filtered[var].value_counts(dropna=exclude_blank)
            if not exclude_blank:
                freq_series.index = [("nan" if pd.isna(x) else x) for x in freq_series.index]
            freq_df = pd.DataFrame({
                'Count': freq_series,
                'Percentage': (freq_series / n_obs * 100).round(2)
            })
            if etiquetas:
                mapping = {}
                for pair in etiquetas.split(","):
                    if ":" in pair:
                        original, label = pair.split(":", 1)
                        mapping[original.strip()] = label.strip()
                new_index = [mapping.get(str(val), str(val)) for val in freq_df.index]
                freq_df.index = new_index
            resumen = df_filtered[var].describe().to_string()
            if not exclude_blank:
                n_blank = len(df_filtered[var]) - df_filtered[var].count()
                result_text = (f"Resumen de {var}:\n{resumen}\n\n"
                               f"Frecuencia de valores:\n{freq_df.to_string()}\n\n"
                               f"Casillas en blanco: {n_blank}")
            else:
                result_text = f"Resumen de {var}:\n{resumen}\n\nFrecuencia de valores:\n{freq_df.to_string()}"

            # Gráfico de barras
            plt.figure(figsize=(width/dpi, height/dpi), dpi=dpi)
            plt.bar(freq_df.index, freq_df['Count'].values, color=color, edgecolor=edge_color)
            resolved_bar_title = resolve_plot_text(title, f"Gráfico de barras de frecuencias para {var}")
            plt.title(resolved_bar_title, fontsize=title_size, color=title_color)
            resolved_bar_xlabel = resolve_plot_text(xlabel, var)
            plt.xlabel(resolved_bar_xlabel, fontsize=xlabel_size, color=xlabel_color)
            resolved_bar_ylabel = resolve_plot_text(ylabel, "Frecuencia")
            plt.ylabel(resolved_bar_ylabel, fontsize=ylabel_size, color=ylabel_color)
            plt.xticks(rotation=45, ha="right")

            # Límites y ticks
            if ylim_raw:
                try:
                    lo, hi = [float(v) for v in ylim_raw.split(",")]
                    plt.ylim(lo, hi)
                except:
                    pass
            if yticks_raw:
                try:
                    ticks = [float(v) for v in yticks_raw.split(",")]
                    plt.yticks(ticks)
                except:
                    pass

            # Cuadrícula
            plt.grid(grid_on)

            # Pearson/Spearman global
            if plot_corr and n_obs > 1:
                try:
                    # Para cualitativa no tiene sentido global, omitido
                    pass
                except:
                    pass

            # Info de n y filtros
            if show_info:
                info_text = f"n = {n_obs}\nFiltros: {var}={filtro}"
                if var2 and filter2: info_text += f", {var2}={filter2}"
                if var3 and filter3: info_text += f", {var3}={filter3}"
                if var4 and filter4: info_text += f", {var4}={filter4}"
                plt.annotate(info_text, xy=(0.95, 0.95), xycoords="axes fraction",
                             fontsize=8, ha="right", va="top",
                             bbox=dict(boxstyle="round", facecolor="white", alpha=0.5))

            plt.tight_layout()
            buf = io.BytesIO()
            plt.savefig(buf, format='png')
            buf.seek(0)
            graph_img = base64.b64encode(buf.getvalue()).decode('utf-8')
            plt.close()

        return render_template_string('''
        <!doctype html>
        <html>
          <head>
            <title>Resultados</title>
            <style>
              .container { display: flex; }
              .left { flex: 1; padding: 10px; }
              .right { flex: 1; padding: 10px; }
            </style>
          </head>
          <body>
            <h1>Resultados de Filtros/Estadísticas</h1>
            <div class="container">
              <div class="left">
                <h2>Resumen</h2>
                <pre>{{ result_text }}</pre>
              </div>
              <div class="right">
                <h2>Gráfica</h2>
                {% if graph_img %}
                  <img src="data:image/png;base64,{{ graph_img }}" alt="Graph">
                {% else %}
                  <p>No se generó gráfica.</p>
                {% endif %}
              </div>
            </div>
            <br>
            <a href="{{ url_for('configure') }}">Volver a Configuración</a> | 
            <a href="{{ url_for('upload_file') }}">Cargar otro archivo</a>
          </body>
        </html>
        ''', result_text=result_text, graph_img=graph_img)

    app.run(debug=True)


# ==============================
# Código de la aplicación de ESCRITORIO (Tkinter – RegresionesTab)
# ==============================
def fmt_p(p):
    try:
        return f"{p:.3e}" if not np.isnan(p) else "0.000e+00"
    except Exception:
        return "N/A"

def safe_pearson(y, y_pred):
    if len(y) < 2 or len(y_pred) < 2 or np.std(y) < 1e-8 or np.std(y_pred) < 1e-8: #Añadido chequeo de longitud
        return np.nan, np.nan
    return stats.pearsonr(y, y_pred)

def safe_spearman(y, y_pred):
    if len(y) < 2 or len(y_pred) < 2 or np.std(y) < 1e-8 or np.std(y_pred) < 1e-8: #Añadido chequeo de longitud
        return np.nan, np.nan
    return stats.spearmanr(y, y_pred)

def exp_model1(x, a, b):
    return a + np.power(b, x)

def exp_model2(x, a, b):
    return a + np.power(x, b)

def exp_model3(x, A, B):
    return A * np.power(B, x)

def exp_decay(x, A, B):
    return A * np.exp(-B * x)

def sigmoid(x, L, k, x0, off):
    return L / (1 + np.exp(-k*(x - x0))) + off

def find_x0(model_func, params, x_guess):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        try:
            sol = fsolve(lambda x: model_func(x, *params), x_guess, maxfev=10000)
            return sol[0]
        except Exception:
            return None

def compute_acme(func, x_range):
    y_vals = func(x_range)
    idx = np.argmax(y_vals) if (np.max(y_vals) - np.min(y_vals)) >= 0 else np.argmin(y_vals)
    return x_range[idx], y_vals[idx]

class ScrollableFrame(ttk.Frame):
    def __init__(self, container, *args, **kwargs):
        super().__init__(container, *args, **kwargs)
        self.canvas = tk.Canvas(self)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.v_scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.v_scrollbar.grid(row=0, column=1, sticky="ns")
        self.h_scrollbar = ttk.Scrollbar(self, orient="horizontal", command=self.canvas.xview)
        self.h_scrollbar.grid(row=1, column=0, sticky="ew")
        self.canvas.configure(yscrollcommand=self.v_scrollbar.set, xscrollcommand=self.h_scrollbar.set)
        self.scrollable_frame = ttk.Frame(self.canvas)
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.scrollable_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)

class RegresionesTab(ttk.Frame):
    def __init__(self, master, main_app_instance=None):
        super().__init__(master)
        self.main_app = main_app_instance
        super().__init__(master)
        self.data = None # DataFrame original cargado
        self.filtered_data = None # DataFrame después de aplicar filtros
        self.graph_path = "temp_graph.png" # Considerar un subdirectorio temporal
        self.results_text_content = "" # Para almacenar el texto de resultados
        self.plot_label_map = {} # Para mapear nombres de variables a etiquetas de gráfico
        self.default_colors = ["#0072B2", "#D55E00", "#009E73", "#F0E442", "#56B4E9", "#CC79A7", "#999999", "#E69F00"]
        self.color_options = ["blue", "green", "red", "skyblue", "orange", "purple",
                               "black", "gray", "brown", "pink", "cyan", "magenta",
                               "teal", "olive", "navy", "maroon", "lime", "gold"]

        self.model_styles = {
            "Lineal": {"linestyle": "-", "marker": "o"},
            "Cuadrático": {"linestyle": "--", "marker": "s"},
            "Cúbico": {"linestyle": ":", "marker": "d"},
            "Potencia": {"linestyle": "-.", "marker": "^"},
            "Logarítmico": {"linestyle": (0, (3, 1, 1, 1)), "marker": "v"},
            "LOESS": {"linestyle": (0, (5, 5)), "marker": "x"},
            "Exp (a+b^x)": {"linestyle": (0, (1, 1)), "marker": "p"},
            "Exp (a+x^b)": {"linestyle": (0, (3, 5, 1, 5)), "marker": "h"},
            "Exp (A*B^x)": {"linestyle": (0, (5, 2, 1, 2)), "marker": "*"},
            "Sigmoide": {"linestyle": (0, (1, 10)), "marker": "+"},
            "Exp Decreciente": {"linestyle": (0, (2, 2)), "marker": "D"},
        }

        self.paned = ttk.PanedWindow(self, orient=tk.HORIZONTAL)
        self.paned.pack(fill="both", expand=True)
        
        # Frame izquierdo con scroll
        left_scroll_container = ScrollableFrame(self.paned)
        self.paned.add(left_scroll_container, weight=1)
        container = left_scroll_container.scrollable_frame # Este es el frame donde van los widgets

        # Frame derecho para resultados
        right_frame = ttk.Frame(self.paned)
        self.paned.add(right_frame, weight=1)

        # Notebook en el panel derecho para resultados y gráfica
        self.results_notebook = ttk.Notebook(right_frame)
        self.results_notebook.pack(fill="both", expand=True, padx=10, pady=10)

        # Pestaña de Resumen
        frm_results = ttk.Frame(self.results_notebook)
        self.results_notebook.add(frm_results, text="Resumen de Resultados")
        self.txt_results = scrolledtext.ScrolledText(frm_results, wrap="none", height=15)
        self.txt_results.pack(fill="both", expand=True)
        self.txt_results.config(state="disabled")

        # Pestaña de Gráfica
        self.graph_frame = ttk.Frame(self.results_notebook)
        self.results_notebook.add(self.graph_frame, text="Gráfica")

        # Canvas para la gráfica
        self.fig = plt.figure(figsize=(5, 4), dpi=100)
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.graph_frame)
        self.canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        # Toolbar para la gráfica
        self.toolbar = NavigationToolbar2Tk(self.canvas, self.graph_frame)
        self.toolbar.update()
        self.canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        # --- Contenido del frame izquierdo (container) ---
        frm_top = ttk.Frame(container)
        frm_top.pack(fill="x", padx=10, pady=5)
        lbl_title = ttk.Label(frm_top, text="Análisis de Regresiones y Dispersión", font=("Helvetica", 14))
        lbl_title.pack(side="left")
        self.msg_label = ttk.Label(frm_top, text="", foreground="blue", wraplength=300)
        self.msg_label.pack(side="right", anchor="ne", padx=10)

        btn_load = ttk.Button(container, text="Cargar Datos (Excel)", command=self.load_data)
        btn_load.pack(pady=5, padx=10, fill="x")
        self.lbl_file = ttk.Label(container, text="Ningún archivo cargado.")
        self.lbl_file.pack(pady=5, padx=10, anchor="w")

        # --- Filtros (Nuevo Componente) ---
        frm_filters_outer = ttk.LabelFrame(container, text="Filtros de Datos (Opcional)")
        frm_filters_outer.pack(fill="x", padx=10, pady=5)
        if FilterComponent:
            self.filter_component = FilterComponent(frm_filters_outer, max_unique_cat=50, log_callback=self.log_message)
            self.filter_component.pack(fill="both", expand=True) # Usar fill="both" y expand=True
        else:
            ttk.Label(frm_filters_outer, text="Error: Componente de filtro no cargado.").pack()
        
        frm_filters_outer.columnconfigure(0, weight=1) # Asegurar que el frame de filtros se expanda
        frm_filters_outer.rowconfigure(0, weight=1) # Asegurar que el frame de filtros se expanda


        # --- Selección de Variables para Regresión ---
        frm_vars = ttk.LabelFrame(container, text="Selección de Variables")
        frm_vars.pack(fill="x", padx=10, pady=5)
        
        dep_var_frame = ttk.Frame(frm_vars)
        dep_var_frame.pack(fill="x", pady=2)
        ttk.Label(dep_var_frame, text="Variables Dependientes (selección múltiple):").pack(anchor="nw", padx=5)
        self.listbox_dep_vars_spec = tk.Listbox(dep_var_frame, selectmode=tk.MULTIPLE, height=4, exportselection=False)
        dep_vars_v_scrollbar = ttk.Scrollbar(dep_var_frame, orient="vertical", command=self.listbox_dep_vars_spec.yview)
        self.listbox_dep_vars_spec.configure(yscrollcommand=dep_vars_v_scrollbar.set)
        dep_vars_v_scrollbar.pack(side="right", fill="y")
        self.listbox_dep_vars_spec.pack(side="left", fill="both", expand=True, padx=5, pady=(0,5))
        self.listbox_dep_vars_spec.bind('<<ListboxSelect>>', self._update_indep_vars_listbox)

        indep_vars_frame = ttk.Frame(frm_vars)
        indep_vars_frame.pack(fill="both", expand=True, pady=2)
        # Store original label text for reuse
        indep_vars_label_text = "Variables Independientes (seleccione de la lista):"
        ttk.Label(indep_vars_frame, text=indep_vars_label_text).pack(anchor="nw", padx=5)

        self.listbox_indep_vars_spec = tk.Listbox(indep_vars_frame, selectmode=tk.MULTIPLE, height=6, exportselection=False)
        indep_vars_v_scrollbar = ttk.Scrollbar(indep_vars_frame, orient="vertical", command=self.listbox_indep_vars_spec.yview)
        indep_vars_h_scrollbar = ttk.Scrollbar(indep_vars_frame, orient="horizontal", command=self.listbox_indep_vars_spec.xview)
        self.listbox_indep_vars_spec.configure(yscrollcommand=indep_vars_v_scrollbar.set, xscrollcommand=indep_vars_h_scrollbar.set)

        indep_vars_v_scrollbar.pack(side="right", fill="y")
        indep_vars_h_scrollbar.pack(side="bottom", fill="x")
        self.listbox_indep_vars_spec.pack(side="left", fill="both", expand=True, padx=5, pady=(0,5))
        
        rename_vars_frame = ttk.Frame(frm_vars)
        rename_vars_frame.pack(fill="x", pady=5)
        ttk.Label(rename_vars_frame, text="Renombrar variable (opcional):").pack(side="left", padx=5)
        self.rename_var_entry = ttk.Entry(rename_vars_frame, width=20)
        self.rename_var_entry.pack(side="left", padx=5)
        ttk.Button(rename_vars_frame, text="Renombrar", command=self.rename_variable).pack(side="left", padx=5)

        # --- Parámetros Gráficos ---
        frm_params = ttk.LabelFrame(container, text="Parámetros Gráficos")
        frm_params.pack(fill="x", padx=10, pady=5)
        param_grid_frame = ttk.Frame(frm_params) 
        param_grid_frame.pack(fill="x", expand=True)

        ttk.Label(param_grid_frame, text="DPI:").grid(row=0, column=0, padx=5, pady=2, sticky="w")
        self.entry_dpi = ttk.Entry(param_grid_frame, width=7)
        self.entry_dpi.grid(row=0, column=1, padx=5, pady=2, sticky="w")
        self.entry_dpi.insert(0, "100")
        ttk.Label(param_grid_frame, text="Ancho (px):").grid(row=0, column=2, padx=5, pady=2, sticky="w")
        self.entry_width = ttk.Entry(param_grid_frame, width=7)
        self.entry_width.grid(row=0, column=3, padx=5, pady=2, sticky="w")
        self.entry_width.insert(0, "800")
        ttk.Label(param_grid_frame, text="Alto (px):").grid(row=0, column=4, padx=5, pady=2, sticky="w")
        self.entry_height = ttk.Entry(param_grid_frame, width=7)
        self.entry_height.grid(row=0, column=5, padx=5, pady=2, sticky="w")
        self.entry_height.insert(0, "600")

        ttk.Label(param_grid_frame, text="Color Puntos:").grid(row=1, column=0, padx=5, pady=2, sticky="w")
        self.cmb_pt_color = ttk.Combobox(param_grid_frame, values=self.color_options, state="readonly", width=10)
        self.cmb_pt_color.grid(row=1, column=1, padx=5, pady=2, sticky="w")
        self.cmb_pt_color.set("blue")

        ttk.Label(param_grid_frame, text="Tamaño Puntos:").grid(row=1, column=2, padx=5, pady=2, sticky="w")
        self.entry_pt_size = ttk.Entry(param_grid_frame, width=7)
        self.entry_pt_size.grid(row=1, column=3, padx=5, pady=2, sticky="w")
        self.entry_pt_size.insert(0, "20") # Valor por defecto para el tamaño de puntos

        ttk.Label(param_grid_frame, text="Tamaño Texto Ejes:").grid(row=1, column=4, padx=5, pady=2, sticky="w")
        self.entry_text_size = ttk.Entry(param_grid_frame, width=7)
        self.entry_text_size.grid(row=1, column=5, padx=5, pady=2, sticky="w")
        self.entry_text_size.insert(0, "10")

        ttk.Label(param_grid_frame, text="Título Gráfica:").grid(row=2, column=0, sticky="w", padx=5, pady=2)
        self.entry_title = ttk.Entry(param_grid_frame, width=20)
        self.entry_title.grid(row=2, column=1, columnspan=2, sticky="we", padx=5)
        ttk.Label(param_grid_frame, text="Tamaño Título:").grid(row=2, column=3, sticky="w", padx=5) 
        self.entry_title_size = ttk.Entry(param_grid_frame, width=5)
        self.entry_title_size.insert(0, "14")
        self.entry_title_size.grid(row=2, column=4, sticky="w", padx=5)

        ttk.Label(param_grid_frame, text="Fuente:").grid(row=8, column=0, sticky="w", padx=5, pady=2)
        self.font_family_var = tk.StringVar(value="sans-serif")
        font_families = ["serif", "sans-serif", "monospace", "Arial", "Times New Roman", "Courier New", "Palatino Linotype"]
        self.font_family_combo = ttk.Combobox(param_grid_frame, textvariable=self.font_family_var, values=font_families, state="readonly", width=15)
        self.font_family_combo.grid(row=8, column=1, columnspan=2, sticky="we", padx=5)

        ttk.Label(param_grid_frame, text="Etiqueta Eje X:").grid(row=3, column=0, sticky="w", padx=5, pady=2)
        self.entry_xlabel = ttk.Entry(param_grid_frame, width=20)
        self.entry_xlabel.grid(row=3, column=1, columnspan=2, sticky="we", padx=5)
        ttk.Label(param_grid_frame, text="Etiqueta Eje Y:").grid(row=4, column=0, sticky="w", padx=5, pady=2)
        self.entry_ylabel = ttk.Entry(param_grid_frame, width=20)
        self.entry_ylabel.grid(row=4, column=1, columnspan=2, sticky="we", padx=5)

        ttk.Label(param_grid_frame, text="X lim (min,max):").grid(row=5, column=0, sticky="w", padx=5, pady=2)
        self.entry_xlim = ttk.Entry(param_grid_frame, width=10)
        self.entry_xlim.grid(row=5, column=1, sticky="w", padx=5)
        ttk.Label(param_grid_frame, text="Y lim (min,max):").grid(row=5, column=2, sticky="w", padx=5)
        self.entry_ylim = ttk.Entry(param_grid_frame, width=10)
        self.entry_ylim.grid(row=5, column=3, sticky="w", padx=5)
        ttk.Label(param_grid_frame, text="X ticks (a,b,c):").grid(row=6, column=0, sticky="w", padx=5, pady=2)
        self.entry_xticks = ttk.Entry(param_grid_frame, width=10)
        self.entry_xticks.grid(row=6, column=1, sticky="w", padx=5)
        ttk.Label(param_grid_frame, text="Y ticks (a,b,c):").grid(row=6, column=2, sticky="w", padx=5)
        self.entry_yticks = ttk.Entry(param_grid_frame, width=10)
        self.entry_yticks.grid(row=6, column=3, sticky="w", padx=5)

        self.var_grid = tk.BooleanVar(value=True)
        ttk.Checkbutton(param_grid_frame, text="Cuadrícula", variable=self.var_grid).grid(row=7, column=0, sticky="w", padx=5, pady=2)
        self.var_show_info = tk.BooleanVar(value=True)
        ttk.Checkbutton(param_grid_frame, text="Info N/Filtros", variable=self.var_show_info).grid(row=7, column=1, sticky="w", padx=5)
        self.var_plot_corr = tk.BooleanVar(value=False)
        ttk.Checkbutton(param_grid_frame, text="Anotar Correl.", variable=self.var_plot_corr).grid(row=7, column=2, sticky="w", padx=5)

        self.var_hide_points_labels = tk.BooleanVar(value=False)
        ttk.Checkbutton(param_grid_frame, text="Ocultar etiquetas de puntos", variable=self.var_hide_points_labels).grid(row=7, column=3, sticky="w", padx=5)

        ttk.Label(param_grid_frame, text="Decimales:").grid(row=9, column=0, sticky="w", padx=5, pady=2)
        self.decimals_var = tk.IntVar(value=2)
        ttk.Spinbox(param_grid_frame, from_=0, to=10, textvariable=self.decimals_var, width=5).grid(row=9, column=1, sticky="w", padx=5)

        self.sci_notation_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(param_grid_frame, text="Notación científica", variable=self.sci_notation_var).grid(row=9, column=2, sticky="w", padx=5)

        self.sci_notation_conditional_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(param_grid_frame, text="Notación científica (solo si aplica)", variable=self.sci_notation_conditional_var).grid(row=9, column=3, sticky="w", padx=5)

        self.var_table_only = tk.BooleanVar(value=False)
        ttk.Checkbutton(param_grid_frame, text="Mostrar solo tabla de correlaciones", variable=self.var_table_only).grid(row=10, column=0, columnspan=2, sticky="w", padx=5, pady=2)

        self.var_show_formula = tk.BooleanVar(value=True)
        ttk.Checkbutton(param_grid_frame, text="Mostrar fórmula", variable=self.var_show_formula).grid(row=10, column=2, sticky="w", padx=5)

        self.var_show_r2 = tk.BooleanVar(value=True)
        ttk.Checkbutton(param_grid_frame, text="Mostrar R²", variable=self.var_show_r2).grid(row=10, column=3, sticky="w", padx=5)

        # New: Custom Labels for Dependent Variable
        ttk.Label(param_grid_frame, text="Etiquetas Personalizadas (Var. Dep.):").grid(row=11, column=0, sticky="w", padx=5, pady=2)
        self.entry_dep_var_labels = ttk.Entry(param_grid_frame, width=30)
        self.entry_dep_var_labels.grid(row=11, column=1, columnspan=3, sticky="we", padx=5)
        ttk.Label(param_grid_frame, text="Ej: 1:Bajo,2:Medio").grid(row=11, column=4, columnspan=2, sticky="w", padx=5)


        # --- Modelos de Regresión ---
        frm_models = ttk.LabelFrame(container, text="Modelos de Regresión a Aplicar")
        frm_models.pack(fill="x", padx=10, pady=5)
        self.var_linear = tk.BooleanVar(value=False); ttk.Checkbutton(frm_models, text="Lineal", variable=self.var_linear).grid(row=0, column=0, padx=2, pady=2, sticky="w")
        self.var_quadratic = tk.BooleanVar(value=False); ttk.Checkbutton(frm_models, text="Cuadrática", variable=self.var_quadratic).grid(row=0, column=1, padx=2, pady=2, sticky="w")
        self.var_cubic = tk.BooleanVar(value=False); ttk.Checkbutton(frm_models, text="Cúbica", variable=self.var_cubic).grid(row=0, column=2, padx=2, pady=2, sticky="w")
        self.var_power = tk.BooleanVar(value=False); ttk.Checkbutton(frm_models, text="Potencia", variable=self.var_power).grid(row=0, column=3, padx=2, pady=2, sticky="w")
        self.var_log = tk.BooleanVar(value=False); ttk.Checkbutton(frm_models, text="Logarítmica", variable=self.var_log).grid(row=0, column=4, padx=2, pady=2, sticky="w")
        self.var_loess = tk.BooleanVar(value=False); ttk.Checkbutton(frm_models, text="LOESS", variable=self.var_loess).grid(row=0, column=5, padx=2, pady=2, sticky="w")
        self.var_inverse = tk.BooleanVar(value=False); ttk.Checkbutton(frm_models, text="Inversa (1/X)", variable=self.var_inverse).grid(row=1, column=0, padx=2, pady=2, sticky="w")
        self.var_rcs = tk.BooleanVar(value=False); ttk.Checkbutton(frm_models, text="Splines (RCS)", variable=self.var_rcs).grid(row=1, column=1, padx=2, pady=2, sticky="w")
        
        frm_otros = ttk.LabelFrame(container, text="Otros Modelos (Solo Resumen)")
        frm_otros.pack(fill="x", padx=10, pady=5)
        self.var_exp1 = tk.BooleanVar(value=False); ttk.Checkbutton(frm_otros, text="Exp (a+b^x)", variable=self.var_exp1).grid(row=0, column=0, padx=2, pady=2, sticky="w")
        self.var_exp2 = tk.BooleanVar(value=False); ttk.Checkbutton(frm_otros, text="Exp (a+x^b)", variable=self.var_exp2).grid(row=0, column=1, padx=2, pady=2, sticky="w")
        self.var_exp3 = tk.BooleanVar(value=False); ttk.Checkbutton(frm_otros, text="Exp (A*B^x)", variable=self.var_exp3).grid(row=0, column=2, padx=2, pady=2, sticky="w")
        self.var_sigmoid = tk.BooleanVar(value=False); ttk.Checkbutton(frm_otros, text="Sigmoide", variable=self.var_sigmoid).grid(row=0, column=3, padx=2, pady=2, sticky="w")
        self.var_exp_decay = tk.BooleanVar(value=False); ttk.Checkbutton(frm_otros, text="Exp Decreciente", variable=self.var_exp_decay).grid(row=0, column=4, padx=2, pady=2, sticky="w")

        frm_line_options = ttk.LabelFrame(container, text="Opciones de Línea de Regresión")
        frm_line_options.pack(fill="x", padx=10, pady=5)

        ttk.Label(frm_line_options, text="Color Líneas:").grid(row=0, column=0, padx=5, pady=2, sticky="w")
        self.cmb_line_color = ttk.Combobox(frm_line_options, values=self.color_options, state="readonly", width=10)
        self.cmb_line_color.grid(row=0, column=1, padx=5, pady=2, sticky="w")
        self.cmb_line_color.set("red")

        ttk.Label(frm_line_options, text="Grosor Líneas:").grid(row=0, column=2, padx=5, pady=2, sticky="w")
        self.entry_line_width = ttk.Entry(frm_line_options, width=7)
        self.entry_line_width.grid(row=0, column=3, padx=5, pady=2, sticky="w")
        self.entry_line_width.insert(0, "2")


        # --- Botones de Acción Finales ---
        frm_buttons_bottom = ttk.Frame(container)
        frm_buttons_bottom.pack(pady=10, fill="x", padx=10)
        btn_plot = ttk.Button(frm_buttons_bottom, text="Generar Dispersión y Regresión", command=self.plot_regression)
        btn_plot.pack(side="left", padx=5, expand=True, fill="x")
        btn_corr_table = ttk.Button(frm_buttons_bottom, text="Mostrar Tabla de Correlaciones", command=self.calculate_and_show_correlations)
        btn_corr_table.pack(side="left", padx=5, expand=True, fill="x")
        btn_save = ttk.Button(frm_buttons_bottom, text="Guardar Gráfica", command=self.save_graph_directly)
        btn_save.pack(side="left", padx=5, expand=True, fill="x")

        btn_edit_results = ttk.Button(frm_buttons_bottom, text="Editar y Formatear Resultados", command=self.open_results_editor)
        btn_edit_results.pack(side="left", padx=5, expand=True, fill="x")

    def _update_variable_selectors(self):
        """Actualiza todos los selectores de variables después de un cambio en las columnas del DataFrame."""
        if self.data is None:
            all_cols = []
            num_cols = []
        else:
            all_cols = list(self.data.columns)
            num_cols = list(self.data.select_dtypes(include=np.number).columns)

        # Guardar selecciones actuales de variables dependientes
        current_dep_indices = self.listbox_dep_vars_spec.curselection()
        current_dep_vars = {self.listbox_dep_vars_spec.get(i) for i in current_dep_indices}

        current_indep_indices = self.listbox_indep_vars_spec.curselection()
        current_indep_vars = {self.listbox_indep_vars_spec.get(i) for i in current_indep_indices}

        # Actualizar Listbox de variables dependientes
        self.listbox_dep_vars_spec.delete(0, tk.END)
        for idx, col in enumerate(num_cols):
            self.listbox_dep_vars_spec.insert(tk.END, col)
            if col in current_dep_vars:
                self.listbox_dep_vars_spec.selection_set(idx)
        
        # Actualizar Listbox de variables independientes
        self._update_indep_vars_listbox(current_indep_vars=current_indep_vars)

        # Actualizar componente de filtro si existe
        if hasattr(self, 'filter_component') and self.filter_component:
            self.filter_component.set_dataframe(self.data)

    def rename_variable(self):
        selected_indices = self.listbox_indep_vars_spec.curselection()
        if not selected_indices:
            messagebox.showwarning("Sin Selección", "Seleccione una variable de la lista para renombrar.")
            return

        if len(selected_indices) > 1:
            messagebox.showwarning("Múltiples Selecciones", "Por favor, seleccione solo una variable para renombrar a la vez.")
            return

        original_name = self.listbox_indep_vars_spec.get(selected_indices[0])
        new_name = self.rename_var_entry.get().strip()

        if not new_name:
            messagebox.showwarning("Nombre Vacío", "Por favor, ingrese un nuevo nombre para la variable.")
            return

        if new_name in self.data.columns and new_name != original_name:
            messagebox.showerror("Nombre Duplicado", f"El nombre '{new_name}' ya existe en el conjunto de datos.")
            return

        # Renombrar en el DataFrame
        self.data.rename(columns={original_name: new_name}, inplace=True)
        self.log_message(f"Variable '{original_name}' renombrada a '{new_name}'.")

        # Actualizar todas las listas de variables en la UI
        self._update_variable_selectors()
        self.rename_var_entry.delete(0, tk.END)

    def open_results_editor(self):
        if not self.results_text_content:
            messagebox.showinfo("Sin Resultados", "Primero genere un análisis para ver y editar los resultados.")
            return

        editor_window = tk.Toplevel(self)
        editor_window.title("Editar Texto de Resultados")
        editor_window.geometry("600x500")

        text_widget = scrolledtext.ScrolledText(editor_window, wrap="word", font=("Courier New", 10))
        text_widget.pack(fill="both", expand=True, padx=10, pady=10)
        text_widget.insert("1.0", self.results_text_content)

        def apply_and_close():
            self.results_text_content = text_widget.get("1.0", tk.END)
            self.show_results_tab()
            editor_window.destroy()

        btn_apply = ttk.Button(editor_window, text="Aplicar y Cerrar", command=apply_and_close)
        btn_apply.pack(pady=10)

    def update_font_styles(self, font_family, font_size):
        """Actualiza la fuente en los widgets de texto de esta pestaña."""
        if hasattr(self, 'txt_results'):
            self.txt_results.config(font=(font_family, font_size))

    def log_message(self, msg, level="INFO"): # Añadido nivel por defecto
        # Actualizar la etiqueta en la GUI
        if hasattr(self, 'msg_label') and self.msg_label:
            self.msg_label.config(text=str(msg))

        # Imprimir también en la consola para depuración más persistente
        print(f"[RegresionesTab - {level.upper()}] {msg}")
        sys.stdout.flush() # Asegurar que se imprima inmediatamente

    def _apply_custom_labels_to_series(self, series, labels_string):
        if not labels_string:
            return series
        
        mapping = {}
        for pair in labels_string.split(","):
            if ":" in pair:
                original, label = pair.split(":", 1)
                try:
                    # Try to convert original to numeric if the series is numeric
                    if pd.api.types.is_numeric_dtype(series):
                        mapping[float(original.strip())] = label.strip()
                    else:
                        mapping[original.strip()] = label.strip()
                except ValueError:
                    mapping[original.strip()] = label.strip()
        
        # Apply mapping. Use .get() with default to keep original if no mapping found
        return series.apply(lambda x: mapping.get(x, x))

    def load_data(self):
        file_path = filedialog.askopenfilename(title="Selecciona archivo Excel",
                                               filetypes=[("Excel files", "*.xlsx *.xls"), ("All files", "*.*")])
        if not file_path:
            self.log_message("Carga cancelada")
            return
        try:
            _, file_extension = os.path.splitext(file_path)
            file_extension = file_extension.lower()

            if file_extension == '.csv':
                df = pd.read_csv(file_path)
            elif file_extension in ['.xls', '.xlsx']:
                df = pd.read_excel(file_path)
            else:
                error_message = f"Tipo de archivo no soportado: {file_extension}. Por favor, seleccione un archivo CSV o Excel."
                self.log_message(error_message)
                messagebox.showerror("Tipo de Archivo No Soportado", error_message)
                return
            
            if df.columns[0].lower().startswith("unnamed: 0") or df.columns[0].lower() == "":
                df = df.iloc[:, 1:]
            
            if "edad de inicio" in df.columns: 
                orig_rows = df.shape[0]
                df = df[df["edad de inicio"] >= 0]
                self.log_message(f"Filtrado 'edad de inicio': {orig_rows-df.shape[0]} descartados de {orig_rows}")
            
            self.data = df
            self.lbl_file.config(text=f"Archivo: {os.path.basename(file_path)} ({df.shape[0]} filas, {df.shape[1]} columnas)")
            
            all_cols = list(df.columns)
            num_cols = list(df.select_dtypes(include=[np.number]).columns)

            # Actualizar componente de filtro
            if hasattr(self, 'filter_component') and self.filter_component:
                try:
                    self.filter_component.set_dataframe(self.data)
                except TypeError as te_filter_comp:
                    self.log_message(f"TypeError específico al llamar a FilterComponent.set_dataframe: {te_filter_comp}")
                    messagebox.showerror("Error de Tipo en Componente Filtro", 
                                         f"Se produjo un error de tipo (argumentos) al configurar el componente de filtro.\n"
                                         f"Detalle: {te_filter_comp}\n\n"
                                         "Esto puede indicar una incompatibilidad o un problema interno en FilterComponent al procesar los datos cargados.")
                    # Decide if you want to re-raise, or if other cleanup is needed.
                    # For now, logging and showing the error is the primary goal for diagnostics.
                    # If this error occurs, subsequent operations relying on filter_component might be affected.
                except Exception as e_filter_comp_other:
                    # Catch other potential errors from set_dataframe too
                    self.log_message(f"Otra excepción al llamar a FilterComponent.set_dataframe: {e_filter_comp_other}")
                    messagebox.showerror("Error en Componente Filtro",
                                         f"Se produjo una excepción general al configurar el componente de filtro.\n"
                                         f"Detalle: {e_filter_comp_other}")

            # Actualizar selectores de variables de regresión
            self.listbox_dep_vars_spec.delete(0, tk.END)
            for col in num_cols:
                self.listbox_dep_vars_spec.insert(tk.END, col)
            if num_cols:
                self.listbox_dep_vars_spec.selection_set(0) # Select the first item by default

            self.listbox_indep_vars_spec.delete(0, tk.END)
            # Call _update_indep_vars_listbox to populate it based on initial dep var selection
            self._update_indep_vars_listbox()
            
            self.log_message("Datos cargados. Configure variables y filtros.")
        except Exception as e:
            self.log_message(f"Error al cargar datos: {e}")
            traceback.print_exc()
            # Add the messagebox here
            messagebox.showerror("Error al Cargar Archivo", 
                                 f"Ocurrió un error detallado al intentar cargar el archivo:\n\n{e}\n\nConsulte la consola para ver el traceback completo si es necesario.")
            self.data = None
            self.lbl_file.config(text="Ningún archivo cargado.")
            self.listbox_dep_vars_spec.delete(0, tk.END) # Clear the listbox
            self.listbox_indep_vars_spec.delete(0, tk.END)
            # Limpiar componente de filtro en caso de error
            if hasattr(self, 'filter_component') and self.filter_component:
                self.filter_component.set_dataframe(None)

    def _update_indep_vars_listbox(self, event=None, current_indep_vars=None):
        if not hasattr(self, 'data') or self.data is None:
            return

        # Get all currently selected dependent variables
        selected_dep_indices = self.listbox_dep_vars_spec.curselection()
        selected_dep_vars = {self.listbox_dep_vars_spec.get(i) for i in selected_dep_indices}

        # If current_indep_vars is not provided (e.g., called from event), get current selection
        if current_indep_vars is None:
            current_indep_selection_indices = self.listbox_indep_vars_spec.curselection()
            current_indep_vars = {self.listbox_indep_vars_spec.get(i) for i in current_indep_selection_indices}

        self.listbox_indep_vars_spec.delete(0, tk.END)

        all_cols = list(self.data.columns)
        # Independent variables should not include any selected dependent variables
        available_indep_vars = [col for col in all_cols if col not in selected_dep_vars]

        for idx, var_name in enumerate(available_indep_vars):
            self.listbox_indep_vars_spec.insert(tk.END, var_name)
            if var_name in current_indep_vars:
                self.listbox_indep_vars_spec.selection_set(idx)

    # Se eliminan apply_filter_criteria y apply_filter_qual

    def _get_filtered_data_for_regression(self):
        """Obtiene los datos filtrados usando el FilterComponent."""
        if self.data is None:
            self.log_message("Error: No hay datos cargados.")
            return None

        df_filtered = None
        if hasattr(self, 'filter_component') and self.filter_component:
            df_filtered = self.filter_component.apply_filters()
            if df_filtered is None:
                self.log_message("Error al aplicar filtros.")
                return None # El componente ya mostró el error
            self.log_message(f"Datos filtrados: {df_filtered.shape[0]} filas.")
        else:
            df_filtered = self.data.copy() # Usar original si no hay filtro
            self.log_message("Usando datos originales (sin filtros).")

        if df_filtered.empty:
            self.log_message("No hay datos después de aplicar filtros.")
            return pd.DataFrame() # Devolver DF vacío en lugar de None

        return df_filtered

    def _parse_variable_specifications(self, spec_string, df_for_check, is_single_var=False):
        if not spec_string:
            self.log_message("Advertencia: No se especificaron variables.")
            return []
        
        lines = [spec_string.strip()] if is_single_var else [line.strip() for line in spec_string.split("\n") if line.strip()]
        parsed_vars = []
        
        if not lines:
             self.log_message(f"Advertencia: No se especificaron variables {'dependientes' if is_single_var else 'independientes'}.")
             return []

        for line_idx, line in enumerate(lines):
            original_name, display_name = line, line
            if ":" in line:
                parts = line.split(":", 1)
                original_name = parts[0].strip()
                display_name = parts[1].strip()
                if not display_name: display_name = original_name 
            
            if original_name not in df_for_check.columns:
                self.log_message(f"Advertencia: Variable '{original_name}' (línea {line_idx+1}) no encontrada en datos filtrados. Omitida.")
                continue
            
            if not pd.api.types.is_numeric_dtype(df_for_check[original_name]):
                self.log_message(f"Advertencia: Variable '{original_name}' (línea {line_idx+1}) no es numérica en datos filtrados. Omitida para regresión.")
                continue
            
            parsed_vars.append((original_name, display_name))
        
        if not parsed_vars:
             self.log_message("Advertencia: Ninguna variable válida para regresión fue procesada.")
        return parsed_vars

    @staticmethod
    def get_p_values_from_curve_fit(popt, pcov, n):
        p = len(popt)
        dof = max(0, n - p)
        
        if np.isinf(pcov).any():
            return [np.nan] * p

        perr = np.sqrt(np.diag(pcov))
        t_stats = popt / perr
        p_values = [2 * stats.t.sf(np.abs(t), dof) for t in t_stats]
        return p_values

    def calculate_and_show_correlations(self):
        self.log_message("Iniciando calculate_and_show_correlations...", "DEBUG")
        if self.data is None:
            self.log_message("calculate_and_show_correlations: No hay datos cargados. Retornando.", "WARN")
            return

        df_f = self._get_filtered_data_for_regression()
        if df_f is None:
            self.log_message("calculate_and_show_correlations: _get_filtered_data_for_regression devolvió None. Retornando.", "ERROR")
            return
        if df_f.empty:
            self.log_message("calculate_and_show_correlations: No hay datos después de aplicar filtros. Retornando.", "WARN")
            return

        selected_dep_indices = self.listbox_dep_vars_spec.curselection()
        selected_dep_vars_names = [self.listbox_dep_vars_spec.get(i) for i in selected_dep_indices]
        if not selected_dep_vars_names:
            messagebox.showwarning("Advertencia", "Por favor, seleccione al menos una variable dependiente.", parent=self)
            return

        selected_indep_indices = self.listbox_indep_vars_spec.curselection()
        selected_indep_vars_names = [self.listbox_indep_vars_spec.get(i) for i in selected_indep_indices]
        if not selected_indep_vars_names:
            messagebox.showwarning("Advertencia", "Por favor, seleccione al menos una variable independiente.", parent=self)
            return

        all_results = []

        for dep_var in selected_dep_vars_names:
            for indep_var in selected_indep_vars_names:
                if dep_var == indep_var:
                    continue

                temp_df = df_f[[dep_var, indep_var]].dropna()
                if temp_df.shape[0] < 2:
                    continue

                x = temp_df[indep_var].values
                y = temp_df[dep_var].values

                # Pearson
                pearson_r, pearson_p = safe_pearson(x, y)
                all_results.append({
                    "Variable Dependiente": dep_var,
                    "Variable Independiente": indep_var,
                    "Modelo": "Pearson",
                    "r": pearson_r,
                    "R²": pearson_r**2 if not np.isnan(pearson_r) else np.nan,
                    "P-valor": pearson_p
                })

                # Spearman
                spearman_r, spearman_p = safe_spearman(x, y)
                all_results.append({
                    "Variable Dependiente": dep_var,
                    "Variable Independiente": indep_var,
                    "Modelo": "Spearman",
                    "r": spearman_r,
                    "R²": np.nan, # R² is not typically reported for Spearman
                    "P-valor": spearman_p
                })

                if self.var_linear.get():
                    try:
                        X_lin = sm.add_constant(x)
                        mod = sm.OLS(y, X_lin).fit()
                        yhat = mod.predict(X_lin)
                        r, p_corr = safe_pearson(y, yhat)
                        all_results.append({
                            "Variable Dependiente": dep_var,
                            "Variable Independiente": indep_var,
                            "Modelo": "Lineal",
                            "r": r,
                            "R²": mod.rsquared,
                            "P-valor": mod.f_pvalue
                        })
                    except Exception as e: self.log_message(f"Error en modelo Lineal: {e}", "ERROR")
                
                if self.var_quadratic.get() and len(x) >= 3:
                    try:
                        X_quad = sm.add_constant(np.column_stack((x, x**2)))
                        mod_quad = sm.OLS(y, X_quad).fit()
                        yhat_quad = mod_quad.predict(X_quad)
                        p_quad, _ = safe_pearson(y, yhat_quad)
                        all_results.append({
                            "Variable Dependiente": dep_var,
                            "Variable Independiente": indep_var,
                            "Modelo": "Cuadrático",
                            "r": p_quad,
                            "R²": mod_quad.rsquared,
                            "P-valor": mod_quad.f_pvalue
                        })
                    except Exception as e: self.log_message(f"Error en modelo Cuadrático: {e}", "ERROR")

                if self.var_cubic.get() and len(x) >= 4:
                    try:
                        X_cubic = sm.add_constant(np.column_stack((x, x**2, x**3)))
                        mod_cubic = sm.OLS(y, X_cubic).fit()
                        yhat_cubic = mod_cubic.predict(X_cubic)
                        p_cubic, _ = safe_pearson(y, yhat_cubic)
                        all_results.append({
                            "Variable Dependiente": dep_var,
                            "Variable Independiente": indep_var,
                            "Modelo": "Cúbico",
                            "r": p_cubic,
                            "R²": mod_cubic.rsquared,
                            "P-valor": mod_cubic.f_pvalue
                        })
                    except Exception as e: self.log_message(f"Error en modelo Cúbico: {e}", "ERROR")

                if self.var_power.get():
                    mask_p = (x > 0) & (y > 0)
                    if mask_p.sum() > 2:
                        xp, yp = x[mask_p], y[mask_p]
                        try:
                            sl,it,_,p_val_b,_ = stats.linregress(np.log(xp),np.log(yp)); a,b=np.exp(it),sl; yhat=a*(xp**b)
                            p,pp=safe_pearson(yp,yhat); s,ps=safe_spearman(yp,yhat); r2=p**2 if not np.isnan(p) else np.nan
                            all_results.append({
                                "Variable Dependiente": dep_var,
                                "Variable Independiente": indep_var,
                                "Modelo": "Potencia",
                                "r": p,
                                "R²": r2,
                                "P-valor": pp
                            })
                        except Exception as e: self.log_message(f"Error en modelo Potencia: {e}", "ERROR")

                if self.var_log.get():
                    mask_l = x > 0
                    if mask_l.sum() > 2:
                        xp, yp = x[mask_l], y[mask_l]
                        try:
                            popt, pcov = curve_fit(lambda z,a,b:a+b*np.log(z),xp,yp,maxfev=10000); yhat=popt[0]+popt[1]*np.log(xp)
                            p,pp=safe_pearson(yp,yhat); s,ps=safe_spearman(yp,yhat); r2=p**2 if not np.isnan(p) else np.nan
                            all_results.append({
                                "Variable Dependiente": dep_var,
                                "Variable Independiente": indep_var,
                                "Modelo": "Logarítmico",
                                "r": p,
                                "R²": r2,
                                "P-valor": pp
                            })
                        except Exception as e: self.log_message(f"Error en modelo Logarítmico: {e}", "ERROR")

                if self.var_inverse.get():
                    mask_i = x != 0
                    if mask_i.sum() > 2:
                        xi, yi = x[mask_i], y[mask_i]
                        try:
                            X_inv = sm.add_constant(1 / xi)
                            mod_inv = sm.OLS(yi, X_inv).fit()
                            yhat_inv = mod_inv.predict(X_inv)
                            p_inv, pp_inv = safe_pearson(yi, yhat_inv)
                            all_results.append({
                                "Variable Dependiente": dep_var,
                                "Variable Independiente": indep_var,
                                "Modelo": "Inverso",
                                "r": p_inv,
                                "R²": mod_inv.rsquared,
                                "P-valor": mod_inv.f_pvalue
                            })
                        except Exception as e: self.log_message(f"Error en modelo Inverso: {e}", "ERROR")

                if self.var_rcs.get():
                    try:
                        X_rcs = dmatrix(f"cr(x, df=4)", {"x": x}, return_type='dataframe')
                        mod_rcs = sm.OLS(y, X_rcs).fit()
                        yhat_rcs = mod_rcs.predict(X_rcs)
                        p_rcs, _ = safe_pearson(y, yhat_rcs)
                        all_results.append({
                            "Variable Dependiente": dep_var,
                            "Variable Independiente": indep_var,
                            "Modelo": "Spline (RCS, df=4)",
                            "r": p_rcs,
                            "R²": mod_rcs.rsquared_adj,
                            "P-valor": mod_rcs.f_pvalue
                        })
                    except Exception as e: self.log_message(f"Error en modelo Spline (RCS): {e}", "ERROR")

                other_models_to_fit = []
                if self.var_exp1.get(): other_models_to_fit.append(("Exp (a+b^x)", exp_model1))
                if self.var_exp2.get(): other_models_to_fit.append(("Exp (a+x^b)", exp_model2))
                if self.var_exp3.get(): other_models_to_fit.append(("Exp (A*B^x)", exp_model3))
                if self.var_sigmoid.get(): other_models_to_fit.append(("Sigmoide", sigmoid))
                if self.var_exp_decay.get(): other_models_to_fit.append(("Exp Decreciente", exp_decay))

                for model_name, model_func in other_models_to_fit:
                    try:
                        p0_other = None
                        if model_name == "Sigmoide" and len(y)>1 and len(x)>0 : p0_other = [max(y)-min(y), 1.0, np.median(x), min(y)]
                        elif model_name == "Sigmoide": p0_other = [1,1,0,0]
                        
                        popt_other, pcov_other = curve_fit(model_func, x, y, p0=p0_other, maxfev=10000)
                        yhat_other = model_func(x, *popt_other)
                        pear_other, p_pear_other = safe_pearson(y, yhat_other)
                        r2_other = pear_other**2 if not np.isnan(pear_other) else np.nan
                        all_results.append({
                            "Variable Dependiente": dep_var,
                            "Variable Independiente": indep_var,
                            "Modelo": model_name,
                            "r": pear_other,
                            "R²": r2_other,
                            "P-valor": p_pear_other
                        })
                    except RuntimeError: self.log_message(f"No se pudo ajustar {model_name} para {indep_var} (RuntimeError).", "WARN")
                    except Exception as e_other_model: self.log_message(f"Error en {model_name} para {indep_var}: {e_other_model}", "ERROR")

                if self.var_cubic.get() and len(x) >= 4:
                    try:
                        X_cubic = sm.add_constant(np.column_stack((x, x**2, x**3)))
                        mod_cubic = sm.OLS(y, X_cubic).fit()
                        yhat_cubic = mod_cubic.predict(X_cubic)
                        p_cubic, _ = safe_pearson(y, yhat_cubic)
                        all_results.append({
                            "Variable Dependiente": dep_var,
                            "Variable Independiente": indep_var,
                            "Modelo": "Cúbico",
                            "r": p_cubic,
                            "R²": mod_cubic.rsquared,
                            "P-valor": mod_cubic.f_pvalue
                        })
                    except Exception as e: self.log_message(f"Error en modelo Cúbico: {e}", "ERROR")

        if not all_results:
            self.results_text_content = "No se pudieron calcular correlaciones para las variables seleccionadas."
            self.show_results_tab()
            return

        df_results = pd.DataFrame(all_results)
        df_results['is_significant'] = df_results['P-valor'] <= 0.05
        df_results['abs_r'] = df_results['r'].abs()
        df_results.sort_values(by=['is_significant', 'abs_r'], ascending=[False, False], inplace=True)
        df_results.drop(columns=['is_significant', 'abs_r'], inplace=True)
        
        pd.options.display.float_format = '{:,.3f}'.format

        self.results_text_content = df_results.to_string(index=False)
        self.show_results_tab()
        self.log_message("calculate_and_show_correlations: Tabla de correlaciones generada.", "INFO")

    def plot_regression(self):
        if self.var_table_only.get():
            self.calculate_and_show_correlations()
            return
        self.log_message("Iniciando plot_regression...", "DEBUG")
        if self.data is None:
            self.log_message("plot_regression: No hay datos cargados. Retornando.", "WARN")
            return

        df_f = self._get_filtered_data_for_regression()
        if df_f is None:
            self.log_message("plot_regression: _get_filtered_data_for_regression devolvió None. Retornando.", "ERROR")
            return
        if df_f.empty:
            self.log_message("plot_regression: No hay datos después de aplicar filtros. Retornando.", "WARN")
            return

        self.log_message(f"plot_regression: Datos filtrados obtenidos con {df_f.shape[0]} filas.", "DEBUG")

        selected_dep_indices = self.listbox_dep_vars_spec.curselection()
        selected_dep_vars_names = [self.listbox_dep_vars_spec.get(i) for i in selected_dep_indices]
        if not selected_dep_vars_names:
            messagebox.showwarning("Advertencia", "Por favor, seleccione al menos una variable dependiente.", parent=self)
            self.log_message("plot_regression: No hay variables dependientes seleccionadas. Retornando.", "WARN")
            return

        selected_indep_indices = self.listbox_indep_vars_spec.curselection()
        selected_indep_vars_names = [self.listbox_indep_vars_spec.get(i) for i in selected_indep_indices]
        if not selected_indep_vars_names:
            messagebox.showwarning("Advertencia", "Por favor, seleccione al menos una variable independiente.", parent=self)
            self.log_message("plot_regression: No hay variables independientes seleccionadas. Retornando.", "WARN")
            return

        self.log_message(f"plot_regression: Variables dependientes seleccionadas: {selected_dep_vars_names}", "DEBUG")
        self.log_message(f"plot_regression: Variables independientes seleccionadas: {selected_indep_vars_names}", "DEBUG")

        try:
            dpi = int(self.entry_dpi.get()); w_px = int(self.entry_width.get()); h_px = int(self.entry_height.get())
            w_in, h_in = w_px/dpi, h_px/dpi; pt_size = float(self.entry_pt_size.get()); txt_size = int(self.entry_text_size.get())
            title_sz = int(self.entry_title_size.get())
            self.log_message(f"plot_regression: Parámetros gráficos leídos: DPI={dpi}, W={w_px}, H={h_px}, PtSize={pt_size}, TxtSize={txt_size}", "DEBUG")
        except ValueError as e_params:
            self.log_message(f"plot_regression: Error en parámetros DPI/tamaño: {e_params}. Retornando.", "ERROR")
            messagebox.showerror("Error de Parámetros", f"Error en los valores de DPI o tamaño de gráfico:\n{e_params}", parent=self)
            return

        font_family = self.font_family_var.get()
        font_size = int(self.entry_text_size.get())
        decimals = self.decimals_var.get()
        if decimals is None:
            decimals = 2
        decimals = max(0, int(decimals))
        use_sci_notation = self.sci_notation_var.get()
        use_sci_notation_conditional = self.sci_notation_conditional_var.get()

        def resolve_entry_text(entry_widget, default_value):
            raw_value = entry_widget.get()
            if raw_value == "":
                return default_value
            stripped = raw_value.strip()
            if stripped == "":
                return ""
            return stripped

        def format_number(num):
            try:
                value = float(num)
            except (TypeError, ValueError):
                return str(num)

            lower_threshold = 10 ** (-(decimals + 1)) if decimals is not None else 0.001
            upper_threshold = 10 ** (decimals + 1) if decimals is not None else 1000

            if use_sci_notation:
                return f"{value:.{decimals}e}"
            if use_sci_notation_conditional and value != 0:
                abs_value = abs(value)
                if abs_value >= upper_threshold or abs_value < lower_threshold:
                    return f"{value:.{decimals}e}"
            return f"{value:.{decimals}f}"

        show_formula_flag = self.var_show_formula.get()
        show_r2_flag = self.var_show_r2.get()
        show_grid = self.var_grid.get()
        show_info = self.var_show_info.get()
        hide_point_legend = self.var_hide_points_labels.get()

        def build_poly_formula(dep_name, coeffs, indep_name):
            terms = []
            for power, coef in enumerate(coeffs):
                if coef is None:
                    continue
                try:
                    if np.isnan(coef):
                        continue
                except TypeError:
                    pass
                if power == 0:
                    terms.append(format_number(coef))
                else:
                    sign = "-" if coef < 0 else "+"
                    coef_abs = format_number(abs(coef))
                    var_part = indep_name if power == 1 else f"{indep_name}^{power}"
                    terms.append(f"{sign} {coef_abs}·{var_part}")
            if not terms:
                return f"{dep_name} = 0"
            first = terms[0]
            rest = " ".join(terms[1:]) if len(terms) > 1 else ""
            body = f"{first} {rest}".strip()
            return f"{dep_name} = {body}"

        def build_label(base, formula=None, r2_value=None):
            detail_parts = []
            if show_formula_flag and formula:
                detail_parts.append(formula)
            if show_r2_flag and r2_value is not None:
                try:
                    if not np.isnan(r2_value):
                        detail_parts.append(f"R²={format_number(r2_value)}")
                except TypeError:
                    detail_parts.append(f"R²={format_number(r2_value)}")
            if detail_parts:
                return f"{base} ({'; '.join(detail_parts)})"
            return base

        def normalize_p_values(p_values):
            if p_values is None:
                return []
            if isinstance(p_values, pd.Series):
                return list(p_values.items())
            if isinstance(p_values, dict):
                return list(p_values.items())
            try:
                return [(f"Coef {idx}", val) for idx, val in enumerate(p_values)]
            except TypeError:
                return [("Coef", p_values)]

        def parse_range_string(text_value):
            raw = (text_value or "").strip()
            if not raw:
                return None
            try:
                parts = [float(part.strip()) for part in raw.split(',') if part.strip()]
                if len(parts) == 2:
                    lo, hi = parts
                    if lo == hi:
                        return (lo, hi)
                    return (min(lo, hi), max(lo, hi))
            except ValueError:
                self.log_message(f"Rango inválido ingresado: '{raw}'", "WARN")
            return None

        def parse_ticks_string(text_value):
            raw = (text_value or "").strip()
            if not raw:
                return []
            ticks = []
            for piece in raw.split(','):
                piece = piece.strip()
                if not piece:
                    continue
                try:
                    ticks.append(float(piece))
                except ValueError:
                    self.log_message(f"Tick inválido ignorado: '{piece}'", "WARN")
            return ticks

        def configure_axis_format(axis):
            formatter = ScalarFormatter(useMathText=True)
            formatter.set_useOffset(False)
            if use_sci_notation:
                formatter.set_scientific(True)
                formatter.set_powerlimits((0, 0))
            elif use_sci_notation_conditional:
                formatter.set_scientific(True)
                power_limit = decimals + 1 if decimals is not None else 3
                formatter.set_powerlimits((-(power_limit), power_limit))
            else:
                formatter.set_scientific(False)
            axis.set_major_formatter(formatter)

        x_limits = parse_range_string(self.entry_xlim.get()) if hasattr(self, 'entry_xlim') else None
        y_limits = parse_range_string(self.entry_ylim.get()) if hasattr(self, 'entry_ylim') else None
        x_ticks_manual = parse_ticks_string(self.entry_xticks.get()) if hasattr(self, 'entry_xticks') else []
        y_ticks_manual = parse_ticks_string(self.entry_yticks.get()) if hasattr(self, 'entry_yticks') else []

        plt.rcParams.update({
            'font.family': font_family,
            'font.size': font_size,
            'axes.titlesize': title_sz,
            'axes.labelsize': font_size,
            'xtick.labelsize': font_size,
            'ytick.labelsize': font_size,
            'legend.fontsize': font_size
        })

        all_results_summary = []

        self.fig.clear()

        total_filtered_rows = len(df_f)
        filter_summary = ""
        if show_info and hasattr(self, 'filter_component') and self.filter_component:
            try:
                filter_summary = self.filter_component.get_active_filters_description()
            except Exception as exc:
                self.log_message(f"No se pudo obtener el resumen de filtros: {exc}", "WARN")
                filter_summary = ""

        for dep_original in selected_dep_vars_names:
            dep_display = dep_original
            self.log_message(f"plot_regression: Procesando VD: '{dep_original}'.", "DEBUG")

            if dep_original not in df_f.columns or not pd.api.types.is_numeric_dtype(df_f[dep_original]):
                self.log_message(f"plot_regression: VD '{dep_original}' no es válida. Saltando.", "ERROR")
                continue

            num_indep = len(selected_indep_vars_names)
            if num_indep == 0:
                continue

            self.fig.set_size_inches(w_in, h_in * num_indep)
            axes = self.fig.subplots(nrows=num_indep, ncols=1, squeeze=False)
            
            summary_for_dep = [f"Resumen de Modelos para VD: {dep_display}\n" + ("-" * 70) + "\n"]

            for i, indep_original in enumerate(selected_indep_vars_names):
                ax = axes[i, 0]
                indep_display = indep_original
                self.log_message(f"plot_regression: Procesando VI #{i+1}: '{indep_original}' para VD '{dep_original}'.", "DEBUG")

                if indep_original not in df_f.columns or not pd.api.types.is_numeric_dtype(df_f[indep_original]):
                    self.log_message(f"plot_regression: VI '{indep_original}' no es válida. Saltando.", "WARN")
                    ax.text(0.5, 0.5, f"Variable '{indep_original}' no válida.", ha='center', va='center')
                    continue

                temp_df = df_f[[dep_original, indep_original]].dropna()
                if temp_df.shape[0] < 2:
                    self.log_message(f"plot_regression: No hay suficientes datos para VI '{indep_display}'. Saltando.", "WARN")
                    ax.text(0.5, 0.5, f"No hay suficientes datos para '{indep_display}'.", ha='center', va='center')
                    continue

                x = temp_df[indep_original].values
                y = temp_df[dep_original].values
                
                # Apply custom labels to the dependent variable for display in summary
                custom_labels_str = self.entry_dep_var_labels.get().strip()
                y_for_summary = pd.Series(y)
                if custom_labels_str:
                    y_for_summary = self._apply_custom_labels_to_series(y_for_summary, custom_labels_str)

                # Add frequency table of dependent variable to summary
                freq_series = y_for_summary.value_counts(dropna=False) # Include NaNs if any
                freq_df = pd.DataFrame({
                    'Count': freq_series,
                    'Percentage': (freq_series / len(y_for_summary) * 100).round(2)
                })
                summary_for_dep.append(f"\nFrecuencia de la Variable Dependiente ({dep_display}):\n")
                summary_for_dep.append(freq_df.to_string() + "\n")
                summary_for_dep.append("-" * 70 + "\n")

                line_color = self.cmb_line_color.get()
                line_width = float(self.entry_line_width.get())
                point_color = self.cmb_pt_color.get()
                scatter_label = f"{indep_display} (datos)" if not hide_point_legend else "_nolegend_"
                ax.scatter(x, y, color=point_color, s=pt_size, alpha=0.6, label=scatter_label)

                sort_idx = np.argsort(x)
                x_sorted = x[sort_idx]
                
                results_list = []

                if self.var_linear.get():
                    try:
                        X_lin = sm.add_constant(x)
                        mod = sm.OLS(y, X_lin).fit()
                        const_lin, slope_lin = mod.params
                        formula_lin = build_poly_formula(dep_display, [const_lin, slope_lin], indep_display)
                        yhat = mod.predict(X_lin)
                        p_lin, _ = safe_pearson(y, yhat)
                        r2_lin = mod.rsquared
                        legend_label = build_label("Lineal", formula_lin, r2_lin)
                        ax.plot(x_sorted, mod.predict(sm.add_constant(x_sorted)), linestyle=self.model_styles["Lineal"]["linestyle"], color=line_color, lw=line_width, label=legend_label)
                        results_list.append({
                            "model": "Lineal",
                            "var": indep_display,
                            "dep_var": dep_display,
                            "r": p_lin,
                            "r2": r2_lin,
                            "formula": formula_lin,
                            "p_general": mod.f_pvalue,
                            "p_values": normalize_p_values(mod.pvalues)
                        })
                    except Exception as e: self.log_message(f"Error en modelo Lineal ({indep_display}): {e}", "ERROR")

                if self.var_quadratic.get() and len(x) >= 3:
                    try:
                        X_quad = sm.add_constant(np.column_stack((x, x**2)))
                        mod_quad = sm.OLS(y, X_quad).fit()
                        const_quad, coef1_quad, coef2_quad = mod_quad.params
                        formula_quad = build_poly_formula(dep_display, [const_quad, coef1_quad, coef2_quad], indep_display)
                        yhat_quad = mod_quad.predict(X_quad)
                        p_quad, _ = safe_pearson(y, yhat_quad)
                        r2_quad = mod_quad.rsquared
                        legend_label = build_label("Cuadrático", formula_quad, r2_quad)
                        ax.plot(x_sorted, np.polyval([coef2_quad, coef1_quad, const_quad], x_sorted), linestyle=self.model_styles["Cuadrático"]["linestyle"], color=line_color, lw=line_width, label=legend_label)
                        results_list.append({
                            "model": "Cuadrático",
                            "var": indep_display,
                            "dep_var": dep_display,
                            "r": p_quad,
                            "r2": r2_quad,
                            "formula": formula_quad,
                            "p_general": mod_quad.f_pvalue,
                            "p_values": normalize_p_values(mod_quad.pvalues)
                        })
                    except Exception as e: self.log_message(f"Error Cuad ({indep_display}): {e}", "ERROR")

                if self.var_cubic.get() and len(x) >= 4:
                    try:
                        X_cubic = sm.add_constant(np.column_stack((x, x**2, x**3)))
                        mod_cubic = sm.OLS(y, X_cubic).fit()
                        params_cubic = mod_cubic.params
                        formula_cubic = build_poly_formula(dep_display, params_cubic, indep_display)
                        yhat_cubic = mod_cubic.predict(X_cubic)
                        p_cubic, _ = safe_pearson(y, yhat_cubic)
                        r2_cubic = mod_cubic.rsquared
                        legend_label = build_label("Cúbico", formula_cubic, r2_cubic)
                        ax.plot(x_sorted, np.polyval(params_cubic[::-1], x_sorted), linestyle=self.model_styles["Cúbico"]["linestyle"], color=line_color, lw=line_width, label=legend_label)
                        results_list.append({
                            "model": "Cúbico",
                            "var": indep_display,
                            "dep_var": dep_display,
                            "r": p_cubic,
                            "r2": r2_cubic,
                            "formula": formula_cubic,
                            "p_general": mod_cubic.f_pvalue,
                            "p_values": normalize_p_values(mod_cubic.pvalues)
                        })
                    except Exception as e: self.log_message(f"Error Cúbico ({indep_display}): {e}", "ERROR")

                if self.var_power.get():
                    mask_p = (x > 0) & (y > 0)
                    if mask_p.sum() > 2:
                        xp, yp = x[mask_p], y[mask_p]
                        try:
                            sl,it,_,p_val_b,_ = stats.linregress(np.log(xp),np.log(yp)); a,b=np.exp(it),sl; yhat=a*(xp**b)
                            p,pp=safe_pearson(yp,yhat); s,ps=safe_spearman(yp,yhat); r2=p**2 if not np.isnan(p) else np.nan
                            formula_power = f"{dep_display} = {format_number(a)}·{indep_display}^{format_number(b)}"
                            legend_label = build_label("Potencia", formula_power, r2)
                            ax.plot(np.sort(xp), a*np.power(np.sort(xp),b), linestyle=self.model_styles["Potencia"]["linestyle"], color=line_color, label=legend_label)
                            results_list.append({
                                "model": "Potencia",
                                "var": indep_display,
                                "dep_var": dep_display,
                                "r": p,
                                "r2": r2,
                                "formula": formula_power,
                                "p_values": [("Intercepto", np.nan), ("Exponente", p_val_b)]
                            })
                        except Exception as e: self.log_message(f"Error Potencia ({indep_display}): {e}", "ERROR")

                if self.var_log.get():
                    mask_l = x > 0
                    if mask_l.sum() > 2:
                        xp, yp = x[mask_l], y[mask_l]
                        try:
                            popt, pcov = curve_fit(lambda z,a,b:a+b*np.log(z),xp,yp,maxfev=10000); yhat=popt[0]+popt[1]*np.log(xp)
                            p,pp=safe_pearson(yp,yhat); s,ps=safe_spearman(yp,yhat); r2=p**2 if not np.isnan(p) else np.nan
                            p_values = self.get_p_values_from_curve_fit(popt, pcov, len(yp))
                            formula_log = f"{dep_display} = {format_number(popt[0])} + {format_number(popt[1])}·ln({indep_display})"
                            legend_label = build_label("Logarítmico", formula_log, r2)
                            ax.plot(np.sort(xp), popt[0]+popt[1]*np.log(np.sort(xp)), linestyle=self.model_styles["Logarítmico"]["linestyle"], color=line_color, label=legend_label)
                            p_values_named = [(f"Parámetro {idx}", val) for idx, val in enumerate(p_values)] if p_values is not None else []
                            results_list.append({
                                "model": "Logarítmico",
                                "var": indep_display,
                                "dep_var": dep_display,
                                "r": p,
                                "r2": r2,
                                "formula": formula_log,
                                "p_values": p_values_named
                            })
                        except Exception as e: self.log_message(f"Error Log ({indep_display}): {e}", "ERROR")

                if self.var_loess.get() and len(x) > 5:
                    try:
                        lo=lowess(y,x,frac=0.3); xs,ys=lo[:,0],lo[:,1]; acme_x,acme_y=compute_acme(lambda z:np.interp(z,xs,ys),np.linspace(xs.min(),xs.max(),200))
                        formula_loess = f"LOESS({indep_display})"
                        legend_label = build_label("LOESS", formula_loess, None)
                        results_list.append({"model":"LOESS", "var":indep_display, "dep_var":dep_display, "r":np.nan, "r2":np.nan, "formula":f"LOESS para {indep_display}: acme en x={format_number(acme_x)}, y={format_number(acme_y)}"})
                        ax.plot(xs,ys, linestyle=self.model_styles["LOESS"]["linestyle"], color=line_color, label=legend_label)
                    except Exception as e: self.log_message(f"Error LOESS ({indep_display}): {e}", "ERROR")

                if self.var_inverse.get():
                    mask_i = x != 0
                    if mask_i.sum() > 2:
                        xi, yi = x[mask_i], y[mask_i]
                        try:
                            X_inv = sm.add_constant(1 / xi)
                            mod_inv = sm.OLS(yi, X_inv).fit()
                            a_inv, b_inv = mod_inv.params
                            yhat_inv = mod_inv.predict(X_inv)
                            p_inv, pp_inv = safe_pearson(yi, yhat_inv)
                            s_inv, ps_inv = safe_spearman(yi, yhat_inv)
                            r2_inv = mod_inv.rsquared
                            formula_inv = f"{dep_display} = {format_number(a_inv)} + {format_number(b_inv)}/{indep_display}"
                            legend_label = build_label("Inverso", formula_inv, r2_inv)
                            results_list.append({
                                "model": "Inverso",
                                "var": indep_display,
                                "dep_var": dep_display,
                                "r": p_inv,
                                "r2": r2_inv,
                                "formula": formula_inv,
                                "p_general": mod_inv.f_pvalue,
                                "p_values": normalize_p_values(mod_inv.pvalues)
                            })
                            x_sorted_inv = np.sort(xi)
                            ax.plot(x_sorted_inv, a_inv + b_inv / x_sorted_inv, linestyle="-", color=line_color, label=legend_label)
                        except Exception as e_inv: self.log_message(f"Error Inverso ({indep_display}): {e_inv}", "ERROR")

                if self.var_rcs.get():
                    try:
                        X_rcs = dmatrix(f"cr(x, df=4)", {"x": x}, return_type='dataframe')
                        mod_rcs = sm.OLS(y, X_rcs).fit()
                        yhat_rcs = mod_rcs.predict(dmatrix(f"cr(x_sorted, df=4)", {"x_sorted": x_sorted}, return_type='dataframe'))
                        p_rcs, pp_rcs = safe_pearson(y, mod_rcs.predict(X_rcs))
                        s_rcs, ps_rcs = safe_spearman(y, mod_rcs.predict(X_rcs))
                        r2_rcs = mod_rcs.rsquared_adj
                        formula_rcs = "Spline Cúbico Restringido (df=4)"
                        legend_label = build_label("Spline RCS", formula_rcs, r2_rcs)
                        results_list.append({
                            "model": "Spline (RCS, df=4)",
                            "var": indep_display,
                            "dep_var": dep_display,
                            "r": p_rcs,
                            "r2": r2_rcs,
                            "formula": formula_rcs,
                            "p_general": mod_rcs.f_pvalue,
                            "p_values": normalize_p_values(mod_rcs.pvalues)
                        })
                        ax.plot(x_sorted, yhat_rcs, linestyle="--", color=line_color, label=legend_label)
                    except Exception as e_rcs: self.log_message(f"Error en modelo Spline (RCS) ({indep_display}): {e_rcs}", "ERROR")

                other_models_to_fit = []
                if self.var_exp1.get(): other_models_to_fit.append(("Exp (a+b^x)", exp_model1))
                if self.var_exp2.get(): other_models_to_fit.append(("Exp (a+x^b)", exp_model2))
                if self.var_exp3.get(): other_models_to_fit.append(("Exp (A*B^x)", exp_model3))
                if self.var_sigmoid.get(): other_models_to_fit.append(("Sigmoide", sigmoid))
                if self.var_exp_decay.get(): other_models_to_fit.append(("Exp Decreciente", exp_decay))

                for model_name, model_func in other_models_to_fit:
                    try:
                        p0_other = None
                        if model_name == "Sigmoide" and len(y)>1 and len(x)>0 : p0_other = [max(y)-min(y), 1.0, np.median(x), min(y)]
                        elif model_name == "Sigmoide": p0_other = [1,1,0,0]
                        
                        popt_other, pcov_other = curve_fit(model_func, x, y, p0=p0_other, maxfev=10000)
                        yhat_other = model_func(x, *popt_other)
                        pear_other, p_pear_other = safe_pearson(y, yhat_other)
                        spear_other, p_spear_other = safe_spearman(y, yhat_other)
                        r2_other = pear_other**2 if not np.isnan(pear_other) else np.nan
                        p_values_other = self.get_p_values_from_curve_fit(popt_other, pcov_other, len(y))
                        if model_name == "Exp (a+b^x)":
                            formula_str_other = f"{dep_display} = {format_number(popt_other[0])} + {format_number(popt_other[1])}^{indep_display}"
                        elif model_name == "Exp (a+x^b)":
                            formula_str_other = f"{dep_display} = {format_number(popt_other[0])} + {indep_display}^{format_number(popt_other[1])}"
                        elif model_name == "Exp (A*B^x)":
                            formula_str_other = f"{dep_display} = {format_number(popt_other[0])}·{format_number(popt_other[1])}^{indep_display}"
                        elif model_name == "Sigmoide":
                            formula_str_other = (f"{dep_display} = {format_number(popt_other[0])} / (1 + exp(-{format_number(popt_other[1])}·({indep_display}-{format_number(popt_other[2])})))"
                                                f" + {format_number(popt_other[3])}")
                        elif model_name == "Exp Decreciente":
                            formula_str_other = f"{dep_display} = {format_number(popt_other[0])}·exp(-{format_number(popt_other[1])}·{indep_display})"
                        else:
                            formula_str_other = f"{model_name}"

                        legend_label = build_label(model_name, formula_str_other, r2_other)
                        p_values_named = [(f"Parámetro {idx}", val) for idx, val in enumerate(p_values_other)] if p_values_other is not None else []
                        results_list.append({
                            "model": model_name,
                            "var": indep_display,
                            "dep_var": dep_display,
                            "r": pear_other,
                            "r2": r2_other,
                            "formula": formula_str_other,
                            "p_values": p_values_named
                        })
                        ax.plot(x_sorted, model_func(x_sorted, *popt_other), linestyle=self.model_styles[model_name]["linestyle"], color=line_color, label=legend_label)
                    except RuntimeError: self.log_message(f"No se pudo ajustar {model_name} para {indep_display} (RuntimeError).", "WARN")
                    except Exception as e_other_model: self.log_message(f"Error en {model_name} para {indep_display}: {e_other_model}", "ERROR")

                resolved_xlabel = resolve_entry_text(self.entry_xlabel, indep_display)
                ax.set_xlabel(resolved_xlabel, fontsize=txt_size)
                resolved_ylabel = resolve_entry_text(self.entry_ylabel, dep_display)
                ax.set_ylabel(resolved_ylabel, fontsize=txt_size)
                resolved_title = resolve_entry_text(self.entry_title, f"Regresión de {dep_display} vs {indep_display}")
                ax.set_title(resolved_title, fontsize=title_sz)

                if self.var_plot_corr.get():
                    try:
                        r_p, _ = safe_pearson(x, y)
                        r_s, _ = safe_spearman(x, y)
                        corr_text = f"Pearson: {r_p:.3f}\nSpearman: {r_s:.3f}"
                        ax.annotate(corr_text, xy=(0.05, 0.95), xycoords='axes fraction',
                                    fontsize=max(6, txt_size-2), ha='left', va='top',
                                    bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="none", alpha=0.7))
                    except Exception as e: self.log_message(f"Error anotando correlaciones: {e}", "WARN")

                if x_limits:
                    ax.set_xlim(x_limits)
                if y_limits:
                    ax.set_ylim(y_limits)
                if x_ticks_manual:
                    ax.set_xticks(x_ticks_manual)
                if y_ticks_manual:
                    ax.set_yticks(y_ticks_manual)

                configure_axis_format(ax.xaxis)
                configure_axis_format(ax.yaxis)

                if show_grid:
                    ax.grid(True, linestyle='--', alpha=0.7)
                else:
                    ax.grid(False)

                if show_info:
                    info_lines = []
                    if total_filtered_rows is not None:
                        info_lines.append(f"n filtrado: {total_filtered_rows}")
                    info_lines.append(f"n modelo: {len(temp_df)}")
                    if filter_summary:
                        wrapped_filters = textwrap.wrap(filter_summary, width=45)
                        if wrapped_filters:
                            info_lines.append("Filtros:")
                            info_lines.extend(wrapped_filters)
                    info_text = "\n".join(info_lines)
                    ax.annotate(info_text, xy=(0.95, 0.95), xycoords='axes fraction', fontsize=max(6, txt_size-2),
                                ha='right', va='top', bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="#666666", alpha=0.6))

                handles, labels = ax.get_legend_handles_labels()
                legend_pairs = [(h, l) for h, l in zip(handles, labels) if l and l != '_nolegend_']
                if legend_pairs:
                    handles, labels = zip(*legend_pairs)
                    ax.legend(handles, labels, fontsize=max(6, txt_size-2), loc='best')
                else:
                    existing_legend = ax.get_legend()
                    if existing_legend is not None:
                        existing_legend.remove()

                results_list.sort(key=lambda x: x.get("r2", -1), reverse=True)
                for r_item in results_list:
                    summary_for_dep.append(f"Modelo: {r_item['model']} | VI: {r_item['var']}\n")
                    if show_formula_flag and r_item.get('formula'):
                        summary_for_dep.append(f"  Fórmula: {r_item['formula']}\n")
                    if show_r2_flag and ('r2' in r_item) and r_item['r2'] is not None:
                        try:
                            summary_for_dep.append(f"  R² = {format_number(r_item['r2'])}\n")
                        except Exception:
                            summary_for_dep.append(f"  R² = {r_item['r2']}\n")
                    if 'p_general' in r_item and r_item['p_general'] is not None:
                        summary_for_dep.append(f"  P-valor (general) = {fmt_p(r_item['p_general'])}\n")
                    if 'p_values' in r_item:
                        summary_for_dep.append("  P-valores de coeficientes:\n")
                        p_iterable = r_item['p_values']
                        if isinstance(p_iterable, list):
                            for entry in p_iterable:
                                if isinstance(entry, tuple) and len(entry) == 2:
                                    label, p_val = entry
                                    summary_for_dep.append(f"    {label}: {fmt_p(p_val)}\n")
                                else:
                                    summary_for_dep.append(f"    Coef: {fmt_p(entry)}\n")
                        elif isinstance(p_iterable, pd.Series):
                            for label, p_val in p_iterable.items():
                                summary_for_dep.append(f"    {label}: {fmt_p(p_val)}\n")
                        elif isinstance(p_iterable, dict):
                            for label, p_val in p_iterable.items():
                                summary_for_dep.append(f"    {label}: {fmt_p(p_val)}\n")
                        else:
                            summary_for_dep.append(f"    Coef: {fmt_p(p_iterable)}\n")
                    summary_for_dep.append(f"{'-' * 70}\n")

            all_results_summary.extend(summary_for_dep)
            self.fig.tight_layout()
            self.canvas.draw()
            self.log_message(f"plot_regression: Gráfico para '{dep_display}' dibujado en el canvas.", "INFO")

            # Switch to the graph tab
            self.results_notebook.select(self.graph_frame)

        self.results_text_content = "".join(all_results_summary)
        self.show_results_tab()
        self.log_message("plot_regression: Todas las gráficas y resúmenes generados.", "INFO")
    def show_results_tab(self):
        self.log_message("show_results_tab: Actualizando widget de texto con resultados.", "DEBUG")
        self.txt_results.config(state="normal")
        self.txt_results.delete("1.0", tk.END)
        self.txt_results.insert("1.0", self.results_text_content)
        self.txt_results.config(state="disabled")




    def save_graph_directly(self):
        self.log_message("Iniciando save_graph_directly...", "DEBUG")
        
        if not self.fig.axes:
            self.log_message("save_graph_directly: No hay gráfica para guardar (figura vacía). Retornando.", "WARN")
            messagebox.showwarning("Sin Gráfica", "No hay gráfica generada para guardar. Genere una primero.", parent=self)
            return

        dest = filedialog.asksaveasfilename(initialfile="regresion_plot.png",
                                            defaultextension=".png",
                                            filetypes=[("PNG files", "*.png"), ("JPEG files", "*.jpg;*.jpeg"), ("All files", "*.*")])
        if dest:
            try:
                self.fig.savefig(dest)
                self.log_message(f"Gráfica guardada en {dest}")
            except Exception as e:
                self.log_message(f"Error al guardar gráfica: {e}")

def run_tkinter_app():
    root = tk.Tk()
    root.title("Regresiones y Dispersión")
    root.geometry("1200x800") # Set initial size, but the window will be resizable
    root.rowconfigure(0, weight=1)
    root.columnconfigure(0, weight=1)
    nb = ttk.Notebook(root)
    nb.grid(row=0, column=0, sticky="nsew")
    tab = RegresionesTab(nb)
    nb.add(tab, text="Regresiones")
    root.mainloop()

# ==============================
# Modo de ejecución: Elegir entre WEB o DESKTOP
# ==============================
if __name__ == "__main__":
    # Para simplificar, ejecutar directamente la versión Tkinter
    run_tkinter_app()
    # mode = input("Seleccione el modo de ejecución (web/desktop): ").strip().lower()
    # if mode in ["web", "w"]:
    #     run_flask_app()
    # elif mode in ["desktop", "tk", "t"]:
    #     run_tkinter_app()
    # else:
    #     print("Modo no reconocido. Escriba 'web' o 'desktop'.")
