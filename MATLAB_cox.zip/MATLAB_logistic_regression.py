#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
import traceback
import os
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from sklearn.metrics import roc_curve, auc, confusion_matrix, classification_report, roc_auc_score
from statsmodels.graphics.gofplots import ProbPlot
from scipy import stats
# Considerar una función directa para Hosmer-Lemeshow si existe o implementarla.

try:
    from MATLAB_filter_component import FilterComponent
except ImportError:
    messagebox.showerror("Error de Importación", "No se pudo importar FilterComponent.")
    FilterComponent = None

class LogisticRegressionTab(ttk.Frame):
    def __init__(self, master, main_app_instance=None):
        super().__init__(master)
        self.main_app = main_app_instance
        super().__init__(master)
        self.df_original = None
        self.df_filtered = None
        self.model_results = None

        # Variables de control Tkinter
        self.filepath_var = tk.StringVar()
        self.dependent_var = tk.StringVar()
        self.independent_vars = [] # Lista de nombres de variables independientes seleccionadas

        # Integración del componente de filtro
        self.filter_component = None

        self._build_ui()

    def _build_ui(self):
        # --- Layout Principal (PanedWindow) ---
        main_pane = ttk.PanedWindow(self, orient=tk.HORIZONTAL)
        main_pane.pack(fill=tk.BOTH, expand=True)

        # --- Panel Izquierdo: Controles ---
        left_pane = ttk.Frame(main_pane)
        main_pane.add(left_pane, weight=1)

        # --- Panel Derecho: Resultados ---
        right_pane = ttk.Frame(main_pane)
        main_pane.add(right_pane, weight=2)

        # --- Controles en Panel Izquierdo ---
        controls_frame = ttk.LabelFrame(left_pane, text="Configuración Regresión Logística")
        controls_frame.pack(padx=10, pady=10, fill="both", expand=True)

        # 1. Carga de Archivo
        file_frame = ttk.LabelFrame(controls_frame, text="1. Carga de Datos")
        file_frame.pack(fill="x", padx=5, pady=5)
        path_frame = ttk.Frame(file_frame)
        path_frame.pack(fill="x", pady=2)
        ttk.Label(path_frame, text="Archivo:").pack(side="left", padx=5)
        ttk.Entry(path_frame, textvariable=self.filepath_var, width=40, state="readonly").pack(side="left", padx=5, expand=True, fill="x")
        ttk.Button(path_frame, text="Buscar", command=self._load_file).pack(side="left", padx=5)

        # 2. Filtros
        if FilterComponent:
            self.filter_component = FilterComponent(controls_frame, self.df_original)
            self.filter_component.pack(fill="x", padx=5, pady=5)

        # 3. Selección de Variables
        vars_frame = ttk.LabelFrame(controls_frame, text="3. Selección de Variables")
        vars_frame.pack(fill="x", padx=5, pady=5)
        # Variable Dependiente (Binaria)
        ttk.Label(vars_frame, text="Dependiente (Binaria):").grid(row=0, column=0, padx=5, pady=2, sticky="w")
        self.dep_var_combo = ttk.Combobox(vars_frame, textvariable=self.dependent_var, state="readonly", width=25)
        self.dep_var_combo.grid(row=0, column=1, padx=5, pady=2, sticky="ew")
        self.dep_var_combo.bind("<<ComboboxSelected>>", self._validate_dependent_var)

        # Codificación de la variable dependiente
        coding_frame = ttk.Frame(vars_frame)
        coding_frame.grid(row=0, column=2, padx=5, pady=2, sticky="w")
        ttk.Label(coding_frame, text="Codificar como 0:").pack(side="left")
        self.code_as_0_var = tk.StringVar(value="0")
        ttk.Entry(coding_frame, textvariable=self.code_as_0_var, width=5).pack(side="left")
        ttk.Label(coding_frame, text="Codificar como 1:").pack(side="left")
        self.code_as_1_var = tk.StringVar(value="1")
        ttk.Entry(coding_frame, textvariable=self.code_as_1_var, width=5).pack(side="left")
        # Variables Independientes
        ttk.Label(vars_frame, text="Independientes:").grid(row=1, column=0, padx=5, pady=2, sticky="nw")
        list_frame = ttk.Frame(vars_frame)
        list_frame.grid(row=1, column=1, padx=5, pady=2, sticky="nsew")
        self.indep_var_listbox = tk.Listbox(list_frame, selectmode=tk.MULTIPLE, height=6, exportselection=False)
        indep_scroll = ttk.Scrollbar(list_frame, orient="vertical", command=self.indep_var_listbox.yview)
        self.indep_var_listbox.configure(yscrollcommand=indep_scroll.set)
        indep_scroll.pack(side="right", fill="y")
        self.indep_var_listbox.pack(side="left", fill="both", expand=True)
        vars_frame.columnconfigure(1, weight=1)
        vars_frame.rowconfigure(1, weight=1)

        # 4. Botón de Ejecución
        run_button = ttk.Button(controls_frame, text="Ejecutar Regresión Logística", command=self._run_logistic_regression)
        run_button.pack(pady=10)

        # --- Resultados en Panel Derecho (con Notebook para texto y gráficos) ---
        self.results_notebook = ttk.Notebook(right_pane)
        self.results_notebook.pack(padx=10, pady=10, fill="both", expand=True)

        # Pestaña para Resultados de Texto
        results_text_frame = ttk.Frame(self.results_notebook)
        self.results_notebook.add(results_text_frame, text="Resumen del Modelo")
        self.results_text = tk.Text(results_text_frame, wrap="none", height=25)
        results_v_scroll = ttk.Scrollbar(results_text_frame, orient="vertical", command=self.results_text.yview)
        results_h_scroll = ttk.Scrollbar(results_text_frame, orient="horizontal", command=self.results_text.xview)
        self.results_text.configure(yscrollcommand=results_v_scroll.set, xscrollcommand=results_h_scroll.set)
        results_v_scroll.pack(side="right", fill="y")
        results_h_scroll.pack(side="bottom", fill="x")
        self.results_text.pack(fill="both", expand=True, padx=5, pady=5)
        self.results_text.config(state="disabled")

        # Pestaña para Gráfico ROC (se añadirá dinámicamente)
        self.roc_plot_frame = None # Se creará al generar el gráfico

        # Controles de fuente para gráficos
        font_frame = ttk.LabelFrame(controls_frame, text="5. Opciones de Gráfico")
        font_frame.pack(fill="x", padx=5, pady=5)

        # --- Fila 1: Fuente y Tamaño ---
        font_row = ttk.Frame(font_frame)
        font_row.pack(fill="x", pady=2)
        ttk.Label(font_row, text="Fuente:").pack(side="left", padx=(5, 2))
        self.font_family_var = tk.StringVar(value="sans-serif")
        font_families = ["serif", "sans-serif", "monospace", "Arial", "Times New Roman", "Courier New", "Palatino Linotype"]
        self.font_family_combo = ttk.Combobox(font_row, textvariable=self.font_family_var, values=font_families, state="readonly", width=15)
        self.font_family_combo.pack(side="left", padx=2)

        ttk.Label(font_row, text="Tamaño:").pack(side="left", padx=(10, 2))
        self.font_size_var = tk.IntVar(value=10)
        self.font_size_spinbox = ttk.Spinbox(font_row, from_=6, to=20, textvariable=self.font_size_var, width=5)
        self.font_size_spinbox.pack(side="left", padx=2)

        # --- Fila 2: Opciones de Gráfico ---
        options_row = ttk.Frame(font_frame)
        options_row.pack(fill="x", pady=2)
        self.normalize_vars = tk.BooleanVar(value=False)
        self.grid_on = tk.BooleanVar(value=True)
        ttk.Checkbutton(options_row, text="Normalizar", variable=self.normalize_vars).pack(side="left", padx=5)
        ttk.Checkbutton(options_row, text="Rejilla", variable=self.grid_on).pack(side="left", padx=5)

        # --- Fila 3: Colores ---
        color_row = ttk.Frame(font_frame)
        color_row.pack(fill="x", pady=2)
        self.line_color = tk.StringVar(value="darkorange")
        self.marker_color = tk.StringVar(value="navy")
        ttk.Label(color_row, text="Línea:").pack(side="left", padx=5)
        self.line_color_combo = ttk.Combobox(color_row, textvariable=self.line_color, values=["darkorange", "blue", "green", "red", "purple", "black"], width=10)
        self.line_color_combo.pack(side="left")
        ttk.Label(color_row, text="Marcador:").pack(side="left", padx=5)
        self.marker_color_combo = ttk.Combobox(color_row, textvariable=self.marker_color, values=["navy", "blue", "green", "red", "purple", "black"], width=10)
        self.marker_color_combo.pack(side="left")

        # --- Fila 4: Títulos y Ejes ---
        title_row = ttk.Frame(font_frame)
        title_row.pack(fill="x", pady=2)
        self.title_var = tk.StringVar(value="")
        self.xlabel_var = tk.StringVar(value="")
        self.ylabel_var = tk.StringVar(value="")
        ttk.Label(title_row, text="Título:").pack(side="left", padx=5)
        ttk.Entry(title_row, textvariable=self.title_var, width=20).pack(side="left")
        ttk.Label(title_row, text="Eje X:").pack(side="left", padx=5)
        ttk.Entry(title_row, textvariable=self.xlabel_var, width=20).pack(side="left")
        ttk.Label(title_row, text="Eje Y:").pack(side="left", padx=5)
        ttk.Entry(title_row, textvariable=self.ylabel_var, width=20).pack(side="left")

        risk_frame = ttk.LabelFrame(controls_frame, text="Análisis de Riesgo")
        risk_frame.pack(fill="x", padx=5, pady=5)

        risk_percent_frame = ttk.Frame(risk_frame)
        risk_percent_frame.pack(fill="x", pady=2)
        ttk.Label(risk_percent_frame, text="Riesgo (%):").pack(side="left", padx=5)
        self.risk_percent_var = tk.DoubleVar(value=50.0)
        ttk.Entry(risk_percent_frame, textvariable=self.risk_percent_var, width=10).pack(side="left")
        ttk.Button(risk_percent_frame, text="Calcular Punto de Riesgo", command=self._calculate_risk_point).pack(side="left", padx=5)

        covariate_values_frame = ttk.Frame(risk_frame)
        covariate_values_frame.pack(fill="x", pady=2)
        ttk.Label(covariate_values_frame, text="Valores de Covariables (separados por coma):").pack(side="left", padx=5)
        self.covariate_values_var = tk.StringVar()
        ttk.Entry(covariate_values_frame, textvariable=self.covariate_values_var, width=40).pack(side="left")
        ttk.Button(covariate_values_frame, text="Calcular Riesgo Específico", command=self._calculate_specific_risk).pack(side="left", padx=5)

        bootstrap_frame = ttk.LabelFrame(controls_frame, text="Intervalos de Confianza")
        bootstrap_frame.pack(fill="x", padx=5, pady=5)
        self.show_ci = tk.BooleanVar(value=False)
        self.bootstrap_ci = tk.BooleanVar(value=False)

        ci_check_frame = ttk.Frame(bootstrap_frame)
        ci_check_frame.pack(fill="x", pady=2)
        ttk.Checkbutton(ci_check_frame, text="Mostrar IC en Gráfica", variable=self.show_ci).pack(side="left", padx=5)
        ttk.Checkbutton(ci_check_frame, text="Usar Bootstrap para IC", variable=self.bootstrap_ci).pack(side="left", padx=5)

        cycles_frame = ttk.Frame(bootstrap_frame)
        cycles_frame.pack(fill="x", pady=2)
        ttk.Label(cycles_frame, text="Ciclos Bootstrap:").pack(side="left", padx=5)
        self.bootstrap_cycles_var = tk.IntVar(value=1000)
        ttk.Entry(cycles_frame, textvariable=self.bootstrap_cycles_var, width=10).pack(side="left")

        seed_frame = ttk.Frame(bootstrap_frame)
        seed_frame.pack(fill="x", pady=2)
        ttk.Label(seed_frame, text="Semilla Bootstrap:").pack(side="left", padx=5)
        self.bootstrap_seed_var = tk.IntVar(value=42)
        ttk.Entry(seed_frame, textvariable=self.bootstrap_seed_var, width=10).pack(side="left")

    def _load_file(self):
        """Carga un archivo CSV o Excel y actualiza los controles."""
        filepath = filedialog.askopenfilename(
            title="Seleccionar archivo de datos",
            filetypes=(("Archivos Excel", "*.xls *.xlsx"), ("Archivos CSV", "*.csv"), ("Todos los archivos", "*.*"))
        )
        if not filepath: return

        ext = os.path.splitext(filepath)[1].lower()
        try:
            if ext == ".csv": self.df_original = pd.read_csv(filepath, sep=",")
            elif ext in [".xls", ".xlsx"]: self.df_original = pd.read_excel(filepath)
            else: messagebox.showerror("Error de Archivo", "Tipo de archivo no soportado."); return

            self.filepath_var.set(filepath)
            self._update_variable_selectors()
            if self.filter_component:
                self.filter_component.set_dataframe(self.df_original)

            self.results_text.config(state="normal")
            self.results_text.delete("1.0", tk.END)
            self.results_text.insert(tk.END, f"Archivo '{os.path.basename(filepath)}' cargado.\n")
            self.results_text.insert(tk.END, f"Dimensiones de los datos: {self.df_original.shape}\n")
            self.results_text.config(state="disabled")
            self.log(f"Datos cargados: {self.df_original.shape}", "INFO")

        except Exception as e:
            messagebox.showerror("Error al Leer Archivo", f"No se pudo leer el archivo:\n{e}")
            self.df_original = None; self.filepath_var.set(""); self._update_variable_selectors()
            if self.filter_component:
                self.filter_component.set_dataframe(None)
            self.log(f"Error cargando archivo: {e}", "ERROR")

    def _update_variable_selectors(self):
        """Actualiza los combobox y listbox de selección de variables."""
        cols = sorted(self.df_original.columns.tolist()) if self.df_original is not None else []
        binary_cols = []
        if self.df_original is not None:
            for col in cols:
                # Considerar binaria si tiene 2 valores únicos y es numérica o booleana
                unique_vals = self.df_original[col].dropna().unique()
                if len(unique_vals) == 2:
                     # Chequear si son 0/1, True/False, o dos números cualesquiera
                     is_numeric_or_bool = pd.api.types.is_numeric_dtype(self.df_original[col]) or pd.api.types.is_bool_dtype(self.df_original[col])
                     # Podríamos ser más estrictos y requerir 0/1
                     # is_01 = all(v in [0, 1] for v in unique_vals)
                     if is_numeric_or_bool:
                         binary_cols.append(col)

        self.dep_var_combo['values'] = [""] + binary_cols
        self.dependent_var.set("")

        self.indep_var_listbox.delete(0, tk.END)
        for col in cols:
            self.indep_var_listbox.insert(tk.END, col)

        self.log("Selectores de variables actualizados.", "DEBUG")

    def _validate_dependent_var(self, event=None):
        """Valida que la variable dependiente seleccionada sea binaria (0/1)."""
        dep_var_name = self.dependent_var.get()
        if not dep_var_name or self.df_original is None:
            return

        code_as_0 = self.code_as_0_var.get()
        code_as_1 = self.code_as_1_var.get()
        unique_vals = self.df_original[dep_var_name].dropna().unique()

        try:
            # Intentar convertir los valores únicos al tipo de la codificación
            unique_vals_conv = [type(eval(code_as_0))(v) for v in unique_vals]
            if not all(v in [eval(code_as_0), eval(code_as_1)] for v in unique_vals_conv) or len(unique_vals_conv) != 2:
                messagebox.showwarning("Variable Dependiente Inválida",
                                       f"La variable dependiente '{dep_var_name}' debe ser binaria y contener solo los valores {code_as_0} y {code_as_1}.")
                self.dependent_var.set("") # Limpiar selección
        except:
            messagebox.showwarning("Variable Dependiente Inválida",
                                   f"No se pudo validar la variable dependiente '{dep_var_name}' con la codificación especificada.")
            self.dependent_var.set("") # Limpiar selección

    def _run_logistic_regression(self):
        """Ejecuta el análisis de regresión logística."""
        self.results_text.config(state="normal")
        self.results_text.delete("1.0", tk.END)
        self.log("Iniciando análisis de Regresión Logística...", "INFO")

        if self.df_original is None:
            self.log("No hay datos cargados.", "ERROR")
            messagebox.showerror("Error", "No hay datos cargados para analizar.")
            self.results_text.config(state="disabled")
            return

        # Aplicar filtros
        if self.filter_component:
            try:
                self.df_filtered = self.filter_component.apply_filters()
                self.log(f"Datos filtrados: {self.df_filtered.shape}", "INFO")
            except Exception as e:
                self.log(f"Error al aplicar filtros: {e}", "ERROR")
                messagebox.showerror("Error de Filtro", f"Error al aplicar filtros:\n{e}")
                self.results_text.config(state="disabled")
                return
        else:
            self.df_filtered = self.df_original.copy()

        if self.df_filtered.empty:
            self.log("DataFrame vacío después de aplicar filtros.", "WARN")
            messagebox.showwarning("Datos Vacíos", "El DataFrame está vacío después de aplicar los filtros.")
            self.results_text.config(state="disabled")
            return

        # 2. Obtener variables seleccionadas
        dep_var = self.dependent_var.get()
        selected_indices = self.indep_var_listbox.curselection()
        indep_vars = [self.indep_var_listbox.get(i) for i in selected_indices]

        if not dep_var:
            self.log("Variable dependiente no seleccionada.", "ERROR")
            messagebox.showerror("Error", "Seleccione la variable dependiente.")
            self.results_text.config(state="disabled")
            return
        if not indep_vars:
            self.log("Variables independientes no seleccionadas.", "ERROR")
            messagebox.showerror("Error", "Seleccione al menos una variable independiente.")
            self.results_text.config(state="disabled")
            return
        if dep_var in indep_vars:
            self.log("Variable dependiente no puede ser independiente.", "ERROR")
            messagebox.showerror("Error", "La variable dependiente no puede estar en la lista de independientes.")
            self.results_text.config(state="disabled")
            return

        # 3. Preparar datos para statsmodels (manejar NaNs)
        cols_to_use = [dep_var] + indep_vars
        df_analysis = self.df_filtered[cols_to_use].dropna()

        if df_analysis.empty or len(df_analysis) < len(cols_to_use) + 1:
             self.log(f"Datos insuficientes después de eliminar NaNs (Filas: {len(df_analysis)}, Vars: {len(cols_to_use)}).", "ERROR")
             self.results_text.insert(tk.END, f"Datos insuficientes después de eliminar NaNs (Filas: {len(df_analysis)}). Se necesitan más filas que variables.")
             self.results_text.config(state="disabled")
             return

        # Recodificar la variable dependiente
        code_as_0 = self.code_as_0_var.get()
        code_as_1 = self.code_as_1_var.get()
        df_analysis[dep_var] = df_analysis[dep_var].apply(lambda x: 1 if str(x) == code_as_1 else 0)

        # Validar nuevamente la variable dependiente en los datos filtrados/limpios
        unique_deps = df_analysis[dep_var].unique()
        if not all(v in [0, 1] for v in unique_deps) or len(unique_deps) != 2:
             self.log(f"Variable dependiente '{dep_var}' no es binaria (0/1) en los datos de análisis.", "ERROR")
             self.results_text.insert(tk.END, f"Error: La variable dependiente '{dep_var}' no es binaria (0/1) en los datos usados para el análisis.")
             self.results_text.config(state="disabled")
             return

        self.log(f"Variables para modelo: Dep={dep_var}, Indep={indep_vars}", "INFO")
        self.log(f"Dimensiones datos análisis: {df_analysis.shape}", "INFO")

        # Contar casos de 0s y 1s en la variable dependiente
        case_counts = df_analysis[dep_var].value_counts()
        self.results_text.insert(tk.END, f"Casos de 0: {case_counts.get(0, 0)}\n")
        self.results_text.insert(tk.END, f"Casos de 1: {case_counts.get(1, 0)}\n\n")

        # 4. Construir fórmula y ajustar modelo
        try:
            # Crear fórmula para statsmodels (maneja variables categóricas automáticamente con C())
            # Asegurarse de que los nombres de variables sean válidos para fórmulas
            def quote_var(v):
                # Usar Q() para variables que no son identificadores válidos de Python
                # o que podrían entrar en conflicto con palabras clave de patsy.
                if not v.isidentifier() or v in ["C", "Q", "I"]:
                    return f"Q('{v}')"
                return v

            clean_dep_var = quote_var(dep_var)
            clean_indep_vars = [quote_var(v) for v in indep_vars]
            formula = f"{clean_dep_var} ~ {' + '.join(clean_indep_vars)}"
            self.log(f"Fórmula: {formula}", "DEBUG")

            # Usar Logit para regresión logística binaria
            if self.bootstrap_ci.get():
                n_bootstraps = self.bootstrap_cycles_var.get()
                np.random.seed(self.bootstrap_seed_var.get())

                boot_params = []
                for _ in range(n_bootstraps):
                    boot_sample = df_analysis.sample(n=len(df_analysis), replace=True)
                    boot_model = smf.logit(formula, data=boot_sample).fit(disp=0)
                    boot_params.append(boot_model.params)

                boot_params = pd.DataFrame(boot_params)

                # Calcular la media y los percentiles de los parámetros de arranque
                param_summary = boot_params.describe(percentiles=[0.025, 0.975])

                # Usar el modelo original para el resumen principal
                logit_model = smf.logit(formula, data=df_analysis)
                self.model_results = logit_model.fit()
                summary_str = str(self.model_results.summary()) + "\n\n--- Coeficientes de Bootstrap ---\n" + param_summary.to_string()
            else:
                logit_model = smf.logit(formula, data=df_analysis)
                self.model_results = logit_model.fit()
                summary_str = str(self.model_results.summary())
            self.results_text.insert(tk.END, summary_str)
            self.log("Modelo ajustado. Mostrando resumen básico.", "SUCCESS")

            # Calcular y mostrar Odds Ratios
            try:
                odds_ratios = pd.DataFrame({
                    "Odds Ratio": np.exp(self.model_results.params),
                    "IC 95% Inferior": np.exp(self.model_results.conf_int()[0]),
                    "IC 95% Superior": np.exp(self.model_results.conf_int()[1]),
                    "p-valor": self.model_results.pvalues
                })
                # Excluir intercepto si se desea
                # odds_ratios = odds_ratios.drop(index='Intercept')
                self.results_text.insert(tk.END, "\n\n--- Odds Ratios (exp(coef)) ---\n")
                self.results_text.insert(tk.END, odds_ratios.to_string(float_format="%.4f"))
                self.log("Odds Ratios calculados.", "INFO")
            except Exception as e_or:
                self.log(f"Error calculando Odds Ratios: {e_or}", "WARN")
                self.results_text.insert(tk.END, f"\n\nError calculando Odds Ratios: {e_or}")

            # --- Métricas de Evaluación Adicionales ---
            self.results_text.insert(tk.END, f"\n\n--- Métricas de Evaluación del Modelo ---\n")
            y_true = df_analysis[dep_var]
            y_pred_prob = self.model_results.predict(df_analysis[indep_vars]) # Probabilidades predichas

            # Pseudo R-cuadrado (McFadden)
            try:
                ll_full = self.model_results.llf
                ll_null = smf.logit(f"{clean_dep_var} ~ 1", data=df_analysis).fit(disp=0).llf
                pseudo_r2_mcfadden = 1 - (ll_full / ll_null)
                self.results_text.insert(tk.END, f"Pseudo R-cuadrado (McFadden): {pseudo_r2_mcfadden:.4f}\n")
                self.log(f"Pseudo R2 (McFadden): {pseudo_r2_mcfadden:.4f}", "INFO")
            except Exception as e_r2:
                self.log(f"Error calculando Pseudo R2: {e_r2}", "WARN")
                self.results_text.insert(tk.END, f"Pseudo R-cuadrado (McFadden): Error ({e_r2})\n")

            # Curva ROC y AUC
            try:
                fpr, tpr, thresholds_roc = roc_curve(y_true, y_pred_prob)
                roc_auc = auc(fpr, tpr)
                self.results_text.insert(tk.END, f"AUC (Area Under ROC Curve): {roc_auc:.4f}\n")
                self.log(f"AUC: {roc_auc:.4f}", "INFO")
                self._plot_roc_curve(fpr, tpr, roc_auc) # Mostrar gráfico ROC
            except Exception as e_roc:
                self.log(f"Error calculando/plotando ROC/AUC: {e_roc}", "WARN")
                self.results_text.insert(tk.END, f"AUC: Error ({e_roc})\n")

            # Tabla de Clasificación y Métricas Relacionadas (usando umbral 0.5)
            try:
                threshold = 0.5
                y_pred_class = (y_pred_prob >= threshold).astype(int)
                cm = confusion_matrix(y_true, y_pred_class)
                self.results_text.insert(tk.END, f"\n--- Tabla de Clasificación (umbral={threshold}) ---\n")
                self.results_text.insert(tk.END, f"Verdaderos Negativos (VN): {cm[0,0]}\n")
                self.results_text.insert(tk.END, f"Falsos Positivos   (FP): {cm[0,1]}\n")
                self.results_text.insert(tk.END, f"Falsos Negativos   (FN): {cm[1,0]}\n")
                self.results_text.insert(tk.END, f"Verdaderos Positivos (VP): {cm[1,1]}\n\n")

                report = classification_report(y_true, y_pred_class, target_names=['Clase 0', 'Clase 1'], zero_division=0)
                self.results_text.insert(tk.END, "Reporte de Clasificación:\n")
                self.results_text.insert(tk.END, report + "\n")
                self.log("Tabla de clasificación y reporte generados.", "INFO")
            except Exception as e_cm:
                self.log(f"Error generando tabla de clasificación: {e_cm}", "WARN")
                self.results_text.insert(tk.END, f"Tabla de Clasificación: Error ({e_cm})\n")

            # Prueba de Hosmer-Lemeshow (Cálculo manual simplificado)
            try:
                hl_stat, hl_p_value = self._hosmer_lemeshow_test(y_true, y_pred_prob)
                self.results_text.insert(tk.END, f"\n--- Prueba de Hosmer-Lemeshow ---\n")
                self.results_text.insert(tk.END, f"Estadístico H-L: {hl_stat:.4f}\n")
                self.results_text.insert(tk.END, f"p-valor H-L: {hl_p_value:.4f}\n")
                interpretation = "Buen ajuste (p > 0.05)" if hl_p_value > 0.05 else "Pobre ajuste (p <= 0.05)"
                self.results_text.insert(tk.END, f"Interpretación: {interpretation}\n")
                self.log(f"Hosmer-Lemeshow: stat={hl_stat:.4f}, p={hl_p_value:.4f}", "INFO")
            except Exception as e_hl:
                self.log(f"Error calculando Hosmer-Lemeshow: {e_hl}", "WARN")
                self.results_text.insert(tk.END, f"Prueba de Hosmer-Lemeshow: Error ({e_hl})\n")

            # Generar gráficos de riesgo vs. covariables
            try:
                self._plot_risk_vs_covariates(df_analysis, indep_vars, y_pred_prob)
            except Exception as e_risk_plot:
                self.log(f"Error generando gráficos de riesgo: {e_risk_plot}", "WARN")

        except Exception as e:
            self.log(f"Error al ajustar el modelo logístico: {e}", "ERROR")
            self.results_text.insert(tk.END, f"Error al ajustar el modelo:\n{e}\n{traceback.format_exc()}")
            messagebox.showerror("Error de Modelo", f"Error al ajustar el modelo logístico:\n{e}")

        finally:
            self.results_text.config(state="disabled")

    def log(self, message, level="INFO"):
        """Placeholder para logging."""
        print(f"[{level}] LogisticRegTab: {message}")

    def _hosmer_lemeshow_test(self, y_true, y_pred_prob, g=10):
        """
        Calcula la prueba de Hosmer-Lemeshow.
        :param y_true: Serie de valores verdaderos (0 o 1).
        :param y_pred_prob: Serie de probabilidades predichas.
        :param g: Número de grupos (deciles por defecto).
        :return: (estadístico chi-cuadrado, p-valor)
        """
        y_true = np.array(y_true)
        y_pred_prob = np.array(y_pred_prob)

        # Ordenar por probabilidad predicha
        sorted_indices = np.argsort(y_pred_prob)
        y_true_sorted = y_true[sorted_indices]
        y_pred_prob_sorted = y_pred_prob[sorted_indices]

        # Crear grupos
        groups = np.array_split(np.arange(len(y_true_sorted)), g)

        observed_1 = []
        expected_1 = []
        observed_0 = []
        expected_0 = []
        group_size = []

        for group_indices in groups:
            if len(group_indices) == 0:
                continue

            obs_1_g = np.sum(y_true_sorted[group_indices])
            exp_1_g = np.sum(y_pred_prob_sorted[group_indices])

            obs_0_g = len(group_indices) - obs_1_g
            exp_0_g = len(group_indices) - exp_1_g

            # Evitar división por cero si un grupo esperado es 0 (aunque raro con probs)
            if exp_1_g == 0 and obs_1_g != 0: exp_1_g = 1e-9 # Pequeño valor para evitar error
            if exp_0_g == 0 and obs_0_g != 0: exp_0_g = 1e-9

            observed_1.append(obs_1_g)
            expected_1.append(exp_1_g)
            observed_0.append(obs_0_g)
            expected_0.append(exp_0_g)
            group_size.append(len(group_indices))

        # Calcular estadístico Chi-cuadrado
        hl_stat = 0
        for i in range(len(observed_1)):
            if expected_1[i] > 0: # Evitar división por cero
                 hl_stat += ((observed_1[i] - expected_1[i])**2) / expected_1[i]
            if expected_0[i] > 0: # Evitar división por cero
                 hl_stat += ((observed_0[i] - expected_0[i])**2) / expected_0[i]

        # Grados de libertad (g - 2 es común, pero puede variar)
        # Para una prueba más robusta, se podría usar g - k donde k es el número de
        # patrones de covarianza distintos si se agrupa por ellos, o g-2 si se agrupa por deciles de riesgo.
        # Aquí usamos g-2 como aproximación común para deciles.
        df_hl = max(1, g - 2)
        p_value = stats.chi2.sf(hl_stat, df_hl)

        return hl_stat, p_value

    def _plot_roc_curve(self, fpr, tpr, roc_auc):
        """Genera y muestra el gráfico de la curva ROC en una nueva pestaña del Notebook."""
        if self.roc_plot_frame:
            for widget in self.roc_plot_frame.winfo_children():
                widget.destroy()
        else:
            self.roc_plot_frame = ttk.Frame(self.results_notebook)
            self.results_notebook.add(self.roc_plot_frame, text="Curva ROC")

        plt.rcParams['font.family'] = self.font_family_var.get()
        fig, ax = plt.subplots(figsize=(6, 5)) # Ajustar tamaño según sea necesario
        ax.plot(fpr, tpr, color=self.line_color.get(), lw=2, label=f'Curva ROC (AUC = {roc_auc:.2f})')
        ax.plot([0, 1], [0, 1], color=self.marker_color.get(), lw=2, linestyle='--')
        ax.set_xlim([0.0, 1.0])
        ax.set_ylim([0.0, 1.05])
        ax.set_xlabel(self.xlabel_var.get(), fontsize=self.font_size_var.get())
        ax.set_ylabel(self.ylabel_var.get(), fontsize=self.font_size_var.get())
        ax.set_title("Curva ROC", fontsize=self.font_size_var.get() + 2)
        ax.legend(loc="lower right")
        if self.grid_on.get():
            ax.grid(True, linestyle=':', alpha=0.7)
        else:
            ax.grid(False)
        plt.xticks(fontsize=self.font_size_var.get())
        plt.yticks(fontsize=self.font_size_var.get())
        fig.tight_layout()

        canvas = FigureCanvasTkAgg(fig, master=self.roc_plot_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        # Asegurarse de que la pestaña ROC sea visible
        try:
            self.results_notebook.select(self.roc_plot_frame)
        except tk.TclError: # Puede ocurrir si la pestaña ya está seleccionada o el notebook no está visible
            pass
        self.log("Curva ROC generada.", "INFO")

    def _clear_covariate_plots(self):
        """Cierra todas las pestañas de gráficos de covariables."""
        for i in reversed(range(self.results_notebook.index('end'))):
            tab_text = self.results_notebook.tab(i, "text")
            if tab_text.startswith("Riesgo vs"):
                self.results_notebook.forget(i)

    def _plot_risk_vs_covariates(self, df_analysis, indep_vars, y_pred_prob):
        """Genera y muestra gráficos de riesgo vs. covariables."""
        self._clear_covariate_plots()

        if self.normalize_vars.get():
            # Normalizar las covariables seleccionadas y trazarlas en un solo gráfico
            covariate_plot_frame = ttk.Frame(self.results_notebook)
            self.results_notebook.add(covariate_plot_frame, text="Riesgo vs Covariables Normalizadas")
            plt.rcParams['font.family'] = self.font_family_var.get()
            fig, ax = plt.subplots(figsize=(6, 5))

            for var in indep_vars:
                # Normalizar la covariable a un rango de 0-1
                normalized_var = (df_analysis[var] - df_analysis[var].min()) / (df_analysis[var].max() - df_analysis[var].min())
                sorted_indices = np.argsort(normalized_var)
                ax.plot(normalized_var.iloc[sorted_indices], y_pred_prob.iloc[sorted_indices], label=var)

            ax.set_xlabel(self.xlabel_var.get() if self.xlabel_var.get() else "Covariable Normalizada", fontsize=self.font_size_var.get())
            ax.set_ylabel(self.ylabel_var.get() if self.ylabel_var.get() else "Riesgo Predicho (Probabilidad)", fontsize=self.font_size_var.get())
            ax.set_title(self.title_var.get() if self.title_var.get() else "Riesgo vs Covariables Normalizadas", fontsize=self.font_size_var.get() + 2)
            ax.legend()
            if self.grid_on.get():
                ax.grid(True, linestyle=':', alpha=0.7)
            else:
                ax.grid(False)
            plt.xticks(fontsize=self.font_size_var.get())
            plt.yticks(fontsize=self.font_size_var.get())
            fig.tight_layout()

            canvas = FigureCanvasTkAgg(fig, master=covariate_plot_frame)
            canvas.draw()
            canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)
            self.log("Gráfico de riesgo vs. covariables normalizadas generado.", "INFO")
        else:
            # Trazar cada covariable en un gráfico separado
            for var in indep_vars:
                covariate_plot_frame = ttk.Frame(self.results_notebook)
                self.results_notebook.add(covariate_plot_frame, text=f"Riesgo vs {var}")

                plt.rcParams['font.family'] = self.font_family_var.get()
                fig, ax = plt.subplots(figsize=(6, 5))
                # Generar una secuencia de valores para la covariable para un gráfico más suave
                x_range = np.linspace(df_analysis[var].min(), df_analysis[var].max(), 200)

                # Crear un DataFrame para la predicción. Todas las demás covariables se mantienen en su media.
                pred_df = pd.DataFrame({var: x_range})
                for other_var in indep_vars:
                    if other_var != var:
                        pred_df[other_var] = df_analysis[other_var].mean()

                pred_prob = self.model_results.predict(pred_df)

                ax.plot(x_range, pred_prob, color=self.line_color.get(), linestyle='-')

                if self.show_ci.get():
                    if self.bootstrap_ci.get():
                        # Calcular IC de bootstrap para la gráfica
                        boot_preds = []
                        n_bootstraps = self.bootstrap_cycles_var.get()
                        np.random.seed(self.bootstrap_seed_var.get())
                        for _ in range(n_bootstraps):
                            boot_sample = df_analysis.sample(n=len(df_analysis), replace=True)
                            boot_model = smf.logit(formula, data=boot_sample).fit(disp=0)
                            boot_preds.append(boot_model.predict(pred_df))

                        boot_preds = np.array(boot_preds)
                        ci_lower = np.percentile(boot_preds, 2.5, axis=0)
                        ci_upper = np.percentile(boot_preds, 97.5, axis=0)
                        ax.fill_between(x_range, ci_lower, ci_upper, color='gray', alpha=0.2)
                    else:
                        # Usar IC por defecto del modelo
                        risk_pred = self.model_results.get_prediction(pred_df)
                        ci = risk_pred.summary_frame(alpha=0.05)
                        ax.fill_between(x_range, ci['ci_lower'], ci['ci_upper'], color='gray', alpha=0.2)
                ax.set_xlabel(self.xlabel_var.get() if self.xlabel_var.get() else var, fontsize=self.font_size_var.get())
                ax.set_ylabel(self.ylabel_var.get() if self.ylabel_var.get() else "Riesgo Predicho (Probabilidad)", fontsize=self.font_size_var.get())
                ax.set_title(self.title_var.get() if self.title_var.get() else f"Riesgo Predicho vs. {var}", fontsize=self.font_size_var.get() + 2)
                if self.grid_on.get():
                    ax.grid(True, linestyle=':', alpha=0.7)
                else:
                    ax.grid(False)
                plt.xticks(fontsize=self.font_size_var.get())
                plt.yticks(fontsize=self.font_size_var.get())
                fig.tight_layout()

                canvas = FigureCanvasTkAgg(fig, master=covariate_plot_frame)
                canvas.draw()
                canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)
                self.log(f"Gráfico de riesgo vs. {var} generado.", "INFO")

    def _calculate_risk_point(self):
        """Calcula el valor de la covariable para un riesgo dado y lo muestra."""
        if not self.model_results:
            messagebox.showerror("Error", "Primero debe ajustar un modelo.")
            return

        try:
            risk_percent = self.risk_percent_var.get()
            if not (0 < risk_percent < 100):
                messagebox.showerror("Error", "El riesgo debe estar entre 0 y 100.")
                return

            risk_prob = risk_percent / 100.0
            log_odds = np.log(risk_prob / (1 - risk_prob))

            # Asumimos un modelo con una sola covariable por simplicidad en esta implementación
            if len(self.model_results.params) == 2:
                intercept, slope = self.model_results.params
                covariate_val = (log_odds - intercept) / slope

                # Calcular el intervalo de confianza para el valor de la covariable
                cov_matrix = self.model_results.cov_params()
                var_intercept = cov_matrix.iloc[0, 0]
                var_slope = cov_matrix.iloc[1, 1]
                cov_intercept_slope = cov_matrix.iloc[0, 1]

                # Propagación de errores para log_odds = intercept + slope * x
                # var(x) = (1/slope^2) * [var(log_odds) + var(intercept) - 2*cov(log_odds, intercept)]
                # Asumimos que log_odds es una constante, por lo que var(log_odds) = 0
                # var(x) = (1/slope^2) * [var(intercept) - 2*cov(log_odds, intercept)]
                # Esto es una simplificación. Un enfoque más robusto usaría el método delta.
                # Simplificando aún más, y reconociendo que no es exacto:
                se_log_odds = np.sqrt(var_intercept + (covariate_val**2 * var_slope) + (2 * covariate_val * cov_intercept_slope))

                log_odds_lower = log_odds - 1.96 * se_log_odds
                log_odds_upper = log_odds + 1.96 * se_log_odds

                covariate_val_lower = (log_odds_lower - intercept) / slope
                covariate_val_upper = (log_odds_upper - intercept) / slope

                # Mostrar en el resumen
                self.results_text.config(state="normal")
                self.results_text.insert(tk.END, f"\n\n--- Punto de Riesgo ({risk_percent}%) ---\n")
                self.results_text.insert(tk.END, f"Para alcanzar un riesgo del {risk_percent}%, el valor de la covariable debe ser: {covariate_val:.4f}\n")
                self.results_text.insert(tk.END, f"Intervalo de confianza del 95% para el valor de la covariable: ({min(covariate_val_lower, covariate_val_upper):.4f}, {max(covariate_val_lower, covariate_val_upper):.4f})\n")
                self.results_text.config(state="disabled")

                # Marcar en la gráfica (si existe)
                for i in reversed(range(self.results_notebook.index('end'))):
                    tab_text = self.results_notebook.tab(i, "text")
                    if tab_text.startswith("Riesgo vs"):
                        frame = self.results_notebook.nametowidget(self.results_notebook.tabs()[i])
                        canvas = frame.winfo_children()[0]
                        fig = canvas.figure
                        ax = fig.axes[0]
                        ax.axhline(y=risk_prob, color='r', linestyle='--')
                        ax.axvline(x=covariate_val, color='r', linestyle='--')
                        canvas.draw()
            else:
                messagebox.showinfo("Información", "El cálculo del punto de riesgo solo está implementado para modelos con una sola covariable.")

        except Exception as e:
            messagebox.showerror("Error", f"No se pudo calcular el punto de riesgo:\n{e}")

    def _calculate_specific_risk(self):
        """Calcula el riesgo para un conjunto de valores de covariables."""
        if not self.model_results:
            messagebox.showerror("Error", "Primero debe ajustar un modelo.")
            return

        try:
            covariate_values_str = self.covariate_values_var.get()
            if not covariate_values_str:
                messagebox.showerror("Error", "Ingrese los valores de las covariables.")
                return

            values = [float(v.strip()) for v in covariate_values_str.split(',')]

            indep_vars_sorted = sorted(self.model_results.params.index[1:])
            if len(values) != len(indep_vars_sorted):
                messagebox.showerror("Error", f"Debe ingresar {len(indep_vars_sorted)} valores de covariables en el orden: {', '.join(indep_vars_sorted)}")
                return

            # Crear un DataFrame para la predicción
            pred_df = pd.DataFrame([values], columns=indep_vars_sorted)

            # Calcular el riesgo y el intervalo de confianza
            risk_pred = self.model_results.get_prediction(pred_df)
            risk_summary = risk_pred.summary_frame(alpha=0.05)

            # Mostrar en el resumen
            self.results_text.config(state="normal")
            self.results_text.insert(tk.END, f"\n\n--- Riesgo Específico ---\n")
            self.results_text.insert(tk.END, f"Para los valores de covariables {values}, el riesgo predicho es:\n")
            self.results_text.insert(tk.END, risk_summary.to_string(float_format="%.4f"))
            self.results_text.config(state="disabled")

        except Exception as e:
            messagebox.showerror("Error", f"No se pudo calcular el riesgo específico:\n{e}")

# --- Ejemplo de uso ---
if __name__ == '__main__':
    root = tk.Tk()
    root.title("Test Logistic Regression Tab")
    root.geometry("900x600")

    # Crear datos de ejemplo para logística
    np.random.seed(42)
    n_samples = 200
    X1 = np.random.rand(n_samples) * 10
    X2 = np.random.choice(['G1', 'G2', 'G3'], n_samples)
    X3_cont = np.random.randn(n_samples) * 5 + 20
    # Crear log-odds lineal
    log_odds = -2 + 0.5 * X1 + (X2 == 'G2') * 1.0 + (X2 == 'G3') * 1.5 - 0.1 * X3_cont
    # Convertir a probabilidad
    prob = 1 / (1 + np.exp(-log_odds))
    # Generar variable dependiente binaria
    Y = (np.random.rand(n_samples) < prob).astype(int)

    sample_df_log = pd.DataFrame({
        'Target': Y,
        'PredictorContinuo': X1,
        'PredictorCategorico': X2,
        'OtraNumerica': X3_cont,
        'ID_Sujeto': range(n_samples)
    })
    # Introducir algunos NaNs
    sample_df_log.loc[::15, 'PredictorContinuo'] = np.nan
    sample_df_log.loc[::20, 'PredictorCategorico'] = np.nan

    # Frame principal
    main_frame = ttk.Frame(root, padding="10")
    main_frame.pack(fill="both", expand=True)

    # Instanciar la pestaña
    logreg_tab = LogisticRegressionTab(main_frame)
    logreg_tab.pack(fill="both", expand=True)

    # Cargar datos de ejemplo en la pestaña (simulando clic de botón)
    logreg_tab.df_original = sample_df_log
    logreg_tab.filepath_var.set("sample_logistic_data.df") # Simular carga
    logreg_tab._update_variable_selectors()
    if hasattr(logreg_tab, 'filter_component') and logreg_tab.filter_component:
        logreg_tab.filter_component.set_dataframe(sample_df_log)

    root.mainloop()
