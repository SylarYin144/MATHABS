#!/usr/bin/env python
# -*- coding: utf-8 -*-
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog, StringVar
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import seaborn as sns
import squarify
import scipy.stats as stats
import numpy as np
import os # <--- AÑADIDO
import traceback
import csv # <--- AÑADIDO
import matplotlib.font_manager as fm
from matplotlib.collections import PolyCollection
from matplotlib.lines import Line2D
import matplotlib.colors as mcolors
import matplotlib.ticker as mticker
from pandas.api.types import is_categorical_dtype
from MATLAB_filter_component import FilterComponent
# Otros imports necesarios para gráficos específicos se añadirán después

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk

def _is_number_and_between(v, lo, hi):
    try:
        vv = float(v)
        return vv >= lo and vv <= hi
    except Exception:
        return False

class GeneralChartsApp(ttk.Frame):
    def __init__(self, parent, main_app_instance=None): # main_app_instance para acceder a datos/logs globales si es necesario
        super().__init__(parent)
        self.parent_for_dialogs = parent
        self.main_app = main_app_instance # Referencia a la aplicación principal
        self.data = None # DataFrame actual
        self.shared_dataset_metadata = {}
        self.current_shared_filter_summary = []
        # Load chart descriptions if the method exists (defensive: avoid AttributeError during import)
        try:
            if hasattr(self, 'load_chart_descriptions'):
                self.chart_descriptions = self.load_chart_descriptions()
            else:
                self.chart_descriptions = {}
        except Exception:
            self.chart_descriptions = {}
        self.color_options = ["blue", "green", "red", "skyblue", "orange", "purple",
                               "black", "gray", "brown", "pink", "cyan", "magenta",
                               "teal", "olive", "navy", "maroon", "lime", "gold"]
        self.param_dist_group_color_map = {}
        self.param_dist_category_color_map = {}

        # --- UI Principal de la Pestaña ---
        main_paned_window = ttk.PanedWindow(self, orient=tk.HORIZONTAL)
        main_paned_window.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Panel de Controles (Izquierda) con Scroll
        left_panel_container = ttk.Frame(main_paned_window)
        main_paned_window.add(left_panel_container, weight=1)

        canvas = tk.Canvas(left_panel_container)
        scrollbar = ttk.Scrollbar(left_panel_container, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(
                scrollregion=canvas.bbox("all")
            )
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        controls_panel = ttk.LabelFrame(scrollable_frame, text="Controles de Gráfico", padding="10")
        controls_panel.pack(fill=tk.BOTH, expand=True)

        # Panel de Visualización (Derecha)
        display_panel = ttk.Frame(main_paned_window)
        main_paned_window.add(display_panel, weight=3)

        # --- Controles ---
        ttk.Label(controls_panel, text="Tipo de Gráfico:").pack(pady=(0,2), anchor="w")
        self.chart_type_var = StringVar()
        self.chart_types = [
            "Gráfico de Barras",
            "Gráfico de Distribución", # Reemplaza Caja, Violín, Puntos, Swarm
            "Gráfico de Líneas / Área",
            "Gráfico Circular / Anillo",
            "Diagrama de Dispersión",
            "Gráfico de Pirámide",
            "Gráfico Radial",
            "Gráfico de Bala",
            "Gráfico Lollipop",
            "Histograma",
            "Gráfico de Densidad",
            "Diagrama de Tallo y Hojas",
            "Mapa de Calor",
            "Correlograma",
            "Gráfico de Coordenadas Paralelas",
            "Diagrama de Venn",
            "Diagrama de Euler",
            "Mapa de Árbol",
            "Diagrama Sunburst",
            "Diagrama de Marimekko",
            "Dendrograma",
            "Diagrama de Sankey",
            "Diagrama de Cuerdas",
            "Diagrama de Flujo",
            "Gráfico de Cascada",
            "Gráfico de Embudo",
            "Diagrama de Gantt",
            "Diagrama de Arco",
            "Gráfico de Flujo",
            "Gráfico de Velas",
            "Línea de Tiempo",
            "Diagrama Espiral",
            "Mapa Coroplético",
            "Mapa de Burbujas",
            "Mapa de Puntos",
            "Mapa de Conexiones",
            "Cartograma",
        ]
        self.chart_type_combo = ttk.Combobox(controls_panel, textvariable=self.chart_type_var, values=self.chart_types, state="readonly", width=30)
        self.chart_type_combo.pack(pady=(0,10), fill="x")
        # defer lookup of the handler until the event triggers to avoid AttributeError
        self.chart_type_combo.bind("<<ComboboxSelected>>", lambda e: self._safe_call('_update_parameter_controls', e))

        # Panel de Filtros
        filters_panel = ttk.LabelFrame(controls_panel, text="Filtros", padding="10")
        filters_panel.pack(fill="x", expand=True, pady=(10,0))
        self.filter_component = FilterComponent(filters_panel)
        self.filter_component.pack(fill="x", expand=True)

        self.parameter_controls_frame = ttk.Frame(controls_panel)
        self.parameter_controls_frame.pack(fill="x", expand=True, pady=(0,10))

        ttk.Button(controls_panel, text="Generar Gráfico", command=lambda: self._safe_call('_generate_chart')).pack(pady=10, fill="x")
        ttk.Button(controls_panel, text="Cargar Datos (Excel/CSV)", command=lambda: self._safe_call('cargar_datos_para_graficos')).pack(pady=5, fill="x")
    # example data button removed per user's request
        self.lbl_data_status = ttk.Label(controls_panel, text="Ningún archivo cargado.")
        self.lbl_data_status.pack(pady=(5,0), anchor="w")


        # --- Área de Visualización del Gráfico ---
        self.chart_display_frame = ttk.LabelFrame(display_panel, text="Visualización del Gráfico", padding="5")
        self.chart_display_frame.pack(fill=tk.BOTH, expand=True)

        # --- Log ---
        log_frame = ttk.LabelFrame(display_panel, text="Información del Gráfico y Log", height=150)
        log_frame.pack(fill=tk.X, pady=(10,0))
        log_frame.pack_propagate(False) # Evitar que se encoja

        self.log_text_widget = tk.Text(log_frame, height=8, wrap=tk.WORD, state=tk.DISABLED, font=("Courier New", 9))
        log_scroll_y = ttk.Scrollbar(log_frame, orient=tk.VERTICAL, command=self.log_text_widget.yview)
        self.log_text_widget.config(yscrollcommand=log_scroll_y.set)
        log_scroll_y.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=2, pady=2)
        self._configure_log_tags()

        self.log("Pestaña 'Gráficas' inicializada. Seleccione un tipo de gráfico y cargue datos.", "INFO")

    def _configure_log_tags(self):
        self.log_text_widget.tag_config("INFO", foreground="black")
        self.log_text_widget.tag_config("DEBUG", foreground="gray")
        self.log_text_widget.tag_config("WARN", foreground="orange")
        self.log_text_widget.tag_config("ERROR", foreground="red", font=("Courier New", 9, "bold"))
        self.log_text_widget.tag_config("SUCCESS", foreground="green")
        self.log_text_widget.tag_config("DESC", foreground="navy", font=("Courier New", 9, "bold"))
        self.log_text_widget.tag_config("PARAMS", foreground="purple")
        self.log_text_widget.tag_config("RECOM", foreground="darkgreen")

    def log(self, message, level="INFO"):
        try:
            timestamp = pd.Timestamp.now().strftime('%H:%M:%S.%f')[:-3]
            self.log_text_widget.config(state=tk.NORMAL)
            self.log_text_widget.insert(tk.END, f"[{timestamp}] [{level.upper()}] {message}\n", level.upper())
            self.log_text_widget.config(state=tk.DISABLED)
            self.log_text_widget.see(tk.END)
        except Exception as e:
            print(f"Error en logger de GeneralChartsApp: {e}")

    def _safe_call(self, name, *args, **kwargs):
        """Call a method by name safely from Tk callbacks. Logs and shows an error if missing or if the call fails."""
        func = getattr(self, name, None)

        if not callable(func):
            msg = f"Función no encontrada: {name}"
            self.log(msg, "ERROR")
            try:
                messagebox.showerror("Error Interno", msg, parent=self.parent_for_dialogs)
            except Exception:
                pass
            return None
        try:
            return func(*args, **kwargs)
        except Exception as e:
            self.log(f"Error ejecutando {name}: {e}", "ERROR")
            import traceback
            self.log(traceback.format_exc(), "DEBUG")
            try:
                messagebox.showerror("Error", f"Error ejecutando {name}: {e}", parent=self.parent_for_dialogs)
            except Exception:
                pass
            return None

    def _create_variable_selector(self, parent_frame, label_text, columns_list, default_value="", allow_recode=False):
        label_widget = ttk.Label(parent_frame, text=label_text)
        label_widget.pack(anchor="w")
        
        var_frame = ttk.Frame(parent_frame)
        var_frame.pack(fill="x", pady=(0,5))

        # Variable to hold the selected column name
        selected_col_var = StringVar(value=default_value)
        selector_combo = ttk.Combobox(var_frame, textvariable=selected_col_var, values=columns_list, state="readonly")
        selector_combo.pack(side=tk.LEFT, expand=True, fill="x")

        # Variable to hold the display name for this specific parameter
        display_name_var = StringVar(value=default_value) # Default to selected column name
        display_entry = ttk.Entry(var_frame, textvariable=display_name_var, width=15)
        display_entry.pack(side=tk.RIGHT)

        recode_var = None
        if allow_recode:
            recode_frame = ttk.Frame(parent_frame)
            recode_frame.pack(fill="x", pady=(0, 5))
            ttk.Label(recode_frame, text="Decodificación y Orden (e.g., 1:Leve, 2:Moderado):").pack(anchor="w")
            recode_var = StringVar()
            recode_entry = ttk.Entry(recode_frame, textvariable=recode_var)
            recode_entry.pack(fill="x")
            # Button to preview recoding
            ttk.Button(recode_frame, text="Probar recodificación", command=lambda sv=selected_col_var, rv=recode_var: self._test_recode(sv, rv)).pack(anchor="e", pady=(3,0))
            setattr(recode_var, "_widget_frame", recode_frame)
        else:
            recode_frame = None
        
        setattr(selected_col_var, "_label_widget", label_widget)
        setattr(selected_col_var, "_widget_frame", var_frame)
        setattr(selected_col_var, "_selector_widget", selector_combo)
        setattr(selected_col_var, "_display_entry", display_entry)
        setattr(selected_col_var, "_recode_var", recode_var)
        if recode_var is not None:
            setattr(recode_var, "_label_widget", None)
            setattr(recode_var, "_entry_widget", recode_entry)
            setattr(recode_var, "_parent_selector", selected_col_var)
        setattr(selected_col_var, "_recode_frame", recode_frame)

        return selected_col_var, display_name_var, recode_var

    def _apply_recode(self, df, column, recode_str):
        if not recode_str or not column:
            return df

        try:
            self.log(f"Iniciando decodificación para la columna '{column}'.", "DEBUG")
            self.log(f"Cadena de decodificación recibida: '{recode_str}'", "DEBUG")

            df = df.copy()

            # Parse recode_str into ordered rules supporting single keys, multiple keys
            # separated by '|' or '/', and numeric ranges like '1-3'. Each rule is
            # (matcher_func, label). We'll apply rules in order; first match wins.
            pairs = [p.strip() for p in recode_str.split(',') if p.strip()]
            rules = []
            order = []
            for pair in pairs:
                if ':' not in pair:
                    continue
                left, label = pair.split(':', 1)
                label = label.strip()
                left = left.strip()
                if not label:
                    continue
                order.append(label)

                # support multiple tokens separated by '|' or '/'
                tokens = []
                if '|' in left:
                    tokens = [t.strip() for t in left.split('|') if t.strip()]
                elif '/' in left:
                    tokens = [t.strip() for t in left.split('/') if t.strip()]
                else:
                    tokens = [left]

                # build matchers from tokens
                for tok in tokens:
                    # range like 1-3
                    if '-' in tok:
                        parts = tok.split('-', 1)
                        try:
                            lo = float(parts[0].strip())
                            hi = float(parts[1].strip())
                            def make_range(lo, hi):
                                return lambda v: (not pd.isna(v)) and _is_number_and_between(v, lo, hi)
                            rules.append((make_range(lo, hi), label, f"{lo}-{hi}"))
                        except Exception:
                            # fallback to literal
                            rules.append((lambda v, t=tok: str(v).strip() == t, label, tok))
                    else:
                        # single token matcher: match numeric or string equivalently
                        def make_tok_match(t):
                            def match(v):
                                if pd.isna(v):
                                    return False
                                # try numeric compare
                                try:
                                    tnum = float(t)
                                    try:
                                        vnum = float(v)
                                        return vnum == tnum
                                    except Exception:
                                        pass
                                except Exception:
                                    pass
                                # otherwise string compare
                                try:
                                    return str(v).strip() == t
                                except Exception:
                                    return False
                            return match
                        rules.append((make_tok_match(tok), label, tok))

            if not rules:
                self.log("El mapa de decodificación está vacío o mal formado. No se aplicarán cambios.", "DEBUG")
                return df

            self.log(f"Reglas de decodificación creadas: {[r[2] for r in rules]}", "DEBUG")
            col_series = df[column]
            original_unique = col_series.unique()
            self.log(f"Valores únicos en '{column}' ANTES de decodificar: {original_unique}", "DEBUG")

            # Apply rules in order to produce mapped values (without altering original df until success)
            def apply_rules_to_value(v):
                for matcher, label, _desc in rules:
                    try:
                        if matcher(v):
                            return label
                    except Exception:
                        continue
                # no rule matched -> return original value as string
                try:
                    return str(v)
                except Exception:
                    return v

            try:
                mapped = col_series.map(lambda v: apply_rules_to_value(v))
            except Exception:
                # fallback: cast to str and do simple replacement
                mapped = col_series.astype(str).map(lambda v: apply_rules_to_value(v))

            # Convert to categorical with provided order (labels order)
            try:
                if order:
                    mapped = pd.Categorical(mapped, categories=order, ordered=True)
            except Exception:
                pass

            df = df.copy()
            df[column] = mapped

            self.log(f"Columna '{column}' dtype después de categorizar: {df[column].dtype}", "DEBUG")

            final_unique = df[column].unique()
            self.log(f"Valores únicos en '{column}' DESPUÉS de categorizar: {final_unique}", "DEBUG")

            # Warn about NaNs which may indicate unmatched keys
            if df[column].isnull().any():
                self.log(f"¡Atención! Se encontraron valores nulos en '{column}' después de la decodificación. "
                         f"Esto puede ocurrir si algunos valores originales no estaban en las reglas de decodificación: {recode_str}", "WARN")

            self.log(f"Columna '{column}' recodificada y ordenada.", "INFO")
            return df

        except Exception as e:
            self.log(f"Error al decodificar la columna '{column}': {e}", "ERROR")
            import traceback
            self.log(traceback.format_exc(), "DEBUG")
            return df

    def _test_recode(self, selected_col_var, recode_var):
        """Show a preview dialog of how recoding will map the unique values of the column."""
        try:
            if self.data is None:
                messagebox.showinfo("Sin Datos", "Cargue datos antes de probar la recodificación.", parent=self.parent_for_dialogs)
                return
            col_name = selected_col_var.get()
            if not col_name:
                messagebox.showinfo("Sin Columna", "Seleccione primero la columna a recodificar.", parent=self.parent_for_dialogs)
                return
            recode_str = recode_var.get()
            if not recode_str:
                messagebox.showinfo("Sin Regla", "Ingrese una cadena de recodificación antes de probar.", parent=self.parent_for_dialogs)
                return

            unique_vals = list(self.data[col_name].dropna().unique())

            # Reuse _apply_recode on a small DataFrame copy to compute mapped values safely
            sample_df = pd.DataFrame({col_name: unique_vals})
            preview_df = self._apply_recode(sample_df, col_name, recode_str)

            # Build dialog showing original -> mapped
            dlg = tk.Toplevel(self)
            dlg.title(f"Previsualizar recodificación: {col_name}")
            dlg.transient(self.parent_for_dialogs)
            dlg.grab_set()

            frame = ttk.Frame(dlg, padding=8)
            frame.pack(fill='both', expand=True)
            ttk.Label(frame, text=f"Columna: {col_name}").pack(anchor='w')

            tree = ttk.Treeview(frame, columns=('original', 'mapped'), show='headings', height=12)
            tree.heading('original', text='Original')
            tree.heading('mapped', text='Mapeado')
            tree.column('original', width=200)
            tree.column('mapped', width=200)
            tree.pack(fill='both', expand=True, pady=(4,8))

            for orig, mapped in zip(unique_vals, preview_df[col_name].tolist()):
                tree.insert('', 'end', values=(str(orig), str(mapped)))

            btn_frame = ttk.Frame(frame)
            btn_frame.pack(fill='x')
            ttk.Button(btn_frame, text='Cerrar', command=lambda: (dlg.grab_release(), dlg.destroy())).pack(side='right')

        except Exception as e:
            self.log(f"Error en previsualizar recodificación: {e}", 'ERROR')
            messagebox.showerror("Error", f"No se pudo previsualizar la recodificación: {e}", parent=self.parent_for_dialogs)


    def _open_group_color_picker(self):
        """Open a small dialog to pick colors per level for the selected hue variable."""
        try:
            hue_var = getattr(self, 'param_dist_hue_var', None)
            hue_name = hue_var.get() if hue_var else ''
            target_name = None
            target_attr = 'param_dist_group_color_map'

            if hue_name:
                target_name = hue_name
                target_attr = 'param_dist_group_color_map'
            else:
                x_var = getattr(self, 'param_dist_x_var', None)
                x_name = x_var.get() if x_var else ''
                if not x_name:
                    messagebox.showinfo("Sin Variable", "Seleccione primero una variable en 'Agrupar por Color' o en el eje X.", parent=self.parent_for_dialogs)
                    return
                target_name = x_name
                target_attr = 'param_dist_category_color_map'

            if self.data is None:
                messagebox.showinfo("Sin Datos", "Cargue datos antes de asignar colores por nivel.", parent=self.parent_for_dialogs)
                return

            levels = list(self.data[target_name].dropna().unique())
            if not levels:
                messagebox.showinfo("Sin Niveles", f"La columna '{target_name}' no tiene niveles válidos.", parent=self.parent_for_dialogs)
                return

            dlg = tk.Toplevel(self)
            dlg.title(f"Colores para niveles de {target_name}")
            dlg.transient(self)
            dlg.grab_set()

            vars_map = {}
            # Suggest palette colors using seaborn if available
            try:
                palette_name = getattr(self, 'param_dist_group_palette_var', 'deep').get() if hasattr(self, 'param_dist_group_palette_var') else 'deep'
                suggested = sns.color_palette(palette_name, n_colors=len(levels))
                suggested_hex = [('#%02x%02x%02x' % tuple(int(255*c) for c in ctuple)) if isinstance(ctuple, tuple) else str(ctuple) for ctuple in [(int(255*c[0]), int(255*c[1]), int(255*c[2])) for c in suggested]]
            except Exception:
                suggested_hex = [self.color_options[i % len(self.color_options)] for i in range(len(levels))]

            for i, lvl in enumerate(levels):
                row = ttk.Frame(dlg)
                row.pack(fill='x', padx=6, pady=3)
                ttk.Label(row, text=str(lvl)).pack(side='left')
                var = StringVar(value=suggested_hex[i] if i < len(suggested_hex) else self.color_options[0])
                vars_map[lvl] = var
                ttk.Combobox(row, textvariable=var, values=self.color_options, state='readonly', width=12).pack(side='right')

            def on_save():
                mapping = {str(k): v.get() for k, v in vars_map.items()}
                setattr(self, target_attr, mapping)
                dlg.grab_release()
                dlg.destroy()
                self.log(f"Asignados colores por nivel para {target_name}: {mapping}", 'INFO')

            btn_frame = ttk.Frame(dlg)
            btn_frame.pack(fill='x', padx=6, pady=6)
            ttk.Button(btn_frame, text='Guardar', command=on_save).pack(side='right', padx=4)
            ttk.Button(btn_frame, text='Cancelar', command=lambda: (dlg.grab_release(), dlg.destroy())).pack(side='right')

        except Exception as e:
            self.log(f"Error abriendo selector de colores por nivel: {e}", 'ERROR')
            messagebox.showerror("Error", f"No se pudo abrir el selector: {e}", parent=self.parent_for_dialogs)


    def load_chart_descriptions(self):
        # Aquí cargarías las descripciones, parámetros y recomendaciones desde un archivo o diccionario
        # Por ahora, un placeholder
        return {
            "Diagrama de Dispersión": {
                "descripcion": "Representa puntos en un plano cartesiano (x, y). Útil para mostrar relaciones o correlaciones entre dos variables. Para crear un gráfico de burbujas, seleccione una variable en el parámetro 'Tamaño'.",
                "parametros_clave": "Variables X, Y. Opcional: color, tamaño, hover_name (Plotly).",
                "recomendaciones": "Ideal para visualizar la relación entre dos variables continuas. Considerar la sobreimpresión de puntos si hay muchos datos."
            },
            "Gráfico de Pastel": {
                "descripcion": "Un círculo dividido en secciones, donde cada sección representa una proporción del total.",
                "parametros_clave": "Columna de valores, columna de etiquetas.",
                "recomendaciones": "Generalmente desaconsejado para comparaciones precisas. Usar con pocas categorías. Evitar versiones 3D."
            },
            "Histogramas": {
                "descripcion": "Muestra la distribución de una variable numérica dividiendo los datos en 'bins' (intervalos) y contando las observaciones en cada bin.",
                "parametros_clave": "Variable (numérica), Número de bins (opcional), Mostrar KDE (opcional).",
                "recomendaciones": "Útil para entender la forma de la distribución de los datos (simetría, picos, etc.). Experimentar con el número de bins."
            }
            # ... Añadir descripciones para todos los demás gráficos
        }

    def _describe_shared_source(self, metadata):
        if not isinstance(metadata, dict):
            return "Archivo compartido"
        source_path = metadata.get("source_path")
        if not source_path:
            return metadata.get("label") or "Archivo compartido"
        try:
            return os.path.basename(source_path)
        except Exception:
            return source_path

    def cargar_datos_para_graficos(self, filepath=None):
        # Allow passing a filepath programmatically for testing; otherwise open file dialog
        self.log(f"Invocando cargar_datos_para_graficos (filepath param: {bool(filepath)})", "DEBUG")
        if not filepath:
            filepath = filedialog.askopenfilename(
            title="Seleccionar archivo de datos para gráficos",
            filetypes=(("Archivos Excel", "*.xlsx *.xls"),
                       ("Archivos CSV", "*.csv"),
                       ("Todos los archivos", "*.*")),
            parent=self.parent_for_dialogs
        )
        if not filepath:
            self.log("Carga de archivo cancelada.", "INFO")
            return

        try:
            filename = os.path.basename(filepath) # 'os' ya está importado
            
            # Try to load the new data into a temporary variable first
            temp_data = None
            if filepath.endswith(('.xlsx', '.xls')):
                # Excel reading may require openpyxl. Check and provide a clear message if missing.
                try:
                    import openpyxl  # noqa: F401
                except Exception:
                    msg = ("Para leer archivos .xlsx se requiere el paquete 'openpyxl'.\n"
                           "Instálalo en tu entorno virtual: pip install openpyxl")
                    messagebox.showerror("Dependencia faltante", msg, parent=self.parent_for_dialogs)
                    self.log(f"Falta dependencia openpyxl para leer '{filename}'.", "ERROR")
                    return
                try:
                    temp_data = pd.read_excel(filepath, engine='openpyxl')
                except Exception as e:
                    self.log(f"Error al leer Excel '{filename}': {e}", "ERROR")
                    messagebox.showerror("Error leyendo Excel", f"No se pudo leer el archivo Excel:\n{e}", parent=self.parent_for_dialogs)
                    return
            elif filepath.endswith('.csv'):
                try:
                    sniffer = csv.Sniffer() # 'csv' ya está importado
                    with open(filepath, 'r', encoding='utf-8-sig') as f:
                        dialect = sniffer.sniff(f.read(1024))
                    temp_data = pd.read_csv(filepath, sep=dialect.delimiter)
                    self.log(f"Archivo CSV '{filename}' cargado con separador '{dialect.delimiter}' detectado.", "INFO")
                except Exception: 
                    # Try common encodings and separators
                    read_attempts = [
                        {'sep': ',', 'encoding': 'utf-8-sig'},
                        {'sep': ',', 'encoding': 'utf-8'},
                        {'sep': ';', 'encoding': 'utf-8-sig'},
                        {'sep': ';', 'encoding': 'latin1'},
                    ]
                    last_exc = None
                    for opts in read_attempts:
                        try:
                            temp_data = pd.read_csv(filepath, sep=opts['sep'], encoding=opts['encoding'])
                            self.log(f"CSV '{filename}' leído con sep='{opts['sep']}' encoding='{opts['encoding']}'", "INFO")
                            break
                        except Exception as e:
                            last_exc = e
                            continue
                    if temp_data is None:
                        self.log(f"Error al leer CSV '{filename}': {last_exc}", "ERROR")
                        messagebox.showerror("Error leyendo CSV", f"No se pudo leer el CSV:\n{last_exc}", parent=self.parent_for_dialogs)
                        return
            else:
                messagebox.showerror("Error de Archivo", f"Tipo de archivo no soportado: {filename}", parent=self.parent_for_dialogs)
                self.log(f"Tipo de archivo no soportado: {filename}", "ERROR")
                return
            
            # Only update self.data after successful load
            if temp_data is not None:
                # Normalize column names (strip BOMs/spaces)
                temp_data.columns = [str(c).strip() for c in temp_data.columns]
                self.data = temp_data
                self.lbl_data_status.config(text=f"{filename} ({self.data.shape[0]}x{self.data.shape[1]})")
                self.log(f"Datos cargados desde '{filename}'. Dimensiones: {self.data.shape}", "SUCCESS")
                
                self.log("Actualizando componente de filtros...", "DEBUG")
                try:
                    self.filter_component.set_dataframe(self.data)
                    self.log("Componente de filtros actualizado.", "DEBUG")
                except Exception as e:
                    self.log(f"Fallo al actualizar el componente de filtros: {e}", "ERROR")
                    self.log(traceback.format_exc(), "DEBUG")

                # Refresh parameter controls
                self.log("Actualizando controles de parámetros de gráfico...", "DEBUG")
                try:
                    self._update_parameter_controls()
                    self.log("Controles de parámetros de gráfico actualizados.", "DEBUG")
                except Exception as e:
                    self.log(f"Fallo al actualizar controles de parámetros: {e}", "ERROR")
                    self.log(traceback.format_exc(), "DEBUG")
            else:
                raise ValueError("No se pudieron cargar los datos correctamente.")

        except Exception as e:
            messagebox.showerror("Error de Lectura", f"No se pudo leer el archivo:\n{e}", parent=self.parent_for_dialogs)
            self.log(f"Error leyendo archivo '{filepath}': {e}", "ERROR")
            # Don't clear self.data on error - keep existing data
            try:
                self.lbl_data_status.config(text="Error al cargar, datos anteriores conservados.")
            except Exception:
                pass

    # cargar_ejemplo removed per user request

    def receive_shared_dataset(self, *, dataset, filtered_dataset=None, filter_summary=None, metadata=None, source_widget=None):
        if source_widget is self:
            return

        self.shared_dataset_metadata = dict(metadata or {})
        self.current_shared_filter_summary = list(filter_summary or [])

        if dataset is None:
            self.data = None
            try:
                self.filter_component.set_dataframe(pd.DataFrame())
            except Exception:
                pass
            try:
                self.lbl_data_status.config(text="Sin dataset compartido.")
            except Exception:
                pass
            self._clear_chart_display()
            for widget in self.parameter_controls_frame.winfo_children():
                widget.destroy()
            self.log("Dataset compartido eliminado; se limpiaron controles y gráfico.", "INFO")
            return

        if isinstance(dataset, pd.DataFrame):
            try:
                base_df = dataset.copy(deep=True)
            except Exception:
                base_df = dataset
        else:
            self.log("Dataset compartido recibido no es un DataFrame. Acción cancelada.", "ERROR")
            return

        active_df = base_df
        if isinstance(filtered_dataset, pd.DataFrame):
            try:
                active_df = filtered_dataset.copy(deep=True)
            except Exception:
                active_df = filtered_dataset

        self.data = active_df

        try:
            self.filter_component.set_dataframe(active_df)
        except Exception as exc:
            self.log(f"No se pudo actualizar el componente de filtros con el dataset compartido: {exc}", "ERROR")

        try:
            rows, cols = active_df.shape
            source_desc = self._describe_shared_source(self.shared_dataset_metadata)
            filters_applied = len(self.current_shared_filter_summary)
            suffix = f" | Filtros: {filters_applied}" if filters_applied else ""
            self.lbl_data_status.config(text=f"Compartido: {source_desc} ({rows}x{cols}){suffix}")
        except Exception:
            pass

        self.log("Dataset compartido recibido en GeneralChartsApp.", "INFO")
        if self.current_shared_filter_summary:
            for summary in self.current_shared_filter_summary:
                self.log(f"  - {summary}", "DEBUG")

        try:
            self._update_parameter_controls()
        except Exception as exc:
            self.log(f"Error al refrescar controles tras recibir dataset compartido: {exc}", "ERROR")

    def _update_parameter_controls(self, event=None):
        for widget in self.parameter_controls_frame.winfo_children():
            widget.destroy()

        chart_type = self.chart_type_var.get()
        if not chart_type:
            return

        self.log(f"Configurando parámetros para: {chart_type}", "DEBUG")
        
        description_data = self.chart_descriptions.get(chart_type, {})
        if description_data:
            self.log(f"Descripción ({chart_type}): {description_data.get('descripcion', 'N/A')}", "DESC")
            self.log(f"Recomendaciones: {description_data.get('recomendaciones', 'N/A')}", "RECOM")


        if self.data is None:
            ttk.Label(self.parameter_controls_frame, text="Cargue datos primero.").pack()
            return

        columnas = list(self.data.columns)
        numeric_columns = [col for col in columnas if pd.api.types.is_numeric_dtype(self.data[col])] if self.data is not None else []
        
        if chart_type == "Diagrama de Dispersión":
            self.param_x_var, self.param_x_display_name_var, self.param_x_recode_var = self._create_variable_selector(
                self.parameter_controls_frame, "Variable X:", columnas, allow_recode=True
            )
            self.param_y_var, self.param_y_display_name_var, self.param_y_recode_var = self._create_variable_selector(
                self.parameter_controls_frame, "Variable Y:", columnas, allow_recode=True
            )
            self.param_color_var, self.param_color_display_name_var, self.param_color_recode_var = self._create_variable_selector(
                self.parameter_controls_frame, "Color (Opcional):", [""] + columnas, allow_recode=True
            )
            self.param_size_var, self.param_size_display_name_var, _ = self._create_variable_selector(
                self.parameter_controls_frame, "Tamaño (Opcional, Numérica):", [""] + [col for col in columnas if pd.api.types.is_numeric_dtype(self.data[col])] if self.data is not None else []
            )

            self.param_scatter_fit_reg_var = tk.BooleanVar(value=False)
            ttk.Checkbutton(self.parameter_controls_frame, text="Añadir línea de regresión", variable=self.param_scatter_fit_reg_var).pack(anchor="w", pady=(5,0))

        elif chart_type == "Histograma":
            self.param_hist_var, _, _ = self._create_variable_selector(
                self.parameter_controls_frame, "Variable Numérica:", numeric_columns
            )
            self.param_hist_hue_var, _, self.param_hist_hue_recode_var = self._create_variable_selector(
                self.parameter_controls_frame, "Agrupar por Color (Opcional):", [""] + columnas, allow_recode=True
            )
            
            ttk.Label(self.parameter_controls_frame, text="Número de Bins (Opcional):").pack(anchor="w")
            self.param_hist_bins_var = StringVar(value="auto")
            ttk.Entry(self.parameter_controls_frame, textvariable=self.param_hist_bins_var).pack(fill="x", pady=(0,5))

            self.param_hist_kde_var = tk.BooleanVar(value=False)
            ttk.Checkbutton(self.parameter_controls_frame, text="Mostrar Curva de Densidad (KDE)", variable=self.param_hist_kde_var).pack(anchor="w", pady=(0,5))
            
            ttk.Label(self.parameter_controls_frame, text="Orientación:").pack(anchor="w")
            self.param_hist_orientation_var = StringVar(value="Vertical")
            ttk.Combobox(self.parameter_controls_frame, textvariable=self.param_hist_orientation_var, values=["Vertical", "Horizontal"], state="readonly").pack(fill="x", pady=(0,5))

        elif chart_type == "Gráfico de Densidad":
            self.param_density_var, _, _ = self._create_variable_selector(
                self.parameter_controls_frame, "Variable Numérica:", numeric_columns
            )
            self.param_density_hue_var, _, self.param_density_hue_recode_var = self._create_variable_selector(
                self.parameter_controls_frame, "Agrupar por Color (Opcional):", [""] + columnas, allow_recode=True
            )

        elif chart_type == "Gráfico de Barras":
            self.param_bar_x_var, _, self.param_bar_x_recode_var = self._create_variable_selector(
                self.parameter_controls_frame, "Variable de Eje (Categorías):", columnas, allow_recode=True
            )
            self.param_bar_y_var, _, _ = self._create_variable_selector(
                self.parameter_controls_frame, "Variable de Valor (Numérica, Opcional):", [""] + numeric_columns
            )
            self.param_bar_hue_var, _, self.param_bar_hue_recode_var = self._create_variable_selector(
                self.parameter_controls_frame, "Agrupar por Color (Opcional):", [""] + columnas, allow_recode=True
            )

            ttk.Label(self.parameter_controls_frame, text="Orientación:").pack(anchor="w")
            self.param_bar_orientation_var = StringVar(value="Vertical")
            ttk.Combobox(self.parameter_controls_frame, textvariable=self.param_bar_orientation_var, values=["Vertical", "Horizontal"], state="readonly").pack(fill="x", pady=(0,5))

            mode_frame = ttk.LabelFrame(self.parameter_controls_frame, text="Modo de Barras", padding="5")
            mode_frame.pack(fill="x", expand=True, pady=(0,5))
            ttk.Label(mode_frame, text="Seleccione el tipo de barras a generar:").pack(anchor="w")
            mode_options = ["Simple", "Agrupado", "Apilado", "Segmentado"]
            previous_mode_var = getattr(self, 'param_bar_mode_var', None)
            previous_mode_value = previous_mode_var.get() if isinstance(previous_mode_var, tk.Variable) else "Simple"
            if previous_mode_value not in mode_options:
                previous_mode_value = "Simple"
            self.param_bar_mode_var = StringVar(value=previous_mode_value)
            mode_combo = ttk.Combobox(mode_frame, textvariable=self.param_bar_mode_var, values=mode_options, state="readonly")
            mode_combo.pack(fill="x", pady=(0,4))

            self.bar_color_frame = ttk.LabelFrame(self.parameter_controls_frame, text="Colores de Barras", padding="5")
            self.bar_color_frame.pack(fill="x", expand=True, pady=(0,5))

            ttk.Label(self.bar_color_frame, text="Modo de Color:").pack(anchor="w")
            self.param_bar_color_mode_var = StringVar(value="auto")
            color_modes = ["auto", "un color", "paleta"]
            ttk.Combobox(self.bar_color_frame, textvariable=self.param_bar_color_mode_var, values=color_modes, state="readonly").pack(fill="x", pady=(0,4))

            ttk.Label(self.bar_color_frame, text="Color único (#hex o nombre):").pack(anchor="w")
            self.param_bar_single_color_var = StringVar(value="#4C72B0")
            ttk.Entry(self.bar_color_frame, textvariable=self.param_bar_single_color_var).pack(fill="x", pady=(0,4))

            ttk.Label(self.bar_color_frame, text="Paleta (cuando aplique):").pack(anchor="w")
            bar_palette_choices = ['default', 'deep', 'muted', 'pastel', 'bright', 'dark', 'colorblind', 'viridis', 'plasma', 'inferno', 'magma', 'cividis']
            self.param_bar_palette_choice_var = StringVar(value='deep')
            ttk.Combobox(self.bar_color_frame, textvariable=self.param_bar_palette_choice_var, values=bar_palette_choices, state="readonly").pack(fill="x", pady=(0,4))

            self.bar_stacked_options_frame = ttk.LabelFrame(self.parameter_controls_frame, text="Opciones de Apilado", padding="5")
            self.param_stacked_100_var = tk.BooleanVar(value=False)
            ttk.Checkbutton(self.bar_stacked_options_frame, text="Normalizar a 100%", variable=self.param_stacked_100_var).pack(anchor="w")

            self.bar_segment_frame = ttk.LabelFrame(self.parameter_controls_frame, text="Segmentos Numéricos", padding="5")
            self.param_bar_segment_vars = []
            max_segments = 4
            for idx in range(max_segments):
                var, display_var, _ = self._create_variable_selector(
                    self.bar_segment_frame,
                    f"Segmento {idx + 1}:",
                    [""] + numeric_columns
                )
                self.param_bar_segment_vars.append((var, display_var))

            self.param_bar_segment_normalize_var = tk.BooleanVar(value=False)
            ttk.Checkbutton(self.bar_segment_frame, text="Normalizar cada barra a 100%", variable=self.param_bar_segment_normalize_var).pack(anchor="w", pady=(4,0))

            self.bar_segment_color_frame = ttk.LabelFrame(self.parameter_controls_frame, text="Colores de Segmentos", padding="5")
            segment_palette_choices = ['deep', 'muted', 'pastel', 'bright', 'dark', 'colorblind', 'viridis', 'plasma', 'inferno', 'magma', 'cividis']
            self.param_bar_segment_palette_var = StringVar(value='deep')
            ttk.Label(self.bar_segment_color_frame, text="Paleta de Segmentos:").pack(anchor="w")
            ttk.Combobox(self.bar_segment_color_frame, textvariable=self.param_bar_segment_palette_var, values=segment_palette_choices, state="readonly").pack(fill="x", pady=(0,4))
            ttk.Label(self.bar_segment_color_frame, text="Colores personalizados (coma separada):").pack(anchor="w")
            self.param_bar_segment_custom_colors_var = StringVar()
            ttk.Entry(self.bar_segment_color_frame, textvariable=self.param_bar_segment_custom_colors_var).pack(fill="x", pady=(0,4))

            mode_combo.bind("<<ComboboxSelected>>", lambda _evt: self._refresh_bar_mode_controls())
            try:
                self.param_bar_mode_var.trace_add('write', lambda *_: self._refresh_bar_mode_controls())
            except Exception:
                pass
            self._refresh_bar_mode_controls()

        elif chart_type == "Gráfico de Pirámide":
            self.param_pyr_age_var, _, self.param_pyr_age_recode_var = self._create_variable_selector(
                self.parameter_controls_frame, "Variable de Eje Y (Categorías de Edad):", columnas, allow_recode=True
            )
            self.param_pyr_male_var, _, _ = self._create_variable_selector(
                self.parameter_controls_frame, "Variable de Barra Izquierda (Numérica):", numeric_columns
            )
            self.param_pyr_female_var, _, _ = self._create_variable_selector(
                self.parameter_controls_frame, "Variable de Barra Derecha (Numérica):", numeric_columns
            )

        elif chart_type == "Gráfico Radial":
            ttk.Label(self.parameter_controls_frame, text="Variables Numéricas (3 o más):").pack(anchor="w")
            self.param_radar_vars = []
            for i in range(5):
                var, _, _ = self._create_variable_selector(self.parameter_controls_frame, f"Variable {i+1}:", [""] + numeric_columns)
                self.param_radar_vars.append(var)

        elif chart_type == "Gráfico de Bala":
            self.param_bullet_value_var, _, _ = self._create_variable_selector(self.parameter_controls_frame, "Variable de Valor (Numérica):", numeric_columns)
            self.param_bullet_target_var, _, _ = self._create_variable_selector(self.parameter_controls_frame, "Variable de Objetivo (Numérica):", numeric_columns)
            ttk.Label(self.parameter_controls_frame, text="Rangos (e.g., 20,50,100):").pack(anchor="w")
            self.param_bullet_ranges_var = StringVar()
            ttk.Entry(self.parameter_controls_frame, textvariable=self.param_bullet_ranges_var).pack(fill="x", pady=(0,5))

        elif chart_type == "Gráfico Lollipop":
            self.param_lollipop_x_var, _, self.param_lollipop_x_recode_var = self._create_variable_selector(
                self.parameter_controls_frame, "Variable Categórica:", columnas, allow_recode=True
            )
            self.param_lollipop_y_var, _, _ = self._create_variable_selector(
                self.parameter_controls_frame, "Variable Numérica:", numeric_columns
            )
            ttk.Label(self.parameter_controls_frame, text="Orientación:").pack(anchor="w")
            self.param_lollipop_orientation_var = StringVar(value="Vertical")
            ttk.Combobox(self.parameter_controls_frame, textvariable=self.param_lollipop_orientation_var, values=["Vertical", "Horizontal"], state="readonly").pack(fill="x", pady=(0,5))
        
        elif chart_type == "Mapa de Árbol":
            self.param_treemap_values_var, _, _ = self._create_variable_selector(
                self.parameter_controls_frame, "Columna de Valores (Tamaño):", numeric_columns
            )
            self.param_treemap_names_var, _, self.param_treemap_names_recode_var = self._create_variable_selector(
                self.parameter_controls_frame, "Columna de Nombres (Etiquetas):", columnas, allow_recode=True
            )

        elif chart_type == "Polígonos de Frecuencia":
            self.param_poly_var, _, _ = self._create_variable_selector(self.parameter_controls_frame, "Variable Numérica:", numeric_columns)
            self.param_poly_hue_var, _, self.param_poly_hue_recode_var = self._create_variable_selector(self.parameter_controls_frame, "Variable Categórica (Comparación):", [""] + columnas, allow_recode=True)

        elif chart_type == "Gráfico de Líneas / Área":
            self.param_line_x_var, _, self.param_line_x_recode_var = self._create_variable_selector(
                self.parameter_controls_frame, "Variable X (Eje X):", columnas, allow_recode=True
            )
            self.param_line_y_var, _, self.param_line_y_recode_var = self._create_variable_selector(
                self.parameter_controls_frame, "Variable Y (Eje Y):", columnas, allow_recode=True
            )
            self.param_line_hue_var, _, self.param_line_hue_recode_var = self._create_variable_selector(
                self.parameter_controls_frame, "Agrupación (Color):", [""] + columnas, allow_recode=True
            )
            self.param_area_fill_var = tk.BooleanVar(value=False)
            ttk.Checkbutton(self.parameter_controls_frame, text="Rellenar como Gráfico de Área", variable=self.param_area_fill_var).pack(anchor="w")

        elif chart_type == "Gráfico de Distribución":
            self.param_dist_y_var, _, _ = self._create_variable_selector(self.parameter_controls_frame, "Variable Numérica (Eje Y):", numeric_columns)
            self.param_dist_x_var, _, self.param_dist_x_recode_var = self._create_variable_selector(self.parameter_controls_frame, "Variable Categórica (Eje X, Opcional):", [""] + columnas, allow_recode=True)
            self.param_dist_hue_var, _, self.param_dist_hue_recode_var = self._create_variable_selector(self.parameter_controls_frame, "Agrupar por Color (Opcional):", [""] + columnas, allow_recode=True)
            ttk.Label(self.parameter_controls_frame, text="Agrupar por Tamaño (Opcional):").pack(anchor="w")
            self.param_dist_size_var = StringVar(value="")
            ttk.Combobox(self.parameter_controls_frame, textvariable=self.param_dist_size_var, values=[""] + columnas, state="readonly").pack(fill="x", pady=(0,5))
            ttk.Label(self.parameter_controls_frame, text="Agrupar por Forma (Opcional):").pack(anchor="w")
            self.param_dist_style_var = StringVar(value="")
            ttk.Combobox(self.parameter_controls_frame, textvariable=self.param_dist_style_var, values=[""] + columnas, state="readonly").pack(fill="x", pady=(0,8))

            layers_frame = ttk.LabelFrame(self.parameter_controls_frame, text="Capas de Visualización", padding="5")
            layers_frame.pack(fill="x", expand=True, pady=(10, 0))

            ttk.Label(layers_frame, text="Tipo de Puntos:").pack(anchor="w")
            self.param_dist_point_type_var = StringVar(value='Strip (Jitter)')
            ttk.Combobox(layers_frame, textvariable=self.param_dist_point_type_var, values=['Ninguno', 'Strip (Jitter)', 'Swarm', 'Center', 'Hex', 'Square'], state="readonly").pack(fill="x", pady=(0,5))
            ttk.Label(layers_frame, text="Método de Acomodo:").pack(anchor="w")
            self.param_dist_layout_method_var = StringVar(value='Auto')
            ttk.Combobox(layers_frame, textvariable=self.param_dist_layout_method_var, values=['Auto', 'Center', 'Hex', 'Square'], state="readonly").pack(fill="x", pady=(0,5))
            ttk.Label(layers_frame, text="Ancho de Jitter Aleatorio:").pack(anchor="w")
            self.param_dist_jitter_width_var = StringVar(value='0.20')
            ttk.Entry(layers_frame, textvariable=self.param_dist_jitter_width_var).pack(fill="x", pady=(0,5))
            # Option to connect category points with a line (pointplot join)
            self.param_dist_connect_points_var = tk.BooleanVar(value=False)
            ttk.Checkbutton(layers_frame, text="Conectar puntos con línea (unir medias)", variable=self.param_dist_connect_points_var).pack(anchor="w")

            self.param_dist_show_box_var = tk.BooleanVar(value=False)
            ttk.Checkbutton(layers_frame, text="Mostrar Diagrama de Caja", variable=self.param_dist_show_box_var).pack(anchor="w")

            self.param_dist_show_violin_var = tk.BooleanVar(value=False)
            ttk.Checkbutton(layers_frame, text="Mostrar Gráfico de Violín", variable=self.param_dist_show_violin_var).pack(anchor="w")

            self.param_dist_raincloud_var = tk.BooleanVar(value=False)
            ttk.Checkbutton(layers_frame, text="Estilo Raincloud (medio violín)", variable=self.param_dist_raincloud_var).pack(anchor="w")
            # Mostrar histograma cuando no hay X seleccionado
            self.param_dist_show_hist_var = tk.BooleanVar(value=False)
            ttk.Checkbutton(layers_frame, text="Mostrar Histograma (cuando no hay X)", variable=self.param_dist_show_hist_var).pack(anchor="w")
            # Mostrar resumen (punto + IC) por categoría
            self.param_dist_show_summary_var = tk.BooleanVar(value=False)
            ttk.Checkbutton(layers_frame, text="Mostrar Resumen (punto + IC)", variable=self.param_dist_show_summary_var).pack(anchor="w")
            # Medio-violín (semi-violin) por categoría (cuando está activado, reemplaza violin completeness)
            self.param_dist_half_violin_var = tk.BooleanVar(value=False)
            ttk.Checkbutton(layers_frame, text="Medio-Violín (semi-violin)", variable=self.param_dist_half_violin_var).pack(anchor="w")
            # Medio-violín con caja y puntos (overlay)
            self.param_dist_half_violin_boxpoints_var = tk.BooleanVar(value=False)
            ttk.Checkbutton(layers_frame, text="Medio-Violín + Caja y Puntos", variable=self.param_dist_half_violin_boxpoints_var).pack(anchor="w")
            # Colapsar categorías en un solo tick y seleccionar paleta de grupo
            self.param_dist_collapse_var = tk.BooleanVar(value=False)
            ttk.Checkbutton(layers_frame, text="Colapsar categorías en un solo tick (usar hue)", variable=self.param_dist_collapse_var).pack(anchor="w")
            ttk.Label(layers_frame, text="Paleta para Grupos:").pack(anchor="w")
            self.param_dist_group_palette_var = StringVar(value='deep')
            group_palettes = ['deep', 'muted', 'pastel', 'bright', 'dark', 'colorblind', 'viridis', 'plasma']
            ttk.Combobox(layers_frame, textvariable=self.param_dist_group_palette_var, values=group_palettes, state="readonly").pack(fill="x", pady=(0,5))
            ttk.Button(layers_frame, text="Asignar colores por nivel", command=lambda: self._open_group_color_picker()).pack(fill="x", pady=(3,5))

        elif chart_type == "Diagrama de Tallo y Hojas":
            self.param_stem_var, _, _ = self._create_variable_selector(self.parameter_controls_frame, "Variable Numérica:", numeric_columns)

        elif chart_type == "Mapa de Calor" or chart_type == "Correlograma":
            ttk.Label(self.parameter_controls_frame, text="Seleccione variables numéricas:").pack(anchor="w")
            self.param_multi_select_vars = []
            for i in range(10):
                var, _, _ = self._create_variable_selector(self.parameter_controls_frame, f"Variable {i+1}:", [""] + numeric_columns)
                self.param_multi_select_vars.append(var)

        elif chart_type == "Gráfico de Coordenadas Paralelas":
            self.param_pc_class_var, _, self.param_pc_class_recode_var = self._create_variable_selector(
                self.parameter_controls_frame, "Variable de Clase (Color):", columnas, allow_recode=True
            )
            ttk.Label(self.parameter_controls_frame, text="Variables Numéricas a Graficar:").pack(anchor="w")
            self.param_pc_vars = []
            for i in range(10):
                var, _, _ = self._create_variable_selector(self.parameter_controls_frame, f"Variable {i+1}:", [""] + numeric_columns)
                self.param_pc_vars.append(var)

        else:
            ttk.Label(self.parameter_controls_frame, text=f"Controles para '{chart_type}' no implementados.").pack()


        # --- Generic Customization Options ---
        customization_frame = ttk.LabelFrame(self.parameter_controls_frame, text="Personalización del Gráfico", padding="10")
        customization_frame.pack(fill="x", expand=True, pady=(15, 0), anchor="n")

        # Title
        ttk.Label(customization_frame, text="Título del Gráfico:").pack(anchor="w")
        self.param_title_var = StringVar()
        ttk.Entry(customization_frame, textvariable=self.param_title_var).pack(fill="x", pady=(0,5))

        # Title color and size
        ttk.Label(customization_frame, text="Color del Título:").pack(anchor="w")
        self.param_title_color_var = StringVar(value='black')
        ttk.Combobox(customization_frame, textvariable=self.param_title_color_var, values=self.color_options, state="readonly").pack(fill="x", pady=(0,5))
        ttk.Label(customization_frame, text="Tamaño del Título:").pack(anchor="w")
        self.param_title_size_var = StringVar(value='12')
        ttk.Entry(customization_frame, textvariable=self.param_title_size_var).pack(fill="x", pady=(0,5))

        # X Label
        ttk.Label(customization_frame, text="Etiqueta Eje X:").pack(anchor="w")
        self.param_xlabel_var = StringVar()
        ttk.Entry(customization_frame, textvariable=self.param_xlabel_var).pack(fill="x", pady=(0,5))

        # Y Label
        ttk.Label(customization_frame, text="Etiqueta Eje Y:").pack(anchor="w")
        self.param_ylabel_var = StringVar()
        ttk.Entry(customization_frame, textvariable=self.param_ylabel_var).pack(fill="x", pady=(0,5))

        # Point Size
        ttk.Label(customization_frame, text="Tamaño de Puntos:").pack(anchor="w")
        self.param_point_size_var = StringVar(value="5")
        ttk.Entry(customization_frame, textvariable=self.param_point_size_var).pack(fill="x", pady=(0,5))

        # Point Color
        ttk.Label(customization_frame, text="Color de Puntos:").pack(anchor="w")
        self.param_point_color_var = StringVar(value="auto")
        point_color_choices = ['auto'] + self.color_options
        ttk.Combobox(customization_frame, textvariable=self.param_point_color_var, values=point_color_choices, state="readonly").pack(fill="x", pady=(0,5))

        # Grid
        self.param_grid_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(customization_frame, text="Mostrar Cuadrícula", variable=self.param_grid_var).pack(anchor="w")

        # Font family selector (per-chart override)
        try:
            available_fonts = sorted({f.name for f in fm.fontManager.ttflist})
            font_choices = ['Default'] + available_fonts[:60]
        except Exception:
            font_choices = ['Default', 'Arial', 'DejaVu Sans', 'Times New Roman', 'Courier New']
        
        # Ensure "Palatino Linotype" is always an option
        if "Palatino Linotype" not in font_choices:
            font_choices.insert(1, "Palatino Linotype") # Insert after 'Default'
        
        ttk.Label(customization_frame, text="Fuente (Family):").pack(anchor="w")
        self.param_font_family_var = StringVar(value='Default')
        ttk.Combobox(customization_frame, textvariable=self.param_font_family_var, values=font_choices, state="readonly").pack(fill="x", pady=(0,5))

        # Font family, size, and color are now part of the global appearance tab

        # Limits and Ticks
        ttk.Label(customization_frame, text="X lim (min,max):").pack(anchor="w")
        self.param_xlim_var = StringVar()
        ttk.Entry(customization_frame, textvariable=self.param_xlim_var).pack(fill="x", pady=(0,5))
        ttk.Label(customization_frame, text="Y lim (min,max):").pack(anchor="w")
        self.param_ylim_var = StringVar()
        ttk.Entry(customization_frame, textvariable=self.param_ylim_var).pack(fill="x", pady=(0,5))

        # --- Advanced Customization Options ---
        adv_custom_frame = ttk.LabelFrame(customization_frame, text="Opciones Avanzadas de Ejes y Tamaño", padding="5")
        adv_custom_frame.pack(fill="x", expand=True, pady=(10, 0))

        ttk.Label(adv_custom_frame, text="Rotación Etiquetas X:").grid(row=0, column=0, padx=5, pady=2, sticky="w")
        self.param_tick_rotation_var = StringVar(value="0")
        ttk.Combobox(adv_custom_frame, textvariable=self.param_tick_rotation_var, values=["0", "30", "45", "90"], state="readonly", width=8).grid(row=0, column=1, padx=5, pady=2, sticky="w")

        ttk.Label(adv_custom_frame, text="Escala Eje X:").grid(row=1, column=0, padx=5, pady=2, sticky="w")
        self.param_xscale_var = StringVar(value="linear")
        ttk.Combobox(adv_custom_frame, textvariable=self.param_xscale_var, values=["linear", "log"], state="readonly", width=8).grid(row=1, column=1, padx=5, pady=2, sticky="w")

        ttk.Label(adv_custom_frame, text="Escala Eje Y:").grid(row=1, column=2, padx=5, pady=2, sticky="w")
        self.param_yscale_var = StringVar(value="linear")
        ttk.Combobox(adv_custom_frame, textvariable=self.param_yscale_var, values=["linear", "log"], state="readonly", width=8).grid(row=1, column=3, padx=5, pady=2, sticky="w")

        ttk.Label(adv_custom_frame, text="Ancho Gráfica (pulgadas):").grid(row=2, column=0, padx=5, pady=2, sticky="w")
        self.param_fig_width_var = StringVar(value="8")
        ttk.Entry(adv_custom_frame, textvariable=self.param_fig_width_var, width=10).grid(row=2, column=1, padx=5, pady=2, sticky="w")

        ttk.Label(adv_custom_frame, text="Alto Gráfica (pulgadas):").grid(row=2, column=2, padx=5, pady=2, sticky="w")
        self.param_fig_height_var = StringVar(value="5")
        ttk.Entry(adv_custom_frame, textvariable=self.param_fig_height_var, width=10).grid(row=2, column=3, padx=5, pady=2, sticky="w")


        # Seaborn Theme
        ttk.Label(customization_frame, text="Tema de Seaborn:").pack(anchor="w")
        self.param_theme_var = StringVar(value='whitegrid')
        themes = ['whitegrid', 'darkgrid', 'grid', 'white', 'dark', 'ticks']
        ttk.Combobox(customization_frame, textvariable=self.param_theme_var, values=themes, state="readonly").pack(fill="x", pady=(0,5))

        # Color Palette
        ttk.Label(customization_frame, text="Paleta de Colores:").pack(anchor="w")
        self.param_palette_var = StringVar(value='default')
        palettes = ['default', 'viridis', 'plasma', 'inferno', 'magma', 'cividis', 'deep', 'muted', 'pastel', 'bright', 'dark', 'colorblind']
        ttk.Combobox(customization_frame, textvariable=self.param_palette_var, values=palettes, state="readonly").pack(fill="x", pady=(0,5))
        # Violin fine controls
        ttk.Label(customization_frame, text="bw (suavizado KDE) para Violín:").pack(anchor="w")
        previous_bw = getattr(self, 'param_violin_bw_var', None)
        bw_default = previous_bw.get() if isinstance(previous_bw, tk.Variable) else '0.2'
        self.param_violin_bw_var = StringVar(value=bw_default)
        ttk.Entry(customization_frame, textvariable=self.param_violin_bw_var).pack(fill="x", pady=(0,5))

        previous_width = getattr(self, 'param_violin_width_var', None)
        width_default = previous_width.get() if isinstance(previous_width, tk.Variable) else '0.8'
        self.param_violin_width_var = StringVar(value=width_default)
        if chart_type == "Gráfico de Distribución":
            ttk.Label(customization_frame, text="Ancho (width) del Violín:").pack(anchor="w")
            ttk.Entry(customization_frame, textvariable=self.param_violin_width_var).pack(fill="x", pady=(0,5))

        ttk.Label(customization_frame, text="Alpha (transparencia) del Violín:").pack(anchor="w")
        previous_alpha = getattr(self, 'param_violin_alpha_var', None)
        alpha_default = previous_alpha.get() if isinstance(previous_alpha, tk.Variable) else '0.6'
        self.param_violin_alpha_var = StringVar(value=alpha_default)
        ttk.Entry(customization_frame, textvariable=self.param_violin_alpha_var).pack(fill="x", pady=(0,5))

        # Legend controls
        self.param_show_legend_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(customization_frame, text="Mostrar Leyenda", variable=self.param_show_legend_var).pack(anchor="w")
        ttk.Label(customization_frame, text="Posición Leyenda:").pack(anchor="w")
        self.param_legend_loc_var = StringVar(value='best')
        legend_positions = ['best','upper right','upper left','lower left','lower right','right','center left','center right','lower center','upper center','center']
        ttk.Combobox(customization_frame, textvariable=self.param_legend_loc_var, values=legend_positions, state="readonly").pack(fill="x", pady=(0,5))
        ttk.Label(customization_frame, text="Tamaño Fuente Leyenda:").pack(anchor="w")
        self.param_legend_size_var = StringVar(value='10')
        ttk.Entry(customization_frame, textvariable=self.param_legend_size_var).pack(fill="x", pady=(0,5))
        
        # Bootstrap and CI
        ci_frame = ttk.LabelFrame(customization_frame, text="Intervalos de Confianza (Bootstrap)", padding="5")
        ci_frame.pack(fill="x", expand=True, pady=(10, 0))

        self.param_ci_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(ci_frame, text="Calcular IC", variable=self.param_ci_var).grid(row=0, column=0, sticky="w")

        ttk.Label(ci_frame, text="Iteraciones:").grid(row=0, column=1, sticky="w")
        self.param_n_boot_var = StringVar(value="1000")
        ttk.Entry(ci_frame, textvariable=self.param_n_boot_var, width=8).grid(row=0, column=2, sticky="w")

    def _refresh_bar_mode_controls(self):
        mode_var = getattr(self, 'param_bar_mode_var', None)
        if mode_var is None:
            return

        mode_value = mode_var.get() if callable(getattr(mode_var, 'get', None)) else 'Simple'
        mode = (mode_value or 'Simple').strip().lower()

        show_y_selector = mode in ('simple', 'agrupado', 'apilado')
        show_hue_selector = mode in ('simple', 'agrupado', 'apilado')
        show_bar_colors = mode in ('simple', 'agrupado', 'apilado')
        show_stacked_options = mode == 'apilado'
        show_segment_controls = mode == 'segmentado'

        def toggle_selector(var_obj, should_show):
            if var_obj is None:
                return
            label = getattr(var_obj, '_label_widget', None)
            frame = getattr(var_obj, '_widget_frame', None)
            recode_frame = getattr(var_obj, '_recode_frame', None)

            if should_show:
                if label is not None and label.winfo_manager() != 'pack':
                    label.pack(anchor="w")
                if frame is not None and frame.winfo_manager() != 'pack':
                    frame.pack(fill="x", pady=(0,5))
                if recode_frame is not None and recode_frame.winfo_manager() != 'pack':
                    recode_frame.pack(fill="x", pady=(0,5))
            else:
                if label is not None and label.winfo_manager() == 'pack':
                    label.pack_forget()
                if frame is not None and frame.winfo_manager() == 'pack':
                    frame.pack_forget()
                if recode_frame is not None and recode_frame.winfo_manager() == 'pack':
                    recode_frame.pack_forget()

        def toggle_frame(frame_obj, should_show, pack_kwargs):
            if frame_obj is None:
                return
            if should_show:
                if frame_obj.winfo_manager() != 'pack':
                    frame_obj.pack(**pack_kwargs)
            else:
                if frame_obj.winfo_manager() == 'pack':
                    frame_obj.pack_forget()

        toggle_selector(getattr(self, 'param_bar_y_var', None), show_y_selector)
        toggle_selector(getattr(self, 'param_bar_hue_var', None), show_hue_selector)

        toggle_frame(getattr(self, 'bar_color_frame', None), show_bar_colors, {'fill': "x", 'expand': True, 'pady': (0,5)})
        toggle_frame(getattr(self, 'bar_stacked_options_frame', None), show_stacked_options, {'fill': "x", 'expand': True, 'pady': (0,5)})
        toggle_frame(getattr(self, 'bar_segment_frame', None), show_segment_controls, {'fill': "x", 'expand': True, 'pady': (0,5)})
        toggle_frame(getattr(self, 'bar_segment_color_frame', None), show_segment_controls, {'fill': "x", 'expand': True, 'pady': (0,5)})

    def _clear_chart_display(self):
        for widget in self.chart_display_frame.winfo_children():
            widget.destroy()

    def _is_categorical(self, obj):
        try:
            checker = getattr(pd.api.types, "is_categorical_dtype", None)
            if callable(checker):
                return bool(checker(obj))
        except Exception:
            pass
        try:
            dtype = getattr(obj, 'dtype', obj)
            return getattr(dtype, 'name', '').startswith('category')
        except Exception:
            return False

    def _set_categorical_tick_labels(self, ax, data, x_col=None, y_col=None):
        if x_col and x_col in data.columns:
            series_x = data[x_col]
            if self._is_categorical(series_x) or pd.api.types.is_object_dtype(series_x):
                if self._is_categorical(series_x):
                    categories = [str(cat) for cat in series_x.cat.categories]
                else:
                    series_no_na = series_x.dropna()
                    categories = [str(val) for val in series_no_na.unique()]
                if categories:
                    self.log(f"Setting x-tick labels para '{x_col}': {categories}", "DEBUG")
                    ax.set_xticks(range(len(categories)))
                    ax.set_xticklabels(categories)

        if y_col and y_col in data.columns:
            series_y = data[y_col]
            if self._is_categorical(series_y) or pd.api.types.is_object_dtype(series_y):
                if self._is_categorical(series_y):
                    categories = [str(cat) for cat in series_y.cat.categories]
                else:
                    series_no_na = series_y.dropna()
                    categories = [str(val) for val in series_no_na.unique()]
                if categories:
                    self.log(f"Setting y-tick labels para '{y_col}': {categories}", "DEBUG")
                    ax.set_yticks(range(len(categories)))
                    ax.set_yticklabels(categories)

    def _apply_violin_alpha(self, ax, alpha):
        try:
            if alpha is None:
                return
            for coll in getattr(ax, 'collections', []):
                try:
                    if isinstance(coll, PolyCollection):
                        coll.set_alpha(alpha)
                except Exception:
                    continue
        except Exception:
            pass

    def _overlay_boxplot(self, ax, data, x_col, y_col, order, hue_col, palette_arg, width, edge_color, category_palette=None):
        try:
            box_kwargs = {
                'data': data,
                'x': x_col,
                'y': y_col,
                'order': order,
                'ax': ax,
                'width': width,
                'showfliers': False,
                'whis': 1.5
            }
            if hue_col:
                box_kwargs['hue'] = hue_col
                box_kwargs['dodge'] = True
                if palette_arg is not None:
                    box_kwargs['palette'] = palette_arg
                sns.boxplot(
                    **box_kwargs,
                    boxprops={'facecolor': 'none', 'linewidth': 1.1},
                    medianprops={'linewidth': 1.1},
                    whiskerprops={'linewidth': 1.0},
                    capprops={'linewidth': 1.0}
                )
            else:
                if category_palette:
                    box_kwargs['palette'] = {str(k): v for k, v in category_palette.items()}
                    draw_color = None
                else:
                    draw_color = edge_color if edge_color else '#333333'
                    box_kwargs['color'] = draw_color
                sns.boxplot(
                    **box_kwargs,
                    boxprops={'facecolor': 'none', 'edgecolor': draw_color if draw_color else 'black', 'linewidth': 1.2},
                    medianprops={'color': draw_color if draw_color else 'black', 'linewidth': 1.2},
                    whiskerprops={'color': draw_color if draw_color else 'black', 'linewidth': 1.0},
                    capprops={'color': draw_color if draw_color else 'black', 'linewidth': 1.0}
                )
        except Exception:
            pass

    def _color_to_hex(self, color):
        try:
            return mcolors.to_hex(color)
        except Exception:
            return str(color)

    def _build_category_palette(self, categories, palette_name, explicit_map, fallback_color):
        palette_dict = {}
        if categories is None:
            return palette_dict
        explicit_map = explicit_map or {}
        for cat in categories:
            key = str(cat)
            if key in explicit_map and explicit_map[key]:
                palette_dict[cat] = explicit_map[key]
        missing = [cat for cat in categories if cat not in palette_dict]
        if missing:
            try:
                generated = sns.color_palette(palette_name if palette_name else 'deep', n_colors=len(missing))
                generated_hex = [self._color_to_hex(col) for col in generated]
            except Exception:
                generated_hex = [self.color_options[i % len(self.color_options)] for i in range(len(missing))]
            for cat, col in zip(missing, generated_hex):
                palette_dict[cat] = col
        if fallback_color and categories and all(cat not in palette_dict or not palette_dict[cat] for cat in categories):
            for cat in categories:
                palette_dict[cat] = fallback_color
        return palette_dict

    def _build_size_mapper(self, series, base_size):
        base_area = (base_size ** 2)
        if series is None:
            return lambda values: np.full(len(values), base_area)
        try:
            numeric_series = pd.to_numeric(series, errors='coerce')
            if numeric_series.notna().any():
                valid = numeric_series.dropna()
                min_v = valid.min()
                max_v = valid.max()
                if not np.isfinite(min_v):
                    min_v = 0.0
                if not np.isfinite(max_v):
                    max_v = min_v + 1.0
                span = max(max_v - min_v, 1e-9)

                def mapper(values):
                    vals = pd.to_numeric(values, errors='coerce').fillna(min_v)
                    norm = (vals - min_v) / span
                    norm = norm.clip(lower=0.0, upper=1.0)
                    factors = 0.6 + norm * 1.2  # scale between 0.6 and 1.8
                    return (base_size * factors.to_numpy()) ** 2

                return mapper
        except Exception:
            pass

        categories = [str(val) for val in pd.unique(series.dropna())]
        if not categories:
            return lambda values: np.full(len(values), base_area)
        factors = np.linspace(0.7, 1.6, num=len(categories)) if len(categories) > 1 else np.array([1.0])
        mapping = {cat: factors[idx] for idx, cat in enumerate(categories)}

        def mapper(values):
            vals = values.astype(str)
            computed = np.array([mapping.get(val, 1.0) for val in vals])
            return (base_size * computed) ** 2

        return mapper

    def _build_marker_mapper(self, series):
        if series is None:
            return lambda values: np.array(['o'] * len(values))
        markers_cycle = ['o', 'X', 's', '^', 'D', 'P', 'x', '+', '*', 'v', '>', '<', 'h', 'H', 'p']
        categories = [str(val) for val in pd.unique(series.dropna())]
        if not categories:
            return lambda values: np.array(['o'] * len(values))
        mapping = {cat: markers_cycle[idx % len(markers_cycle)] for idx, cat in enumerate(categories)}

        def mapper(values):
            vals = values.astype(str)
            return np.array([mapping.get(val, 'o') for val in vals])

        return mapper

    def _estimate_marker_radii(self, ax, point_size):
        try:
            fig = ax.figure
            if fig is None:
                raise ValueError("Missing figure context")
            bbox = ax.get_window_extent()
            if bbox.width <= 0 or bbox.height <= 0:
                raise ValueError("Invalid axis bounding box")
            xlim = ax.get_xlim()
            ylim = ax.get_ylim()
            x_range = abs(xlim[1] - xlim[0]) if np.all(np.isfinite(xlim)) else 1.0
            y_range = abs(ylim[1] - ylim[0]) if np.all(np.isfinite(ylim)) else 1.0
            pixels_per_point = fig.dpi / 72.0
            diameter_pixels = max(point_size, 1.0) * pixels_per_point
            radius_x = (diameter_pixels / max(bbox.width, 1.0)) * x_range * 0.5
            radius_y = (diameter_pixels / max(bbox.height, 1.0)) * y_range * 0.5
            if not np.isfinite(radius_x) or radius_x <= 0:
                radius_x = max(x_range * 0.015, 0.05)
            if not np.isfinite(radius_y) or radius_y <= 0:
                radius_y = max(y_range * 0.015, 0.05)
            return radius_x, radius_y
        except Exception:
            base = max(point_size * 0.01, 0.05)
            return base, base

    def _generate_symmetric_candidates(self, spacing, limit=200):
        yield 0.0
        step = max(spacing, 1e-4)
        for k in range(1, limit):
            yield step * k
            yield -step * k

    def _compute_center_offsets(self, y_values, spacing_x, radius_y):
        n = len(y_values)
        offsets = np.zeros(n, dtype=float)
        if n == 0:
            return offsets
        order = np.argsort(y_values)
        placed = []
        horizontal_step = max(spacing_x, 1e-4)
        vertical_scale = max(radius_y, 1e-4) * 1.05
        for idx in order:
            y_val = y_values[idx]
            assigned = False
            for candidate in self._generate_symmetric_candidates(horizontal_step):
                ok = True
                for px, py in placed:
                    dx = (candidate - px) / (horizontal_step * 1.05)
                    dy = (y_val - py) / vertical_scale
                    if dx * dx + dy * dy < 1.0:
                        ok = False
                        break
                if ok:
                    offsets[idx] = candidate
                    placed.append((candidate, y_val))
                    assigned = True
                    break
            if not assigned:
                offsets[idx] = 0.0
        return offsets

    def _compute_grid_offsets(self, y_values, spacing_x, row_threshold, hex_mode=False):
        n = len(y_values)
        offsets = np.zeros(n, dtype=float)
        if n == 0:
            return offsets
        order = np.argsort(y_values)
        rows = []
        threshold = max(row_threshold, 1e-4)
        for idx in order:
            y_val = y_values[idx]
            allocated = False
            for row in rows:
                if abs(y_val - row['anchor']) <= threshold:
                    row['indices'].append(idx)
                    allocated = True
                    break
            if not allocated:
                rows.append({'anchor': y_val, 'indices': [idx]})
        step = max(spacing_x, 0.04)
        for row_idx, row in enumerate(rows):
            members = row['indices']
            count = len(members)
            if count == 1:
                offsets[members[0]] = 0.0
                continue
            members_sorted = sorted(members, key=lambda i: y_values[i])
            if count % 2:
                center = count // 2
                row_offsets = [(i - center) * step for i in range(count)]
            else:
                center = count / 2 - 0.5
                row_offsets = [(i - center) * step for i in range(count)]
            if hex_mode and (row_idx % 2 == 1) and count > 1:
                row_offsets = [off + step / 2.0 for off in row_offsets]
            for member_idx, offset in zip(members_sorted, row_offsets):
                offsets[member_idx] = offset
        return offsets

    def _compute_point_offsets(self, y_values, method, spacing_x, row_threshold, radius_x, radius_y):
        values = np.asarray(y_values, dtype=float)
        if values.size == 0:
            return np.array([], dtype=float)
        if method == 'center':
            return self._compute_center_offsets(values, max(spacing_x, radius_x * 1.2), radius_y)
        if method == 'hex':
            return self._compute_grid_offsets(values, max(spacing_x, radius_x * 1.6), row_threshold, hex_mode=True)
        if method == 'square':
            return self._compute_grid_offsets(values, max(spacing_x, radius_x * 1.6), row_threshold, hex_mode=False)
        return np.zeros_like(values, dtype=float)

    def _resolve_point_color(self, hue_value, hue_index, palette_dict, palette_list, fallback):
        if palette_dict:
            if hue_value in palette_dict and palette_dict[hue_value]:
                return palette_dict[hue_value]
            hue_key = str(hue_value)
            if hue_key in palette_dict and palette_dict[hue_key]:
                return palette_dict[hue_key]
        if palette_list:
            try:
                return palette_list[hue_index % len(palette_list)]
            except Exception:
                pass
        return fallback if fallback else 'C0'

    def _plot_custom_point_layout(self, ax, data, x_col, y_col, order, hue_col, palette_arg, category_palette, default_color, point_size, method, size_col=None, size_mapper=None, style_col=None, style_mapper=None):
        method = (method or '').lower()
        if method not in ('center', 'hex', 'square'):
            return
        if data is None or data.empty or x_col not in data.columns or y_col not in data.columns:
            return
        if order:
            categories = [cat for cat in order if cat is not None and not (isinstance(cat, float) and np.isnan(cat))]
        else:
            categories = [cat for cat in pd.unique(data[x_col]) if pd.notna(cat)]
        if not categories:
            return

        category_palette = category_palette or {}
        category_palette_norm = {str(cat): self._color_to_hex(col) for cat, col in category_palette.items()}
        try:
            tick_positions = ax.get_xticks()
            tick_labels = [tick.get_text() for tick in ax.get_xticklabels()]
            label_map = {label: pos for label, pos in zip(tick_labels, tick_positions)}
        except Exception:
            label_map = {}
        enumerated_map = {str(cat): idx for idx, cat in enumerate(categories)}
        radius_x, radius_y = self._estimate_marker_radii(ax, point_size)
        spacing_x = max(radius_x * 1.6, 0.05)
        row_threshold = max(radius_y * 1.4, 0.05)
        base_area = point_size ** 2

        hue_levels = []
        if hue_col and hue_col in data.columns:
            hue_series = data[hue_col]
            hue_dtype = getattr(hue_series, 'dtype', None)
            if self._is_categorical(hue_dtype):
                hue_levels = [lvl for lvl in hue_series.cat.categories if pd.notna(lvl)]
            else:
                hue_levels = [lvl for lvl in pd.unique(hue_series.dropna())]

        palette_dict = None
        palette_list = None
        if hue_levels:
            if isinstance(palette_arg, dict):
                palette_dict = {str(k): self._color_to_hex(v) for k, v in palette_arg.items()}
            elif isinstance(palette_arg, (list, tuple)):
                palette_list = [self._color_to_hex(col) for col in palette_arg]
            elif isinstance(palette_arg, str):
                try:
                    palette_list = list(sns.color_palette(palette_arg, n_colors=len(hue_levels)))
                    palette_list = [self._color_to_hex(col) for col in palette_list]
                except Exception:
                    palette_list = None
            if palette_list is None and palette_dict is None:
                try:
                    palette_list = [self._color_to_hex(col) for col in sns.color_palette('deep', n_colors=len(hue_levels))]
                except Exception:
                    palette_list = None

        if hue_levels:
            if len(hue_levels) > 1:
                dodge_total = max(spacing_x * (len(hue_levels) - 1) * 1.3, spacing_x * 2.5)
                hue_offsets = np.linspace(-dodge_total / 2.0, dodge_total / 2.0, len(hue_levels))
            else:
                hue_offsets = np.array([0.0])
        else:
            hue_offsets = None

        def compute_sizes(series, length):
            if size_mapper:
                try:
                    return size_mapper(series if series is not None else pd.Series([np.nan] * length))
                except Exception:
                    pass
            return np.full(length, base_area)

        def compute_markers(series, length):
            if style_mapper:
                try:
                    marker_arr = style_mapper(series if series is not None else pd.Series([np.nan] * length))
                    return np.array(marker_arr)
                except Exception:
                    pass
            return np.array(['o'] * length)

        for cat in categories:
            subset = data[data[x_col] == cat]
            if subset.empty:
                continue
            numeric_series = pd.to_numeric(subset[y_col], errors='coerce')
            valid_mask = numeric_series.notna()
            if not valid_mask.any():
                continue
            subset_valid = subset.loc[valid_mask]
            y_vals_full = numeric_series[valid_mask].to_numpy()
            base_label = str(cat)
            base_x = label_map.get(base_label)
            if base_x is None:
                base_x = enumerated_map.get(base_label)
            if base_x is None:
                new_position = len(enumerated_map)
                enumerated_map[base_label] = new_position
                base_x = new_position

            base_color = category_palette_norm.get(base_label, default_color if default_color else 'C0')

            if hue_levels:
                for hue_idx, hue_val in enumerate(hue_levels):
                    hue_subset = subset_valid[subset_valid[hue_col] == hue_val]
                    if hue_subset.empty:
                        continue
                    y_numeric = pd.to_numeric(hue_subset[y_col], errors='coerce')
                    valid_local = y_numeric.notna()
                    if not valid_local.any():
                        continue
                    hue_valid = hue_subset.loc[valid_local]
                    y_vals = y_numeric[valid_local].to_numpy()
                    offsets = self._compute_point_offsets(y_vals, method, spacing_x, row_threshold, radius_x, radius_y)
                    size_series = hue_valid[size_col] if size_col and size_col in hue_valid.columns else None
                    sizes = compute_sizes(size_series, len(hue_valid))
                    style_series = hue_valid[style_col] if style_col and style_col in hue_valid.columns else None
                    markers = compute_markers(style_series, len(hue_valid))
                    color = self._resolve_point_color(hue_val, hue_idx, palette_dict, palette_list, base_color)
                    base_offset = hue_offsets[hue_idx] if hue_offsets is not None else 0.0
                    for marker in np.unique(markers):
                        idx_mask = markers == marker
                        if not np.any(idx_mask):
                            continue
                        ax.scatter(base_x + base_offset + offsets[idx_mask], y_vals[idx_mask], s=sizes[idx_mask], marker=marker,
                                   color=color, alpha=0.85, edgecolors='none', linewidths=0, zorder=4)
            else:
                y_vals = y_vals_full
                offsets = self._compute_point_offsets(y_vals, method, spacing_x, row_threshold, radius_x, radius_y)
                size_series = subset_valid[size_col] if size_col and size_col in subset_valid.columns else None
                sizes = compute_sizes(size_series, len(subset_valid))
                style_series = subset_valid[style_col] if style_col and style_col in subset_valid.columns else None
                markers = compute_markers(style_series, len(subset_valid))
                for marker in np.unique(markers):
                    idx_mask = markers == marker
                    if not np.any(idx_mask):
                        continue
                    ax.scatter(base_x + offsets[idx_mask], y_vals[idx_mask], s=sizes[idx_mask], marker=marker,
                               color=base_color, alpha=0.85, edgecolors='none', linewidths=0, zorder=4)

    def _generate_chart(self):
        self._clear_chart_display()
        chart_type = self.chart_type_var.get()

        if self.data is None:
            messagebox.showwarning("Sin Datos", "Por favor, cargue un archivo de datos primero.", parent=self.parent_for_dialogs)
            return
        if not chart_type:
            messagebox.showwarning("Sin Selección", "Por favor, seleccione un tipo de gráfico.", parent=self.parent_for_dialogs)
            return

        filtered_data = self.filter_component.apply_filters()

        if filtered_data is not None:
            for param_name in dir(self):
                if param_name.endswith('_recode_var'):
                    recode_var = getattr(self, param_name)
                    if recode_var and isinstance(recode_var, tk.StringVar) and recode_var.get():
                        col_var_name = param_name.replace('_recode_var', '_var')
                        if hasattr(self, col_var_name):
                            col_var = getattr(self, col_var_name)
                            column_name = col_var.get()
                            if column_name:
                                filtered_data = self._apply_recode(filtered_data, column_name, recode_var.get())
        if filtered_data is None:
            self.log("Error al aplicar filtros.", "ERROR")
            return
        
        if filtered_data.empty:
            self.log("No quedan datos después de aplicar los filtros.", "WARN")
            messagebox.showinfo("Datos Vacíos", "No quedan datos después de aplicar los filtros.", parent=self.parent_for_dialogs)
            return

        axis_x_col = None
        axis_y_col = None
        tick_data_x = None
        tick_data_y = None

        def mark_axis(axis_name, column_name, data_frame=None, *, force=False):
            nonlocal axis_x_col, axis_y_col, tick_data_x, tick_data_y
            if not column_name:
                return
            df_ref = data_frame if data_frame is not None else filtered_data
            if df_ref is None or column_name not in df_ref.columns:
                return
            try:
                series_ref = df_ref[column_name]
            except Exception:
                return

            try:
                is_cat = self._is_categorical(series_ref)
            except Exception:
                is_cat = False

            try:
                is_obj = pd.api.types.is_object_dtype(series_ref)
            except Exception:
                is_obj = False

            if not (is_cat or is_obj):
                return

            if axis_name == 'x':
                if force or axis_x_col is None:
                    axis_x_col = column_name
                    tick_data_x = df_ref
            elif axis_name == 'y':
                if force or axis_y_col is None:
                    axis_y_col = column_name
                    tick_data_y = df_ref

        self.log(f"Generando gráfico: {chart_type}", "INFO")
        params_used_log = [f"Tipo de Gráfico: {chart_type}"]

        try:
            # --- Get Customization Options ---
            title = self.param_title_var.get()
            xlabel = self.param_xlabel_var.get()
            ylabel = self.param_ylabel_var.get()
            grid = self.param_grid_var.get()
            xlim_raw = self.param_xlim_var.get()
            ylim_raw = self.param_ylim_var.get()
            theme = self.param_theme_var.get()
            palette = self.param_palette_var.get()
            point_size_str = self.param_point_size_var.get()
            try:
                point_size = float(point_size_str) if point_size_str else 5.0
            except Exception:
                self.log(f"Tamaño de puntos inválido '{point_size_str}', se usará 5.", "WARN")
                point_size = 5.0
            if point_size <= 0:
                self.log(f"Tamaño de puntos no positivo ({point_size}); se ajusta a 0.1.", "WARN")
                point_size = 0.1

            point_color_raw = getattr(self, 'param_point_color_var', StringVar(value='auto')).get()
            point_color = point_color_raw.strip() if point_color_raw else ''
            point_color = None if not point_color or point_color.lower() == 'auto' else point_color
            params_used_log.append(f"  Tamaño puntos: {point_size}")
            if point_color:
                params_used_log.append(f"  Color puntos: {point_color}")

            # Violin / Legend fine controls
            try:
                violin_bw = float(getattr(self, 'param_violin_bw_var', StringVar(value='0.2')).get())
            except Exception:
                violin_bw = 0.2
            try:
                violin_width = float(getattr(self, 'param_violin_width_var', StringVar(value='0.8')).get())
            except Exception:
                violin_width = 0.8
            box_overlay_width = max(0.05, min(violin_width * 0.65, 0.95))
            try:
                violin_alpha = float(getattr(self, 'param_violin_alpha_var', StringVar(value='0.6')).get())
            except Exception:
                violin_alpha = 0.6

            show_legend = getattr(self, 'param_show_legend_var', tk.BooleanVar(value=True)).get()
            legend_loc = getattr(self, 'param_legend_loc_var', StringVar(value='best')).get()
            try:
                legend_size = int(getattr(self, 'param_legend_size_var', StringVar(value='10')).get())
            except Exception:
                legend_size = 10

            # New advanced options
            tick_rotation = int(self.param_tick_rotation_var.get())
            x_scale = self.param_xscale_var.get()
            y_scale = self.param_yscale_var.get()
            fig_width = float(self.param_fig_width_var.get())
            fig_height = float(self.param_fig_height_var.get())

            palette = palette if palette != 'default' else None
            # Seaborn set_theme accepts style as a positional string in many versions; pass as positional to avoid typing issues
            # Apply per-chart font family if selected
            try:
                font_family_sel = getattr(self, 'param_font_family_var', StringVar(value='Default')).get()
                if font_family_sel and font_family_sel != 'Default':
                    try:
                        plt.rcParams['font.family'] = font_family_sel
                    except Exception:
                        pass
            except Exception:
                pass

            try:
                sns.set_theme(style=theme, palette=palette)
            except Exception:
                # Fallback: pass style as positional arg
                sns.set_theme(theme, palette=palette)
            params_used_log.append(f"  Tema: {theme}")
            if palette: params_used_log.append(f"  Paleta: {palette}")
            
            plt_fig, ax = plt.subplots(figsize=(fig_width, fig_height))

            # --- Main Plotting Logic (to be refactored) ---
            # NOTE: This section will be updated next to handle the new consolidated chart types.
            if chart_type == "Diagrama de Dispersión":
                x_col = self.param_x_var.get()
                y_col = self.param_y_var.get()
                
                if not x_col or not y_col:
                    messagebox.showerror("Error", "Debe seleccionar las variables X e Y.", parent=self.parent_for_dialogs)
                    plt.close(plt_fig) # Close the figure to avoid showing an empty plot
                    return

                params_used_log.extend([f"  X: {x_col}", f"  Y: {y_col}"])

                color_col = self.param_color_var.get()
                size_col = self.param_size_var.get()
                fit_reg = self.param_scatter_fit_reg_var.get()

                plot_kwargs = {
                    'data': filtered_data,
                    'x': x_col,
                    'y': y_col,
                    'ax': ax
                }
                if color_col:
                    plot_kwargs['hue'] = color_col
                    params_used_log.append(f"  Color: {color_col}")
                if size_col:
                    plot_kwargs['size'] = size_col
                    params_used_log.append(f"  Tamaño: {size_col}")

                if fit_reg:
                    params_used_log.append("  Línea de Regresión: Sí")
                    sns.regplot(**plot_kwargs)
                else:
                    params_used_log.append("  Línea de Regresión: No")
                    sns.scatterplot(**plot_kwargs)

                mark_axis('x', x_col)
                mark_axis('y', y_col)

            elif chart_type == "Histograma":
                x_col = self.param_hist_var.get()
                if not x_col:
                    messagebox.showerror("Error", "Debe seleccionar una variable numérica.", parent=self.parent_for_dialogs)
                    plt.close(plt_fig)
                    return

                params_used_log.append(f"  Variable: {x_col}")
                
                hue_col = self.param_hist_hue_var.get()
                bins_str = self.param_hist_bins_var.get()
                show_kde = self.param_hist_kde_var.get()
                orientation = self.param_hist_orientation_var.get()

                plot_kwargs = {
                    'data': filtered_data,
                    'kde': show_kde,
                    'ax': ax
                }

                if orientation == "Horizontal":
                    plot_kwargs['y'] = x_col
                else:
                    plot_kwargs['x'] = x_col

                if hue_col:
                    plot_kwargs['hue'] = hue_col
                    params_used_log.append(f"  Hue: {hue_col}")

                if bins_str and bins_str.lower() != 'auto':
                    try:
                        plot_kwargs['bins'] = int(bins_str)
                        params_used_log.append(f"  Bins: {bins_str}")
                    except ValueError:
                        self.log(f"Número de bins inválido: '{bins_str}'. Usando 'auto'.", "WARN")
                
                sns.histplot(**plot_kwargs)

            elif chart_type == "Gráfico de Barras":
                mode_raw = getattr(self, 'param_bar_mode_var', StringVar(value='Simple')).get()
                mode = (mode_raw or 'Simple').strip().lower()
                if mode not in ('simple', 'agrupado', 'apilado', 'segmentado'):
                    mode = 'simple'
                params_used_log.append(f"  Modo barras: {mode_raw}")

                x_col = self.param_bar_x_var.get().strip() if self.param_bar_x_var.get() else ""
                y_raw = self.param_bar_y_var.get().strip() if self.param_bar_y_var.get() else ""
                hue_raw = self.param_bar_hue_var.get().strip() if self.param_bar_hue_var.get() else ""
                orientation = self.param_bar_orientation_var.get()

                if not x_col:
                    messagebox.showerror("Error", "Debe seleccionar la variable de eje.", parent=self.parent_for_dialogs)
                    plt.close(plt_fig)
                    return

                y_col = y_raw if y_raw else None
                hue_col = hue_raw if hue_raw else None

                params_used_log.append(f"  Categorías: {x_col}")
                if y_col and mode != 'segmentado':
                    params_used_log.append(f"  Valores: {y_col}")
                if hue_col and mode != 'segmentado':
                    params_used_log.append(f"  Hue: {hue_col}")
                params_used_log.append(f"  Orientación: {orientation}")

                if orientation == "Horizontal":
                    mark_axis('y', x_col)
                else:
                    mark_axis('x', x_col)

                plot_data = filtered_data.copy()

                category_order = None
                hue_order = None

                try:
                    series_x = filtered_data[x_col]
                    if pd.api.types.is_categorical_dtype(series_x):
                        category_order = [str(cat) for cat in series_x.cat.categories]
                    else:
                        category_order = list(dict.fromkeys(series_x.dropna().tolist()))
                except Exception:
                    category_order = None

                plot_data[x_col] = plot_data[x_col].astype(str)
                if category_order is not None:
                    category_order = [str(val) for val in category_order]
                else:
                    category_order = list(dict.fromkeys(plot_data[x_col].tolist()))

                hue_levels = None
                if hue_col and mode != 'segmentado':
                    try:
                        series_h = filtered_data[hue_col]
                        if pd.api.types.is_categorical_dtype(series_h):
                            hue_order = [str(cat) for cat in series_h.cat.categories]
                        else:
                            hue_order = list(dict.fromkeys(series_h.dropna().tolist()))
                    except Exception:
                        hue_order = None

                    plot_data[hue_col] = plot_data[hue_col].astype(str)
                    if hue_order is not None:
                        hue_order = [str(val) for val in hue_order]
                    else:
                        hue_order = list(dict.fromkeys(plot_data[hue_col].tolist()))
                    hue_levels = hue_order

                bar_color_mode = getattr(self, 'param_bar_color_mode_var', StringVar(value='auto')).get() if hasattr(self, 'param_bar_color_mode_var') else 'auto'
                bar_color_mode = (bar_color_mode or 'auto').strip().lower()
                base_color_raw = getattr(self, 'param_bar_single_color_var', StringVar(value='#4C72B0')).get() if hasattr(self, 'param_bar_single_color_var') else '#4C72B0'
                base_color_raw = base_color_raw.strip() if base_color_raw else ''
                palette_choice = getattr(self, 'param_bar_palette_choice_var', StringVar(value='deep')).get() if hasattr(self, 'param_bar_palette_choice_var') else 'deep'
                palette_choice = (palette_choice or '').strip().lower()
                if palette_choice == 'default':
                    palette_choice = ''

                base_color = base_color_raw if base_color_raw else None

                if bar_color_mode and bar_color_mode != 'auto':
                    params_used_log.append(f"  Modo color barras: {bar_color_mode}")
                if bar_color_mode == 'un color' and base_color:
                    params_used_log.append(f"    Color único: {base_color}")
                if bar_color_mode == 'paleta' and palette_choice:
                    params_used_log.append(f"    Paleta: {palette_choice}")

                try:
                    if mode in ('simple', 'agrupado'):
                        if mode == 'agrupado' and not hue_col:
                            self.log("Se seleccionó modo 'Agrupado' sin variable de color; se graficará como barras simples.", "WARN")

                        palette_spec = None
                        color_spec = None
                        if bar_color_mode == 'un color' and base_color:
                            single_color = self._color_to_hex(base_color)
                            if hue_col and hue_levels:
                                palette_spec = {str(level): single_color for level in hue_levels}
                            else:
                                color_spec = single_color
                        elif bar_color_mode == 'paleta':
                            if hue_col:
                                palette_spec = palette_choice if palette_choice else None
                            else:
                                palette_spec = palette_choice if palette_choice else None

                        if isinstance(palette_spec, dict):
                            normalized_palette = {}
                            for key, value in palette_spec.items():
                                color_hex = self._color_to_hex(value)
                                normalized_palette[str(key)] = color_hex
                            palette_spec = normalized_palette

                        if y_col:
                            plot_kwargs = {
                                'data': plot_data,
                                'hue': hue_col if hue_col else None,
                                'ax': ax
                            }
                            if hue_order:
                                plot_kwargs['hue_order'] = hue_order
                            if palette_spec is not None:
                                plot_kwargs['palette'] = palette_spec
                            elif color_spec is not None:
                                plot_kwargs['color'] = color_spec

                            if orientation == "Horizontal":
                                plot_kwargs.update({'x': y_col, 'y': x_col})
                                if category_order:
                                    plot_kwargs['order'] = category_order
                            else:
                                plot_kwargs.update({'x': x_col, 'y': y_col})
                                if category_order:
                                    plot_kwargs['order'] = category_order

                            sns.barplot(**plot_kwargs)
                        else:
                            plot_kwargs = {
                                'data': plot_data,
                                'hue': hue_col if hue_col else None,
                                'ax': ax
                            }
                            if hue_order:
                                plot_kwargs['hue_order'] = hue_order
                            if palette_spec is not None:
                                plot_kwargs['palette'] = palette_spec
                            elif color_spec is not None:
                                plot_kwargs['color'] = color_spec

                            if orientation == "Horizontal":
                                plot_kwargs.update({'y': x_col})
                                if category_order:
                                    plot_kwargs['order'] = category_order
                            else:
                                plot_kwargs.update({'x': x_col})
                                if category_order:
                                    plot_kwargs['order'] = category_order

                            sns.countplot(**plot_kwargs)

                        if orientation == "Horizontal":
                            mark_axis('y', x_col, plot_data, force=True)
                        else:
                            mark_axis('x', x_col, plot_data, force=True)

                    elif mode == 'apilado':
                        if not hue_col:
                            plt.close(plt_fig)
                            messagebox.showerror("Error", "Seleccione una variable en 'Agrupar por Color' para apilar las barras.", parent=self.parent_for_dialogs)
                            return

                        normalize_100 = getattr(self, 'param_stacked_100_var', tk.BooleanVar(value=False)).get()
                        params_used_log.append(f"  Normalizar a 100%: {'Sí' if normalize_100 else 'No'}")

                        value_field = y_col if y_col else '_count'
                        if y_col:
                            value_data = filtered_data[[x_col, hue_col, y_col]].dropna(subset=[x_col, hue_col])
                            value_data[y_col] = pd.to_numeric(value_data[y_col], errors='coerce').fillna(0.0)
                            grouped = value_data.groupby([x_col, hue_col], dropna=False)[y_col].sum().reset_index(name=value_field)
                        else:
                            value_data = filtered_data[[x_col, hue_col]].dropna(subset=[x_col, hue_col])
                            grouped = value_data.groupby([x_col, hue_col], dropna=False).size().reset_index(name=value_field)

                        grouped[x_col] = grouped[x_col].astype(str)
                        grouped[hue_col] = grouped[hue_col].astype(str)

                        if category_order:
                            grouped['_cat_order'] = grouped[x_col].apply(lambda v: category_order.index(v) if v in category_order else len(category_order))
                        else:
                            grouped['_cat_order'] = grouped[x_col].rank(method='dense')
                        if hue_levels:
                            grouped['_hue_order'] = grouped[hue_col].apply(lambda v: hue_levels.index(v) if v in hue_levels else len(hue_levels))
                        else:
                            grouped['_hue_order'] = grouped[hue_col].rank(method='dense')

                        grouped = grouped.sort_values(['_cat_order', '_hue_order']).drop(columns=['_cat_order', '_hue_order'])

                        pivot = grouped.pivot(index=x_col, columns=hue_col, values=value_field).fillna(0.0)
                        if category_order:
                            pivot = pivot.reindex(category_order, axis=0)
                        if hue_levels:
                            pivot = pivot.reindex(hue_levels, axis=1)

                        pivot = pivot.fillna(0.0)
                        categories = list(pivot.index)
                        stack_levels = list(pivot.columns)
                        if not stack_levels:
                            plt.close(plt_fig)
                            messagebox.showwarning("Datos Vacíos", "No hay categorías disponibles para la variable de color seleccionada.", parent=self.parent_for_dialogs)
                            return
                        values_matrix = pivot.to_numpy(dtype=float)

                        if normalize_100:
                            totals = values_matrix.sum(axis=1)
                            totals[totals == 0] = np.nan
                            values_matrix = np.divide(values_matrix, totals[:, None]) * 100.0
                            values_matrix = np.nan_to_num(values_matrix, nan=0.0)

                        def resolve_stack_colors(levels):
                            if not levels:
                                return []
                            colors_local = []
                            if bar_color_mode == 'un color' and base_color:
                                single_hex = self._color_to_hex(base_color)
                                colors_local = [single_hex] * len(levels)
                            elif bar_color_mode == 'paleta' and palette_choice:
                                try:
                                    palette_generated = sns.color_palette(palette_choice, n_colors=len(levels))
                                    colors_local = [self._color_to_hex(col) for col in palette_generated]
                                except Exception:
                                    colors_local = []
                            if not colors_local:
                                try:
                                    base_palette = palette_choice if palette_choice else 'deep'
                                    palette_generated = sns.color_palette(base_palette, n_colors=len(levels))
                                    colors_local = [self._color_to_hex(col) for col in palette_generated]
                                except Exception:
                                    colors_local = [self.color_options[idx % len(self.color_options)] for idx in range(len(levels))]
                            if len(colors_local) < len(levels):
                                fallback_colors = [self.color_options[idx % len(self.color_options)] for idx in range(len(levels))]
                                while len(colors_local) < len(levels):
                                    colors_local.append(fallback_colors[len(colors_local) % len(fallback_colors)])
                            return colors_local

                        stack_colors = resolve_stack_colors(stack_levels)

                        if orientation == "Horizontal":
                            indices = np.arange(len(categories))
                            cumulative = np.zeros(len(categories))
                            for idx_level, (level, color_hex) in enumerate(zip(stack_levels, stack_colors)):
                                segment_values = values_matrix[:, idx_level]
                                ax.barh(indices, segment_values, left=cumulative, color=color_hex, label=str(level))
                                cumulative += segment_values
                            ax.set_yticks(indices)
                            ax.set_yticklabels(categories)
                            category_df = pd.DataFrame({x_col: categories})
                            mark_axis('y', x_col, category_df, force=True)
                        else:
                            indices = np.arange(len(categories))
                            cumulative = np.zeros(len(categories))
                            for idx_level, (level, color_hex) in enumerate(zip(stack_levels, stack_colors)):
                                segment_values = values_matrix[:, idx_level]
                                ax.bar(indices, segment_values, bottom=cumulative, color=color_hex, label=str(level))
                                cumulative += segment_values
                            ax.set_xticks(indices)
                            ax.set_xticklabels(categories)
                            category_df = pd.DataFrame({x_col: categories})
                            mark_axis('x', x_col, category_df, force=True)

                        if normalize_100 and not ylabel:
                            ax.set_ylabel('Porcentaje (%)')

                        if show_legend:
                            ax.legend(loc=legend_loc)
                        else:
                            legend = ax.get_legend()
                            if legend is not None:
                                legend.remove()

                    elif mode == 'segmentado':
                        normalize_100 = getattr(self, 'param_bar_segment_normalize_var', tk.BooleanVar(value=False)).get()
                        params_used_log.append(f"  Normalizar segmentos a 100%: {'Sí' if normalize_100 else 'No'}")

                        segment_pairs = getattr(self, 'param_bar_segment_vars', []) or []
                        segment_cols = []
                        segment_labels = []
                        for var_pair in segment_pairs:
                            if not isinstance(var_pair, tuple) or len(var_pair) < 2:
                                continue
                            var_obj, label_obj = var_pair
                            col_name = var_obj.get().strip() if var_obj and var_obj.get() else ''
                            if not col_name:
                                continue
                            if col_name not in filtered_data.columns:
                                self.log(f"Columna de segmento '{col_name}' no encontrada en los datos filtrados.", "WARN")
                                continue
                            if not pd.api.types.is_numeric_dtype(filtered_data[col_name]):
                                self.log(f"Columna de segmento '{col_name}' no es numérica; se omite.", "WARN")
                                continue
                            display_label = label_obj.get().strip() if label_obj and label_obj.get() else col_name
                            segment_cols.append(col_name)
                            segment_labels.append(display_label)

                        if len(segment_cols) < 2:
                            plt.close(plt_fig)
                            messagebox.showerror("Error", "Seleccione al menos dos columnas numéricas para formar los segmentos de cada barra.", parent=self.parent_for_dialogs)
                            return

                        params_used_log.append(f"  Segmentos: {', '.join(segment_labels)}")

                        data_columns = [x_col] + segment_cols
                        plot_source = filtered_data[data_columns].copy()
                        plot_source = plot_source.dropna(subset=[x_col])
                        plot_source[segment_cols] = plot_source[segment_cols].apply(pd.to_numeric, errors='coerce').fillna(0.0)
                        if plot_source.empty:
                            plt.close(plt_fig)
                            messagebox.showwarning("Datos Vacíos", "No hay datos disponibles para las columnas seleccionadas.", parent=self.parent_for_dialogs)
                            return

                        try:
                            grouped = plot_source.groupby(x_col, dropna=False)[segment_cols].sum().reset_index()
                        except Exception as exc:
                            plt.close(plt_fig)
                            self.log(f"Error al agrupar datos para barras segmentadas: {exc}", "ERROR")
                            messagebox.showerror("Error", f"No se pudo preparar la información para el gráfico:\n{exc}", parent=self.parent_for_dialogs)
                            return

                        if grouped.empty:
                            plt.close(plt_fig)
                            messagebox.showwarning("Datos Vacíos", "La agrupación resultó vacía para las columnas seleccionadas.", parent=self.parent_for_dialogs)
                            return

                        grouped[x_col] = grouped[x_col].astype(str)
                        if category_order:
                            grouped['_order_index'] = grouped[x_col].apply(lambda val: category_order.index(val) if val in category_order else len(category_order))
                            grouped = grouped.sort_values('_order_index').drop(columns=['_order_index'])

                        categories = grouped[x_col].tolist()
                        values_matrix = grouped[segment_cols].to_numpy(dtype=float)

                        if normalize_100:
                            totals = values_matrix.sum(axis=1)
                            totals[totals == 0] = np.nan
                            values_matrix = np.divide(values_matrix, totals[:, None]) * 100.0
                            values_matrix = np.nan_to_num(values_matrix, nan=0.0)

                        palette_choice_segments = getattr(self, 'param_bar_segment_palette_var', StringVar(value='deep')).get()
                        palette_choice_segments = (palette_choice_segments or '').strip()
                        custom_colors_raw = getattr(self, 'param_bar_segment_custom_colors_var', StringVar(value='')).get()
                        custom_tokens = [tok.strip() for tok in custom_colors_raw.split(',') if tok.strip()]
                        colors = [self._color_to_hex(token) for token in custom_tokens]

                        if len(colors) < len(segment_cols):
                            palette_name = palette_choice_segments if palette_choice_segments else 'deep'
                            try:
                                palette_generated = sns.color_palette(palette_name, n_colors=len(segment_cols))
                                palette_generated = [self._color_to_hex(col) for col in palette_generated]
                            except Exception:
                                palette_generated = [self.color_options[idx % len(self.color_options)] for idx in range(len(segment_cols))]
                            while len(colors) < len(segment_cols):
                                colors.append(palette_generated[len(colors) % len(palette_generated)])

                        params_used_log.append(f"  Paleta segmentos: {palette_choice_segments if palette_choice_segments else 'auto'}")
                        if custom_tokens:
                            params_used_log.append(f"  Colores personalizados: {', '.join(custom_tokens)}")

                        indices = np.arange(len(categories))
                        cumulative = np.zeros(len(categories))

                        if orientation == "Horizontal":
                            for seg_idx, (label, color_hex) in enumerate(zip(segment_labels, colors)):
                                segment_values = values_matrix[:, seg_idx]
                                ax.barh(indices, segment_values, left=cumulative, color=color_hex, label=label)
                                cumulative += segment_values
                            ax.set_yticks(indices)
                            ax.set_yticklabels(categories)
                            category_df = pd.DataFrame({x_col: categories})
                            mark_axis('y', x_col, category_df, force=True)
                        else:
                            for seg_idx, (label, color_hex) in enumerate(zip(segment_labels, colors)):
                                segment_values = values_matrix[:, seg_idx]
                                ax.bar(indices, segment_values, bottom=cumulative, color=color_hex, label=label)
                                cumulative += segment_values
                            ax.set_xticks(indices)
                            ax.set_xticklabels(categories)
                            category_df = pd.DataFrame({x_col: categories})
                            mark_axis('x', x_col, category_df, force=True)

                        if normalize_100 and not ylabel:
                            ax.set_ylabel('Porcentaje (%)')

                        if show_legend:
                            ax.legend(loc=legend_loc)
                        else:
                            legend = ax.get_legend()
                            if legend is not None:
                                legend.remove()

                except Exception as exc:
                    plt.close(plt_fig)
                    self.log(f"Error generando gráfico de barras: {exc}", "ERROR")
                    messagebox.showerror("Error", f"No se pudo generar el gráfico de barras:\n{exc}", parent=self.parent_for_dialogs)
                    return

            elif chart_type == "Gráfico de Líneas / Área":
                x_col = self.param_line_x_var.get()
                y_col = self.param_line_y_var.get()

                if not x_col or not y_col:
                    messagebox.showerror("Error", "Debe seleccionar las variables X e Y.", parent=self.parent_for_dialogs)
                    plt.close(plt_fig)
                    return

                params_used_log.extend([f"  X: {x_col}", f"  Y: {y_col}"])

                hue_col = self.param_line_hue_var.get()
                fill_area = self.param_area_fill_var.get()

                plot_kwargs = {
                    'data': filtered_data,
                    'x': x_col,
                    'y': y_col,
                    'ax': ax
                }

                if hue_col:
                    plot_kwargs['hue'] = hue_col
                    params_used_log.append(f"  Hue: {hue_col}")

                sns.lineplot(**plot_kwargs)

                if fill_area:
                    params_used_log.append("  Rellenar Área: Sí")
                    # Get lines from the plot to fill under them
                    lines = ax.get_lines()
                    for line in lines:
                        ax.fill_between(line.get_xdata(), line.get_ydata(), alpha=0.2, color=line.get_color())

                mark_axis('x', x_col)
                mark_axis('y', y_col)
            
            elif chart_type == "Gráfico de Densidad":
                x_col = self.param_density_var.get()
                if not x_col:
                    messagebox.showerror("Error", "Debe seleccionar una variable numérica.", parent=self.parent_for_dialogs)
                    plt.close(plt_fig)
                    return

                params_used_log.append(f"  Variable: {x_col}")

                hue_col = self.param_density_hue_var.get()

                plot_kwargs = {
                    'data': filtered_data,
                    'x': x_col,
                    'ax': ax,
                    'fill': True
                }

                if hue_col:
                    plot_kwargs['hue'] = hue_col
                    params_used_log.append(f"  Hue: {hue_col}")
                
                sns.kdeplot(**plot_kwargs)

            # This is a placeholder for the new logic. It will be fully implemented in the next step.
            elif chart_type == "Gráfico de Distribución":
                # Parameters
                y_var = getattr(self, 'param_dist_y_var', None)
                x_var = getattr(self, 'param_dist_x_var', None)
                hue_var = getattr(self, 'param_dist_hue_var', None)
                point_type_var = getattr(self, 'param_dist_point_type_var', None)
                size_var = getattr(self, 'param_dist_size_var', None)
                style_var = getattr(self, 'param_dist_style_var', None)
                show_box = getattr(self, 'param_dist_show_box_var', tk.BooleanVar(value=False)).get()
                show_violin = getattr(self, 'param_dist_show_violin_var', tk.BooleanVar(value=False)).get()
                raincloud = getattr(self, 'param_dist_raincloud_var', tk.BooleanVar(value=False)).get()

                y_col = y_var.get() if y_var is not None else None
                x_col = x_var.get() if x_var is not None else None
                hue_col = hue_var.get() if hue_var is not None else None
                point_type = point_type_var.get() if point_type_var is not None else 'Ninguno'
                size_col = size_var.get().strip() if size_var is not None and size_var.get() else ''
                style_col = style_var.get().strip() if style_var is not None and style_var.get() else ''
                size_col = size_col if size_col else None
                style_col = style_col if style_col else None
                layout_method_raw = getattr(self, 'param_dist_layout_method_var', StringVar(value='Auto')).get()
                layout_method_raw = layout_method_raw.strip() if layout_method_raw else 'Auto'
                jitter_width_raw = getattr(self, 'param_dist_jitter_width_var', StringVar(value='0.20')).get()
                try:
                    jitter_width = float(jitter_width_raw)
                except Exception:
                    jitter_width = 0.2
                if jitter_width < 0:
                    jitter_width = 0.0
                jitter_effective = jitter_width

                if raincloud and not show_violin:
                    show_violin = True
                    params_used_log.append("  Raincloud requiere violín: activado automáticamente")

                params_used_log.append(f"  Y: {y_col}")
                if x_col: params_used_log.append(f"  X (categoría): {x_col}")
                if hue_col: params_used_log.append(f"  Hue: {hue_col}")
                params_used_log.append(f"  Mostrar caja: {show_box}")
                params_used_log.append(f"  Mostrar violín: {show_violin}")
                params_used_log.append(f"  Raincloud: {raincloud}")
                params_used_log.append(f"  Tipo puntos: {point_type}")
                if size_col:
                    params_used_log.append(f"  Variable tamaño: {size_col}")
                if style_col:
                    params_used_log.append(f"  Variable forma: {style_col}")
                params_used_log.append(f"  Método acomodo: {layout_method_raw}")
                params_used_log.append(f"  Jitter aleatorio: {jitter_width}")

                if not y_col or y_col not in filtered_data.columns:
                    messagebox.showerror("Error", "Seleccione una variable numérica para el eje Y.", parent=self.parent_for_dialogs)
                    return

                if x_col:
                    mark_axis('x', x_col, filtered_data)

                # Clean data subset
                columns_needed = [y_col]
                if x_col:
                    columns_needed.append(x_col)
                if hue_col:
                    columns_needed.append(hue_col)
                if size_col:
                    columns_needed.append(size_col)
                if style_col:
                    columns_needed.append(style_col)

                drop_subset = [y_col]
                if x_col:
                    drop_subset.append(x_col)
                if hue_col:
                    drop_subset.append(hue_col)

                plot_df = filtered_data[columns_needed].dropna(subset=drop_subset)

                # Determine order for X axis labels and ensure the plotting column is string-based
                x_order = None
                x_col_original = x_col  # Save original x_col before any modifications
                if x_col:
                    plot_df = plot_df.copy()
                    if self._is_categorical(plot_df[x_col]):
                        categories = list(plot_df[x_col].cat.categories)
                        x_order = [str(cat) for cat in categories]
                        plot_df[x_col] = plot_df[x_col].astype(str)
                        self.log(f"Variable categórica '{x_col}' detectada. Orden: {x_order}", "DEBUG")
                    else:
                        # Preserve the order of appearance to keep intuitive ordering
                        unique_vals = list(dict.fromkeys(plot_df[x_col].tolist()))
                        x_order = [str(v) for v in unique_vals]
                        plot_df[x_col] = plot_df[x_col].astype(str)
                        self.log(f"Variable '{x_col}' convertida a string. Orden: {x_order}", "DEBUG")

                    if x_order:
                        try:
                            plot_df[x_col] = pd.Categorical(plot_df[x_col], categories=x_order, ordered=True)
                        except Exception:
                            # Fallback: leave as string if categorical creation fails
                            self.log("No se pudo convertir la columna a Categorical para mantener el orden.", "DEBUG")

                # Handle collapse-to-single-tick option and group palette
                collapse = getattr(self, 'param_dist_collapse_var', tk.BooleanVar(value=False)).get()
                group_palette_name = getattr(self, 'param_dist_group_palette_var', StringVar(value='deep')).get()
                plot_palette_local = None if not group_palette_name or group_palette_name == 'default' else group_palette_name
                if collapse:
                    # create a temporary single x column so seaborn will use hue to separate groups at same tick
                    plot_df = plot_df.copy()
                    plot_df['__single_x__'] = pd.Categorical(['Todas'] * len(plot_df), categories=['Todas'], ordered=True)
                    x_col = '__single_x__'
                    x_order = ['Todas']

                if x_col and x_col in plot_df.columns:
                    force_override = (x_col_original is None) or (x_col != x_col_original)
                    mark_axis('x', x_col, plot_df, force=force_override)

                # Determine palette argument: prefer explicit mapping if user assigned colors per level
                palette_arg = None
                try:
                    mapping = getattr(self, 'param_dist_group_color_map', None)
                    if mapping and hue_col:
                        # mapping keys are strings; ensure keys exist for levels
                        palette_arg = mapping
                    else:
                        palette_arg = plot_palette_local if plot_palette_local else (palette if 'palette' in locals() else None)
                except Exception:
                    palette_arg = plot_palette_local if plot_palette_local else None

                if isinstance(palette_arg, dict):
                    normalized = {}
                    for key, value in palette_arg.items():
                        color_hex = self._color_to_hex(value)
                        normalized[key] = color_hex
                        normalized[str(key)] = color_hex
                    palette_arg = normalized

                category_color_map_attr = getattr(self, 'param_dist_category_color_map', {})
                category_list = []
                if x_col:
                    if x_order:
                        category_list = [str(cat) for cat in x_order]
                    else:
                        category_list = [str(cat) for cat in pd.unique(plot_df[x_col]) if pd.notna(cat)]
                category_palette = self._build_category_palette(category_list, group_palette_name, category_color_map_attr, point_color)

                size_mapper = self._build_size_mapper(plot_df[size_col], point_size) if size_col and size_col in plot_df.columns else None
                style_mapper = self._build_marker_mapper(plot_df[style_col]) if style_col and style_col in plot_df.columns else None

                custom_method_lookup = {'center': 'center', 'hex': 'hex', 'square': 'square'}
                layout_method_option = (layout_method_raw or 'Auto').strip().lower()
                layout_method_resolved = custom_method_lookup.get(layout_method_option)
                point_type_key = (point_type or '').lower()
                point_layout_method = None
                for key, value in custom_method_lookup.items():
                    if key in point_type_key:
                        point_layout_method = value
                        break
                if not point_layout_method:
                    point_layout_method = layout_method_resolved
                if point_layout_method not in custom_method_lookup.values():
                    point_layout_method = None
                fallback_layout_method = point_layout_method or layout_method_resolved
                if fallback_layout_method not in custom_method_lookup.values():
                    fallback_layout_method = None
                if fallback_layout_method is None and (size_col or style_col):
                    fallback_layout_method = 'hex'
                custom_layout_failure_logged = False

                # Centralize point overlay rendering so layout/jitter rules stay consistent
                def render_points(order, mode='auto', enforce_single_color=False, allow_dodge=True, legend_mode=None):
                    nonlocal custom_layout_failure_logged
                    order_to_use = order if order is not None else x_order
                    jitter_value = max(jitter_effective, 0.0)

                    if fallback_layout_method:
                        custom_palette = {} if enforce_single_color else (category_palette or {})
                        try:
                            self._plot_custom_point_layout(
                                ax=ax,
                                data=plot_df,
                                x_col=x_col,
                                y_col=y_col,
                                order=order_to_use,
                                hue_col=hue_col,
                                palette_arg=palette_arg,
                                category_palette=custom_palette,
                                default_color=custom_point_color,
                                point_size=point_size,
                                method=fallback_layout_method,
                                size_col=size_col,
                                size_mapper=size_mapper,
                                style_col=style_col,
                                style_mapper=style_mapper
                            )
                            return
                        except Exception:
                            if not custom_layout_failure_logged:
                                self.log("No se pudo aplicar el acomodo personalizado; se usa dispersión estándar.", "WARN")
                                custom_layout_failure_logged = True

                    mode_key = (mode or 'auto').lower()
                    if mode_key == 'auto':
                        if 'swarm' in point_type_key:
                            mode_key = 'swarm'
                        elif point_type_key in ('center', 'hex', 'square'):
                            mode_key = 'swarm'
                        else:
                            mode_key = 'strip'

                    palette_for_points = None
                    color_override = None
                    if hue_col and palette_arg is not None and not enforce_single_color:
                        palette_for_points = palette_arg
                    elif not hue_col and not enforce_single_color and category_palette:
                        palette_for_points = {str(k): v for k, v in category_palette.items()}
                    else:
                        color_override = custom_point_color

                    common_kwargs = {
                        'data': plot_df,
                        'x': x_col,
                        'y': y_col,
                        'order': order_to_use,
                        'ax': ax,
                        'size': point_size
                    }
                    if hue_col:
                        common_kwargs['hue'] = hue_col
                        if allow_dodge:
                            common_kwargs['dodge'] = True
                    if palette_for_points is not None:
                        common_kwargs['palette'] = palette_for_points
                    if color_override is not None:
                        common_kwargs['color'] = color_override
                    if legend_mode is not None:
                        common_kwargs['legend'] = legend_mode

                    try:
                        if mode_key == 'swarm':
                            swarm_kwargs = common_kwargs.copy()
                            swarm_kwargs['alpha'] = 0.85
                            sns.swarmplot(**swarm_kwargs)
                        else:
                            strip_kwargs = common_kwargs.copy()
                            strip_kwargs['alpha'] = 0.7
                            strip_kwargs['jitter'] = jitter_value
                            sns.stripplot(**strip_kwargs)
                    except Exception:
                        if mode_key != 'strip':
                            try:
                                strip_kwargs = common_kwargs.copy()
                                strip_kwargs['alpha'] = 0.7
                                strip_kwargs['jitter'] = jitter_value
                                sns.stripplot(**strip_kwargs)
                            except Exception:
                                pass

                # If categorical X is provided, draw grouped violins/boxes/points
                if x_col:
                    custom_point_color = point_color if point_color else 'k'
                    violin_color = point_color if point_color else None
                    connect_points = getattr(self, 'param_dist_connect_points_var', tk.BooleanVar(value=False)).get()
                    violin_palette_kwargs = {}
                    if hue_col:
                        if palette_arg:
                            violin_palette_kwargs['palette'] = palette_arg
                    else:
                        if category_palette:
                            violin_palette_kwargs['palette'] = {str(k): v for k, v in category_palette.items()}
                        elif violin_color:
                            violin_palette_kwargs['color'] = violin_color

                    # Use violinplot or boxplot as base
                    half_violin = getattr(self, 'param_dist_half_violin_var', tk.BooleanVar(value=False)).get()
                    if show_violin:
                        # If half-violin requested and there's no hue, render custom half-violins
                        if half_violin and not hue_col:
                            try:
                                # Use x_order if available, otherwise get unique values
                                if x_order:
                                    cats = x_order
                                else:
                                    cats = list(plot_df[x_col].astype(str).unique())
                                # numeric positions for categories
                                positions = np.arange(len(cats))
                                all_min = float(plot_df[y_col].min())
                                all_max = float(plot_df[y_col].max())
                                if all_min == all_max:
                                    all_min -= 0.5
                                    all_max += 0.5
                                y_grid = np.linspace(all_min, all_max, 300)
                                max_width = max(0.05, violin_width * 0.5)
                                kde_list = []
                                for i, cat in enumerate(cats):
                                    vals = plot_df.loc[plot_df[x_col].astype(str) == cat, y_col].dropna().values
                                    if len(vals) < 2:
                                        kde_list.append(None)
                                        continue
                                    try:
                                        kde = stats.gaussian_kde(vals)
                                        kde_vals = kde(y_grid)
                                    except Exception:
                                        kde_list.append(None)
                                        continue
                                    # normalize so the widest violin has width max_width
                                    kde_list.append(kde_vals)

                                # compute global max for normalization
                                max_kde = 0.0
                                for vals in kde_list:
                                    if vals is not None:
                                        max_kde = max(max_kde, np.max(vals))
                                if max_kde <= 0:
                                    max_kde = 1.0

                                for i, cat in enumerate(cats):
                                    kde_vals = kde_list[i]
                                    x0 = positions[i]
                                    if kde_vals is None:
                                        # draw a small vertical line to indicate presence
                                        subvals = plot_df.loc[plot_df[x_col].astype(str) == cat, y_col].dropna().values
                                        if len(subvals) == 0:
                                            continue
                                        ax.vlines(x0 - 0.05, np.min(subvals), np.max(subvals), color='gray', alpha=violin_alpha, linewidth=4)
                                        continue
                                    kde_norm = (kde_vals / max_kde) * max_width
                                    # draw half-violin to the left of x0
                                    facecolor = category_palette.get(str(cat), violin_color if violin_color else 'C0')
                                    ax.fill_betweenx(y_grid, x0, x0 - kde_norm, facecolor=facecolor, alpha=violin_alpha, linewidth=0)

                                # ticks and limits
                                ax.set_xticks(positions)
                                ax.set_xticklabels(cats)
                                ax.set_xlim(-0.5, len(cats) - 0.5)

                                # If requested, overlay boxplots and points
                                half_boxpoints = getattr(self, 'param_dist_half_violin_boxpoints_var', tk.BooleanVar(value=False)).get()
                                if half_boxpoints:
                                    # prepare data for matplotlib boxplot (list per category)
                                    bp_data = [plot_df.loc[plot_df[x_col].astype(str) == cat, y_col].dropna().values for cat in cats]
                                    try:
                                        box_shift = max_width * 0.95
                                        box_positions = positions + box_shift
                                        bp = ax.boxplot(bp_data, positions=box_positions, widths=box_overlay_width, patch_artist=True, manage_ticks=False, showfliers=False)
                                        box_colors = [category_palette.get(str(cat), '#FFFFFF') for cat in cats]
                                        for patch, color in zip(bp.get('boxes', []), box_colors):
                                            patch.set_facecolor(color)
                                            patch.set_edgecolor('black')
                                            patch.set_alpha(0.85)
                                        for median in bp.get('medians', []):
                                            median.set_color('black')
                                        for whisker in bp.get('whiskers', []):
                                            whisker.set_color('black')
                                        for cap in bp.get('caps', []):
                                            cap.set_color('black')
                                    except Exception:
                                        pass

                                    # overlay points (swarm preferred)
                                    render_points(order=cats, mode='swarm', allow_dodge=False, legend_mode=False)

                            except Exception:
                                sns.violinplot(data=plot_df, x=x_col, y=y_col, hue=hue_col if hue_col else None, order=x_order, ax=ax, cut=0, scale='width', bw=violin_bw, width=violin_width, **violin_palette_kwargs)
                            self._apply_violin_alpha(ax, violin_alpha)
                            if show_box:
                                self._overlay_boxplot(
                                    ax=ax,
                                    data=plot_df,
                                    x_col=x_col,
                                    y_col=y_col,
                                    order=x_order if x_order else None,
                                    hue_col=hue_col,
                                    palette_arg=palette_arg,
                                    width=box_overlay_width,
                                    edge_color=violin_color,
                                    category_palette=category_palette
                                )
                        else:
                            # If raincloud requested, try to render a compact violin + points overlay
                            plot_palette = palette if palette else None
                            if raincloud:
                                # If hue is present and has exactly 2 levels, we can use split=True
                                if hue_col:
                                    try:
                                        unique_hues = plot_df[hue_col].dropna().unique()
                                        if len(unique_hues) == 2:
                                            sns.violinplot(data=plot_df, x=x_col, y=y_col, hue=hue_col, order=x_order, split=True, inner=None, ax=ax, cut=0, scale='width', bw=violin_bw, width=violin_width, **violin_palette_kwargs)
                                        else:
                                            sns.violinplot(data=plot_df, x=x_col, y=y_col, hue=hue_col, order=x_order, inner=None, ax=ax, cut=0, scale='width', bw=violin_bw, width=violin_width, **violin_palette_kwargs)
                                    except Exception:
                                        sns.violinplot(data=plot_df, x=x_col, y=y_col, hue=hue_col if hue_col else None, order=x_order, inner=None, ax=ax, cut=0, scale='width', bw=violin_bw, width=violin_width, **violin_palette_kwargs)
                                else:
                                    sns.violinplot(data=plot_df, x=x_col, y=y_col, order=x_order, inner=None, ax=ax, cut=0, scale='width', bw=violin_bw, width=violin_width, **violin_palette_kwargs)
                                # overlay scattered points to emulate raincloud (dodge only meaningful with hue)
                                    render_points(order=x_order, mode='strip', enforce_single_color=not bool(hue_col), allow_dodge=bool(hue_col), legend_mode=False)
                            else:
                                sns.violinplot(data=plot_df, x=x_col, y=y_col, hue=hue_col if hue_col else None, order=x_order, ax=ax, cut=0, scale='width', bw=violin_bw, width=violin_width, **violin_palette_kwargs)
                            self._apply_violin_alpha(ax, violin_alpha)
                            if show_box:
                                self._overlay_boxplot(
                                    ax=ax,
                                    data=plot_df,
                                    x_col=x_col,
                                    y_col=y_col,
                                    order=x_order if x_order else None,
                                    hue_col=hue_col,
                                    palette_arg=palette_arg,
                                    width=box_overlay_width,
                                    edge_color=violin_color,
                                    category_palette=category_palette
                                )
                            # Custom legend assembly consolidating color/size/style once each
                            try:
                                existing_legend = ax.get_legend()
                                if existing_legend is not None:
                                    existing_legend.remove()
                            except Exception:
                                pass

                            if show_legend:
                                point_color_hex = self._color_to_hex(custom_point_color)
                                combined_handles = []
                                combined_labels = []

                                def add_section(section_title, entries):
                                    if not section_title or not entries:
                                        return
                                    combined_handles.append(Line2D([0], [0], linestyle='None', marker=None, alpha=0))
                                    combined_labels.append(f"{section_title}:")
                                    for entry_handle, entry_label in entries:
                                        combined_handles.append(entry_handle)
                                        combined_labels.append(f"  {entry_label}")

                                # Color legend (hue or category palette)
                                color_entries = []
                                color_title = None
                                if hue_col and hue_col in plot_df.columns:
                                    hue_series = plot_df[hue_col]
                                    hue_dtype = getattr(hue_series, 'dtype', None)
                                    if self._is_categorical(hue_dtype):
                                        hue_levels = [lvl for lvl in hue_series.cat.categories if pd.notna(lvl)]
                                    else:
                                        hue_levels = [lvl for lvl in pd.unique(hue_series.dropna())]
                                    if hue_levels:
                                        color_title = hue_col
                                        palette_colors = {}
                                        if isinstance(palette_arg, dict):
                                            palette_colors = {str(k): self._color_to_hex(v) for k, v in palette_arg.items() if v}
                                        else:
                                            palette_list = None
                                            if isinstance(palette_arg, (list, tuple)):
                                                palette_list = [self._color_to_hex(col) for col in palette_arg]
                                            elif isinstance(palette_arg, str):
                                                try:
                                                    palette_list = [self._color_to_hex(col) for col in sns.color_palette(palette_arg, n_colors=len(hue_levels))]
                                                except Exception:
                                                    palette_list = None
                                            if palette_list is None:
                                                try:
                                                    palette_list = [self._color_to_hex(col) for col in sns.color_palette(n_colors=len(hue_levels))]
                                                except Exception:
                                                    palette_list = None
                                            if palette_list:
                                                palette_colors = {str(hue_levels[idx]): palette_list[idx % len(palette_list)] for idx in range(len(hue_levels))}
                                        for idx, level in enumerate(hue_levels):
                                            key = str(level)
                                            color_hex = palette_colors.get(key) if palette_colors else None
                                            if not color_hex and palette_colors:
                                                color_hex = palette_colors.get(level)
                                            if not color_hex:
                                                color_hex = point_color_hex
                                            handle = Line2D([0], [0], marker='o', linestyle='None', markersize=max(point_size, 6), markerfacecolor=color_hex, markeredgecolor=color_hex)
                                            color_entries.append((handle, str(level)))
                                elif category_palette:
                                    mapped_palette = {str(k): self._color_to_hex(v) for k, v in category_palette.items() if v}
                                    categories_for_legend = x_order if x_order else [str(cat) for cat in mapped_palette.keys()]
                                    categories_for_legend = [str(cat) for cat in categories_for_legend if cat is not None]
                                    if categories_for_legend:
                                        color_title = x_col_original if x_col_original else (x_col if x_col else 'Color')
                                        for cat in categories_for_legend:
                                            color_hex = mapped_palette.get(cat)
                                            if not color_hex:
                                                continue
                                            handle = Line2D([0], [0], marker='o', linestyle='None', markersize=max(point_size, 6), markerfacecolor=color_hex, markeredgecolor=color_hex)
                                            color_entries.append((handle, cat))
                                if color_entries and not color_title:
                                    color_title = 'Color'

                                # Size legend
                                size_entries = []
                                size_title = size_col if size_col else None
                                if size_col and size_mapper and size_col in plot_df.columns:
                                    size_series = plot_df[size_col]
                                    if not size_series.empty:
                                        numeric_values = pd.to_numeric(size_series, errors='coerce').dropna()
                                        legend_candidates = []
                                        if not numeric_values.empty:
                                            quantiles = np.quantile(numeric_values, [0.0, 0.5, 1.0])
                                            quantiles = np.unique(np.round(quantiles, decimals=6))
                                            if quantiles.size == 1:
                                                quantiles = np.unique(np.round(numeric_values.to_numpy(), decimals=6))
                                            quantiles = sorted(float(val) for val in quantiles)
                                            if len(quantiles) > 4:
                                                quantiles = [quantiles[0], float(np.median(quantiles)), quantiles[-1]]
                                            for val in quantiles:
                                                try:
                                                    area = float(size_mapper(pd.Series([val]))[0])
                                                except Exception:
                                                    continue
                                                legend_candidates.append((f"{val:g}", area))
                                        else:
                                            cat_values = [val for val in pd.unique(size_series.dropna())]
                                            limit = min(len(cat_values), 6)
                                            for val in cat_values[:limit]:
                                                try:
                                                    area = float(size_mapper(pd.Series([val]))[0])
                                                except Exception:
                                                    continue
                                                legend_candidates.append((str(val), area))
                                        if legend_candidates:
                                            legend_candidates.sort(key=lambda item: item[1])
                                            area_seen = set()
                                            for label_text, area in legend_candidates:
                                                if area <= 0 or label_text in area_seen:
                                                    continue
                                                area_seen.add(label_text)
                                                markersize = max(np.sqrt(abs(area)), 4.0)
                                                handle = Line2D([0], [0], marker='o', linestyle='None', markersize=markersize, markerfacecolor='none', markeredgecolor='#333333', color='#333333')
                                                size_entries.append((handle, label_text))
                                                if len(size_entries) >= 5:
                                                    break
                                        if not size_title:
                                            size_title = 'Tamaño'

                                # Style legend
                                style_entries = []
                                style_title = style_col if style_col else None
                                if style_col and style_mapper and style_col in plot_df.columns:
                                    style_series = plot_df[style_col].dropna()
                                    if not style_series.empty:
                                        style_levels = [val for val in pd.unique(style_series)]
                                        limit = min(len(style_levels), 8)
                                        marker_size = max(point_size, 8)
                                        for val in style_levels[:limit]:
                                            try:
                                                marker_symbol = style_mapper(pd.Series([val]))[0]
                                            except Exception:
                                                marker_symbol = 'o'
                                            handle = Line2D([0], [0], marker=marker_symbol, linestyle='None', markersize=marker_size, markerfacecolor='none', markeredgecolor=point_color_hex, color=point_color_hex, markeredgewidth=1.4)
                                            style_entries.append((handle, str(val)))
                                        if not style_title:
                                            style_title = 'Forma'

                                add_section(color_title, color_entries)
                                add_section(size_title, size_entries)
                                add_section(style_title, style_entries)

                                if combined_handles:
                                    legend = ax.legend(combined_handles, combined_labels, loc=legend_loc, frameon=True, handlelength=2)
                                    try:
                                        legend._legend_box.align = "left"
                                    except Exception:
                                        pass
                                    try:
                                        for text in legend.get_texts():
                                            text.set_fontsize(legend_size)
                                    except Exception:
                                        pass
                                else:
                                    try:
                                        legend = ax.get_legend()
                                        if legend is not None:
                                            legend.remove()
                                    except Exception:
                                        pass
                            else:
                                try:
                                    legend = ax.get_legend()
                                    if legend is not None:
                                        legend.remove()
                                except Exception:
                                    pass
                    elif show_box:
                        sns.boxplot(data=plot_df, x=x_col, y=y_col, hue=hue_col if hue_col else None, order=x_order, ax=ax)
                    else:
                        # Dot/point summary (use pointplot of means/medians)
                        show_summary = getattr(self, 'param_dist_show_summary_var', tk.BooleanVar(value=False)).get()
                        join_flag = True if connect_points else False
                        if show_summary:
                            try:
                                sns.pointplot(data=plot_df, x=x_col, y=y_col, hue=hue_col if hue_col else None, order=x_order, join=join_flag, ax=ax, ci=95)
                            except Exception:
                                try:
                                    sns.pointplot(data=plot_df, x=x_col, y=y_col, hue=hue_col if hue_col else None, order=x_order, join=join_flag, ax=ax, ci='sd')
                                except Exception:
                                    pass

                    # Overlay points if requested
                    if point_type and point_type != 'Ninguno':
                        point_mode = 'strip'
                        if point_type_key == 'swarm' or point_type in ('Swarm',):
                            point_mode = 'swarm'
                        elif point_type_key in ('center', 'hex', 'square') or point_type in ('Center', 'Hex', 'Square'):
                            point_mode = 'swarm'
                        render_points(order=x_order, mode=point_mode, allow_dodge=bool(hue_col), legend_mode=False)

                else:
                    # Single numeric distribution: histogram + optional KDE, box/violin as inset
                    # Show histogram only if user enabled the checkbox; otherwise show KDE only
                    show_hist = getattr(self, 'param_dist_show_hist_var', tk.BooleanVar(value=False)).get()
                    if show_hist:
                        sns.histplot(plot_df[y_col], kde=True, ax=ax)
                    else:
                        try:
                            sns.kdeplot(plot_df[y_col], ax=ax, fill=False)
                        except Exception:
                            # Fallback: histogram if KDE fails
                            sns.histplot(plot_df[y_col], kde=True, ax=ax)

                    if show_violin or show_box:
                        # Add a small inset axis for box/violin
                        try:
                            from mpl_toolkits.axes_grid1.inset_locator import inset_axes
                            iax = inset_axes(ax, width="30%", height="30%", loc='upper right')
                            if show_violin:
                                sns.violinplot(y=plot_df[y_col], ax=iax, orient='v')
                            else:
                                sns.boxplot(y=plot_df[y_col], ax=iax, orient='v')
                            iax.set_xlabel('')
                            iax.set_ylabel('')
                            iax.set_xticks([])
                        except Exception:
                            # Fallback: draw boxplot on main ax at top
                            sns.boxplot(y=plot_df[y_col], ax=ax, width=0.2)

                    # Overlay points: for single-variable distribution prefer swarm (jitter)
                    try:
                        # Use swarmplot along the x-axis (orient horizontal)
                        single_point_color = point_color if point_color else 'k'
                        sns.swarmplot(x=plot_df[y_col], ax=ax, color=single_point_color, size=point_size)
                    except Exception:
                        # Fallback to stripplot (jitter)
                        single_point_color = point_color if point_color else 'k'
                        sns.stripplot(x=plot_df[y_col], ax=ax, jitter=0.25, color=single_point_color, size=point_size)

            else:
                ax.text(0.5, 0.5, f"Gráfico '{chart_type}' aún no implementado.", ha='center', va='center')

            # --- Apply Specific Customizations to Axes ---
            try:
                title_color = getattr(self, 'param_title_color_var', StringVar(value='black')).get()
            except Exception:
                title_color = 'black'
            try:
                title_size = int(getattr(self, 'param_title_size_var', StringVar(value='12')).get())
            except Exception:
                title_size = None
            if title_size:
                ax.set_title(title if title else chart_type, color=title_color, fontsize=title_size)
            else:
                ax.set_title(title if title else chart_type, color=title_color)
            ax.set_xlabel(xlabel)
            ax.set_ylabel(ylabel)
            if grid:
                ax.grid(True, linestyle='--', alpha=0.7)
            else:
                ax.grid(False)

            # Apply new advanced options
            ax.set_xscale(x_scale)
            ax.set_yscale(y_scale)
            plt.setp(ax.get_xticklabels(), rotation=tick_rotation)

            if xlim_raw:
                parts = [p.strip() for p in xlim_raw.split(',') if p.strip()]
                try:
                    nums = [float(p) for p in parts]
                    if len(nums) == 1:
                        ax.set_xlim(nums[0])
                    elif len(nums) >= 2:
                        ax.set_xlim((nums[0], nums[1]))
                except Exception:
                    self.log("Formato de xlim inválido, se ignora.", "WARN")
            if ylim_raw:
                parts = [p.strip() for p in ylim_raw.split(',') if p.strip()]
                try:
                    nums = [float(p) for p in parts]
                    if len(nums) == 1:
                        ax.set_ylim(nums[0])
                    elif len(nums) >= 2:
                        ax.set_ylim((nums[0], nums[1]))
                except Exception:
                    self.log("Formato de ylim inválido, se ignora.", "WARN")

            # --- Set categorical tick labels for distribution plots (after axis scaling) ---
            if chart_type == "Gráfico de Distribución":
                if 'x_order' in locals() and x_order:
                    try:
                        locator = mticker.FixedLocator(range(len(x_order)))
                        formatter = mticker.FixedFormatter(x_order)
                        ax.xaxis.set_major_locator(locator)
                        ax.xaxis.set_major_formatter(formatter)
                        self.log(f"Locator y formatter personalizados aplicados al eje X con orden: {x_order}", "DEBUG")
                        tick_texts = [tick.get_text() for tick in ax.get_xticklabels()]
                        self.log(f"Ticklabels actuales tras aplicar formatter: {tick_texts}", "DEBUG")
                        self.log(f"Labels del eje X establecidos: {x_order}", "INFO")
                    except Exception as e:
                        self.log(f"Error al establecer labels del eje X: {e}", "WARN")
                        self.log(traceback.format_exc(), "DEBUG")

            # Reapply categorical tick overrides after scale/lim adjustments
            if axis_x_col:
                data_for_x = tick_data_x if tick_data_x is not None else filtered_data
                self._set_categorical_tick_labels(ax, data_for_x, x_col=axis_x_col)
            if axis_y_col:
                data_for_y = tick_data_y if tick_data_y is not None else filtered_data
                self._set_categorical_tick_labels(ax, data_for_y, y_col=axis_y_col)

            plt.tight_layout()
            canvas = FigureCanvasTkAgg(plt_fig, master=self.chart_display_frame)
            canvas.draw()
            toolbar = NavigationToolbar2Tk(canvas, self.chart_display_frame)
            toolbar.update()
            canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)

            self.log(f"'{chart_type}' generado con éxito.", "SUCCESS")
            self.log("Parámetros usados:\n" + "\n".join(params_used_log), "PARAMS")

        except Exception as e:
            self.log(f"Error generando gráfico '{chart_type}': {e}", "ERROR")
            messagebox.showerror("Error de Graficación", f"No se pudo generar el gráfico:\n{e}", parent=self.parent_for_dialogs)

if __name__ == '__main__':
    root = tk.Tk()
    root.title("Prueba Pestaña Gráficas Generales")
    root.geometry("1000x700")
    
    app_tab = GeneralChartsApp(root)
    app_tab.pack(fill="both", expand=True)
    root.mainloop()