#!/usr/bin/env python
# -*- coding: utf-8 -*-

import tkinter as tk
from tkinter import ttk, simpledialog, messagebox, filedialog
import numpy as np
import pandas as pd
import re
import traceback
import os

try:
    from MATLAB_filter_component import FilterComponent
    FILTER_COMPONENT_AVAILABLE = True
except ImportError:
    FilterComponent = None
    FILTER_COMPONENT_AVAILABLE = False

class AddVariablesTab(ttk.Frame):
    def __init__(self, parent_notebook, main_app_instance):
        super().__init__(parent_notebook)
        self.main_app = main_app_instance
        self.data = None
        self.filtered_data = None
        self.file_path = None
        self.filter_component = None
        self.filter_status_var = tk.StringVar(value="Sin datos cargados.")

        # Main frame
        main_frame = ttk.Frame(self, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)

        # Button to load data
        btn_load_data = ttk.Button(main_frame, text="Cargar Archivo (Excel/CSV)", command=self.load_data)
        btn_load_data.pack(pady=10, padx=10, fill=tk.X)

        self.dataset_info_var = tk.StringVar(value="Archivo actual: Sin archivo cargado.")
        self.dataset_info_label = ttk.Label(main_frame, textvariable=self.dataset_info_var, anchor="w", justify=tk.LEFT)
        self.dataset_info_label.pack(fill=tk.X, padx=10, pady=(0, 8))

        # Button to create variable
        btn_create_var = ttk.Button(main_frame, text="Crear Nueva Variable por Fórmula", command=self.create_variable_by_formula)
        btn_create_var.pack(pady=10, padx=10, fill=tk.X)

        # Shared filters section
        filters_frame = ttk.LabelFrame(main_frame, text="Filtros Compartidos para Todas las Pestañas")
        filters_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        if FILTER_COMPONENT_AVAILABLE and FilterComponent is not None:
            self.filter_component = FilterComponent(filters_frame, log_callback=self._log)
            self.filter_component.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

            filter_buttons_frame = ttk.Frame(filters_frame)
            filter_buttons_frame.pack(fill=tk.X, padx=5, pady=5)

            self.btn_apply_filters = ttk.Button(filter_buttons_frame, text="Aplicar Filtros", command=self.apply_filters_to_dataset, state=tk.DISABLED)
            self.btn_apply_filters.pack(side=tk.LEFT, padx=2)

            self.btn_clear_filters = ttk.Button(filter_buttons_frame, text="Limpiar Filtros", command=self.clear_filters, state=tk.DISABLED)
            self.btn_clear_filters.pack(side=tk.LEFT, padx=2)
        else:
            ttk.Label(filters_frame, text="El componente de filtros no está disponible.").pack(padx=10, pady=10, anchor="w")
            self.btn_apply_filters = None
            self.btn_clear_filters = None

        self.filter_status_label = ttk.Label(filters_frame, textvariable=self.filter_status_var, wraplength=500, justify=tk.LEFT)
        self.filter_status_label.pack(fill=tk.X, padx=5, pady=(0, 5))

        self._update_filter_buttons_state()
        self._propagate_shared_dataset(None, [])
        self._update_dataset_info_display()

        # Frame for renaming variables
        frame_rename = ttk.LabelFrame(main_frame, text="Renombrar Variable")
        frame_rename.pack(fill=tk.X, padx=10, pady=10, ipady=5)

        ttk.Label(frame_rename, text="Variable a Renombrar:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.combo_rename_var = ttk.Combobox(frame_rename, state="readonly")
        self.combo_rename_var.grid(row=0, column=1, padx=5, pady=5, sticky="ew")

        ttk.Label(frame_rename, text="Nuevo Nombre:").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.entry_new_name = ttk.Entry(frame_rename)
        self.entry_new_name.grid(row=1, column=1, padx=5, pady=5, sticky="ew")

        btn_rename = ttk.Button(frame_rename, text="Renombrar", command=self.rename_variable)
        btn_rename.grid(row=2, column=1, padx=5, pady=10, sticky="e")

        frame_rename.columnconfigure(1, weight=1)

        # Frame for recoding variables
        frame_recode = ttk.LabelFrame(main_frame, text="Recodificar Variable")
        frame_recode.pack(fill=tk.X, padx=10, pady=10, ipady=5)

        ttk.Label(frame_recode, text="Variable a Recodificar:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.combo_recode_var = ttk.Combobox(frame_recode, state="readonly")
        self.combo_recode_var.grid(row=0, column=1, padx=5, pady=5, sticky="ew")

        ttk.Label(frame_recode, text="Mapeo de Valores (ej: F:1, M:0):").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.entry_recode_map = ttk.Entry(frame_recode)
        self.entry_recode_map.grid(row=1, column=1, padx=5, pady=5, sticky="ew")

        btn_recode = ttk.Button(frame_recode, text="Recodificar", command=self.recode_variable)
        btn_recode.grid(row=2, column=1, padx=5, pady=10, sticky="e")

        frame_recode.columnconfigure(1, weight=1)

        # Frame for saving data
        frame_save = ttk.LabelFrame(main_frame, text="Guardar Datos Modificados")
        frame_save.pack(fill=tk.X, padx=10, pady=10, ipady=5)

        btn_save_as = ttk.Button(frame_save, text="Guardar como...", command=self.save_data_as)
        btn_save_as.pack(side=tk.LEFT, padx=10, pady=10)

        btn_overwrite = ttk.Button(frame_save, text="Sustituir base actual", command=self.overwrite_data)
        btn_overwrite.pack(side=tk.LEFT, padx=10, pady=10)

    def load_data(self):
        filepath = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx *.xls"), ("CSV files", "*.csv")])
        if not filepath:
            return
        try:
            if filepath.lower().endswith('.csv'):
                self.data = pd.read_csv(filepath)
            else:
                self.data = pd.read_excel(filepath)
            self.file_path = filepath
            self.filtered_data = None
            self._after_dataset_changed(reapply_filters=False)
            messagebox.showinfo("Éxito", "Datos cargados correctamente.", parent=self)
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo cargar el archivo: {e}", parent=self)
            self.data = None
            self.file_path = None
            self.filtered_data = None
            self._after_dataset_changed(reapply_filters=False)

    def recode_variable(self):
        if self.data is None:
            messagebox.showerror("Error", "No hay datos cargados.", parent=self)
            return

        var_to_recode = self.combo_recode_var.get()
        recode_map_str = self.entry_recode_map.get().strip()

        if not var_to_recode:
            messagebox.showerror("Error", "Seleccione una variable para recodificar.", parent=self)
            return

        if not recode_map_str:
            messagebox.showerror("Error", "Ingrese el mapeo de valores.", parent=self)
            return

        try:
            # Parse the mapping string: "key1:val1,key2:val2"
            recode_map = {}
            for pair in recode_map_str.split(','):
                if ':' not in pair:
                    continue
                key, value = pair.split(':', 1)
                key = key.strip()
                value = value.strip()
                # Try to convert key and value to numeric if possible
                try:
                    key = pd.to_numeric(key)
                except ValueError:
                    pass
                try:
                    value = pd.to_numeric(value)
                except ValueError:
                    pass
                recode_map[key] = value

            if not recode_map:
                messagebox.showerror("Error", "El formato del mapeo es incorrecto. Use: clave1:valor1,clave2:valor2", parent=self)
                return

            # Apply the recoding
            self.data[var_to_recode] = self.data[var_to_recode].replace(recode_map)
            
            # Update variable selectors and broadcast change
            self._after_dataset_changed(reapply_filters=True)
            self.entry_recode_map.delete(0, tk.END)

        except Exception as e:
            messagebox.showerror("Error", f"Ocurrió un error al recodificar la variable:\n{e}", parent=self)

    def rename_variable(self):
        if self.data is None:
            messagebox.showerror("Error", "No hay datos cargados.", parent=self)
            return

        old_name = self.combo_rename_var.get()
        new_name = self.entry_new_name.get().strip()

        if not old_name:
            messagebox.showerror("Error", "Seleccione una variable para renombrar.", parent=self)
            return

        if not new_name:
            messagebox.showerror("Error", "Ingrese un nuevo nombre para la variable.", parent=self)
            return

        if not re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", new_name):
            messagebox.showerror("Nombre Inválido", "El nuevo nombre de la variable debe ser un identificador Python válido.", parent=self)
            return

        if new_name in self.data.columns:
            messagebox.showerror("Error", f"La variable '{new_name}' ya existe.", parent=self)
            return

        try:
            self.data.rename(columns={old_name: new_name}, inplace=True)
            messagebox.showinfo("Éxito", f"La variable '{old_name}' ha sido renombrada a '{new_name}'.", parent=self)

            # Update variable selectors and broadcast change
            self._after_dataset_changed(reapply_filters=True)
            self.entry_new_name.delete(0, tk.END)

        except Exception as e:
            messagebox.showerror("Error", f"Ocurrió un error al renombrar la variable:\n{e}", parent=self)

    def update_variable_lists(self):
        if self.data is not None:
            cols = sorted(self.data.columns.tolist())
            self.combo_rename_var['values'] = cols
            self.combo_recode_var['values'] = cols
            if cols:
                self.combo_rename_var.set(cols[0])
                self.combo_recode_var.set(cols[0])
            else:
                self.combo_rename_var.set('')
                self.combo_recode_var.set('')
        else:
            self.combo_rename_var['values'] = []
            self.combo_rename_var.set('')
            self.combo_recode_var['values'] = []
            self.combo_recode_var.set('')

        self._update_filter_buttons_state()

    def save_data_as(self):
        if self.data is None:
            messagebox.showerror("Error", "No hay datos para guardar.", parent=self)
            return

        file_path = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            filetypes=[("Excel files", "*.xlsx"), ("CSV files", "*.csv"), ("All files", "*.*")]
        )

        if not file_path:
            return

        try:
            if file_path.lower().endswith('.csv'):
                self.data.to_csv(file_path, index=False)
            else:
                self.data.to_excel(file_path, index=False)
            messagebox.showinfo("Éxito", f"Datos guardados en {file_path}", parent=self)
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar el archivo:\n{e}", parent=self)

    def overwrite_data(self):
        if self.data is None:
            messagebox.showerror("Error", "No hay datos para guardar.", parent=self)
            return
            
        original_path = self.file_path
        if not original_path:
            messagebox.showerror("Error", "No se conoce la ruta del archivo original. Use 'Guardar como...'", parent=self)
            return

        if not messagebox.askyesno("Confirmar", f"¿Está seguro de que desea sobrescribir el archivo original?\n{original_path}"):
            return

        try:
            if original_path.lower().endswith('.csv'):
                self.data.to_csv(original_path, index=False)
            else:
                self.data.to_excel(original_path, index=False)
            messagebox.showinfo("Éxito", "El archivo original ha sido sobrescrito.", parent=self)
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo sobrescribir el archivo:\n{e}", parent=self)

    def apply_filters_to_dataset(self):
        if not self.filter_component:
            return
        if self.data is None:
            messagebox.showwarning("Sin Datos", "Cargue datos antes de aplicar filtros.", parent=self)
            return

        filtered_df = self.filter_component.apply_filters()
        if filtered_df is None:
            return

        summary = self.filter_component.get_last_filters_summary()
        if summary:
            self.filtered_data = filtered_df
        else:
            self.filtered_data = None

        self._update_filter_status(summary)
        self._propagate_shared_dataset(self.filtered_data if self.filtered_data is not None else None, summary)
        self._update_filter_buttons_state()

    def clear_filters(self):
        if not self.filter_component:
            return
        self.filter_component.clear_all_filters()
        self.filtered_data = None
        self._update_filter_status([])
        self._propagate_shared_dataset(None, [])
        self._update_filter_buttons_state()

    def _after_dataset_changed(self, reapply_filters=False):
        self.update_variable_lists()

        if self.filter_component:
            df_for_filters = self.data if isinstance(self.data, pd.DataFrame) else pd.DataFrame()
            self.filter_component.set_dataframe(df_for_filters)

        summary = []
        filtered_df = None

        if self.data is None:
            self.filtered_data = None
        elif reapply_filters and self.filter_component and self.filter_component.filter_conditions:
            filtered_result = self.filter_component.apply_filters()
            if filtered_result is not None:
                summary = self.filter_component.get_last_filters_summary()
                if summary:
                    self.filtered_data = filtered_result
                    filtered_df = filtered_result
                else:
                    self.filtered_data = None
            else:
                self.filtered_data = None
        else:
            if self.filter_component:
                summary = self.filter_component.get_last_filters_summary()
                if summary and self.filtered_data is not None:
                    filtered_df = self.filtered_data
                else:
                    summary = []
                    self.filtered_data = None

        self._update_filter_status(summary)
        self._update_filter_buttons_state()
        self._propagate_shared_dataset(filtered_df, summary)

    def _update_filter_buttons_state(self):
        enable = tk.NORMAL if self.data is not None and self.filter_component else tk.DISABLED
        if self.btn_apply_filters:
            self.btn_apply_filters.config(state=enable)

        if self.btn_clear_filters:
            has_filters_defined = False
            if self.filter_component:
                has_filters_defined = bool(self.filter_component.filter_conditions) or bool(self.filter_component.get_last_filters_summary())
            clear_state = tk.NORMAL if enable == tk.NORMAL and has_filters_defined else tk.DISABLED
            self.btn_clear_filters.config(state=clear_state)

    def _update_filter_status(self, summary):
        if self.data is None:
            self.filter_status_var.set("Sin datos cargados.")
            return

        total_rows = len(self.data)
        if summary and self.filtered_data is not None:
            filtered_rows = len(self.filtered_data)
            details = '; '.join(summary)
            self.filter_status_var.set(
                f"Filtros activos ({len(summary)}). Registros: {filtered_rows}/{total_rows}. Detalle: {details}"
            )
        else:
            self.filter_status_var.set(f"Sin filtros aplicados. Registros disponibles: {total_rows}.")

    def _log(self, message, level="INFO"):
        print(f"[AddVariables::{level}] {message}")

    def get_filter_summary(self):
        if self.filter_component:
            return self.filter_component.get_last_filters_summary()
        return []

    def get_current_dataset(self):
        return self.filtered_data if self.filtered_data is not None else self.data
    def create_variable_by_formula(self):
        if self.data is None:
            messagebox.showerror("Error", "No hay datos cargados para crear una variable.", parent=self)
            return

        new_var_name = simpledialog.askstring(
            "Crear Nueva Variable",
            "Ingrese el nombre para la nueva variable:",
            parent=self)

        if not new_var_name or not new_var_name.strip():
            return
        new_var_name = new_var_name.strip()
        
        if not re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", new_var_name):
            messagebox.showerror("Nombre Inválido", "El nombre de la variable debe ser un identificador Python válido.", parent=self)
            return

        if new_var_name in self.data.columns:
            messagebox.showerror("Error", f"La variable '{new_var_name}' ya existe.", parent=self)
            return

        available_cols_example = ", ".join(self.data.columns[:min(5, len(self.data.columns))])
        if len(self.data.columns) > 5:
            available_cols_example += "..."

        formula_str = simpledialog.askstring(
            "Ingresar Fórmula",
            f"Columnas disponibles (ejemplo): {available_cols_example}\n"
            "Use nombres de columna directamente. Si tienen espacios o caracteres especiales, "
            "use Q('nombre de columna con espacios') o renombre la columna previamente.\n"
            "Funciones NumPy (np.), math (math.), Pandas (pd.) están disponibles.\n"
            "Ejemplo: `col1 * 2 + np.log(Q(\'otra columna\'))`",
            parent=self)

        if not formula_str:
            return

        try:
            env = {'np': np, 'math': __import__('math'), 'pd': pd}
            temp_df_for_eval = self.data.copy()
            
            result_series = temp_df_for_eval.eval(formula_str, engine='python', local_dict=env)
            
            if not isinstance(result_series, pd.Series):
                raise ValueError(f"La fórmula no resultó en una Serie de Pandas (obtenido: {type(result_series)}).")
            if len(result_series) != len(self.data):
                 raise ValueError(f"La serie resultante ({len(result_series)} elementos) no coincide en longitud con el DataFrame ({len(self.data)} elementos).")

            self.data[new_var_name] = result_series.values

            messagebox.showinfo("Variable Creada", f"La variable '{new_var_name}' ha sido creada y añadida al dataset.", parent=self)

            # Update variable selectors and broadcast change
            self._after_dataset_changed(reapply_filters=True)

        except Exception as e:
            err_details = traceback.format_exc()
            messagebox.showerror(
                "Error de Fórmula",
                f"Error al evaluar la fórmula para '{new_var_name}':\n{e}\n\n"
                "Asegúrese que los nombres de columna con espacios o caracteres especiales estén entre acentos graves (backticks), ej: `nombre con espacio`.\n"
                f"Detalles del error:\n{err_details[:600]}...",
                parent=self)

    def _propagate_shared_dataset(self, filtered_df=None, summary=None):
        """Informa al contenedor sobre cambios en el dataset compartido y sus filtros."""
        if not self.main_app or not hasattr(self.main_app, 'update_shared_dataset'):
            return

        metadata = {}
        if self.file_path:
            metadata['source_path'] = self.file_path
        if isinstance(self.data, pd.DataFrame):
            metadata['row_count'] = len(self.data)
            metadata['column_count'] = len(self.data.columns)

        if summary is None:
            summary = self.get_filter_summary()

        self._update_dataset_info_display(summary=summary, metadata=metadata)

        self.main_app.update_shared_dataset(
            self.data,
            filtered_dataset=filtered_df,
            filter_summary=summary,
            source_widget=self,
            metadata=metadata
        )

    def _update_dataset_info_display(self, summary=None, metadata=None):
        if not hasattr(self, "dataset_info_var"):
            return

        if summary is None:
            summary = self.get_filter_summary()

        if self.data is None or not isinstance(self.data, pd.DataFrame):
            self.dataset_info_var.set("Archivo actual: Sin archivo cargado.")
            return

        source_path = self.file_path
        if not source_path and metadata:
            source_path = metadata.get('source_path')

        base_name = os.path.basename(source_path) if source_path else "Datos en memoria"
        total_rows = len(self.data)

        if self.filtered_data is not None and isinstance(self.filtered_data, pd.DataFrame):
            visible_rows = len(self.filtered_data)
            info = f"Archivo actual: {base_name} • Filas visibles: {visible_rows}/{total_rows}"
        else:
            info = f"Archivo actual: {base_name} • Filas disponibles: {total_rows}"

        if summary:
            info += f" • Filtros activos: {len(summary)}"

        self.dataset_info_var.set(info)
