import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog, StringVar, BooleanVar, DoubleVar, IntVar, Listbox, MULTIPLE, SINGLE, BROWSE, Toplevel, Frame, Label, Entry, Button, Checkbutton, Radiobutton
from tkinter import scrolledtext
import pandas as pd
import numpy as np
from lifelines import WeibullAFTFitter, LogNormalAFTFitter, LogLogisticAFTFitter
from lifelines.utils import datetimes_to_durations
import os
import json
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

from MATLAB_filter_component import FilterComponent

class ScrolledFrame(ttk.Frame):
    def __init__(self, parent, *args, **kw):
        super().__init__(parent, *args, **kw)
        self.canvas = tk.Canvas(self, highlightthickness=0, bd=0)
        self.interior = ttk.Frame(self.canvas)
        self.v_scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.h_scrollbar = ttk.Scrollbar(self, orient="horizontal", command=self.canvas.xview)
        self.canvas.configure(yscrollcommand=self.v_scrollbar.set, xscrollcommand=self.h_scrollbar.set)
        self.v_scrollbar.pack(side="right", fill="y")
        self.h_scrollbar.pack(side="bottom", fill="x")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.interior_id = self.canvas.create_window(0, 0, window=self.interior, anchor="nw")
        self.interior.bind('<Configure>', self._on_interior_configure)
        self.canvas.bind('<Enter>', self._bind_mousewheel_events)
        self.canvas.bind('<Leave>', self._unbind_mousewheel_events)

    def _on_interior_configure(self, event):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _bind_mousewheel_events(self, event):
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)
        self.canvas.bind_all("<Button-4>", self._on_mousewheel)
        self.canvas.bind_all("<Button-5>", self._on_mousewheel)

    def _unbind_mousewheel_events(self, event):
        self.canvas.unbind_all("<MouseWheel>")
        self.canvas.unbind_all("<Button-4>")
        self.canvas.unbind_all("<Button-5>")

    def _on_mousewheel(self, event):
        if self.canvas.winfo_containing(event.x_root, event.y_root) == self.canvas:
            if event.num == 4:
                self.canvas.yview_scroll(-1, "units")
            elif event.num == 5:
                self.canvas.yview_scroll(1, "units")
            else:
                self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

class AFTsTab(ttk.Frame):
    def __init__(self, notebook, main_app_instance):
        super().__init__(notebook)
        self.main_app_instance = main_app_instance
        self.data = None
        self.base_data = None
        self.results = None
        self.fitter = None
        self.variable_configs = {}
        self.shared_metadata = {}
        self.current_shared_filter_summary = []
        self.using_shared_dataset = True

        # --- UI ---
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # --- Preprocessing Tab ---
        self.preproc_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.preproc_tab, text="1. Preprocesamiento")

        # --- Modeling Tab ---
        self.modeling_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.modeling_tab, text="2. Modelado AFT")

        # --- Results Tab ---
        self.results_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.results_tab, text="3. Resultados")

        # --- Graphs Tab ---
        self.graphs_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.graphs_tab, text="4. Gráficas")

        self._create_preproc_widgets()
        self._create_modeling_widgets()
        self._create_results_widgets()
        self._create_graphs_widgets()

    def _create_preproc_widgets(self):
        # --- File Loading ---
        load_frame = ttk.LabelFrame(self.preproc_tab, text="Cargar Datos")
        load_frame.pack(fill=tk.X, padx=10, pady=10)

        ttk.Button(load_frame, text="Cargar Archivo (Excel/CSV)", command=self.load_data).pack(side=tk.LEFT, padx=5, pady=5)
        self.file_label = ttk.Label(load_frame, text="Ningún archivo cargado.")
        self.file_label.pack(side=tk.LEFT, padx=5, pady=5)

        # --- Filtering ---
        filter_frame = ttk.LabelFrame(self.preproc_tab, text="Filtros")
        filter_frame.pack(fill=tk.X, padx=10, pady=10)
        self.filter_component = FilterComponent(filter_frame)
        self.filter_component.pack(fill=tk.X, expand=True)

    def _create_modeling_widgets(self):
        # --- Model Selection ---
        model_frame = ttk.LabelFrame(self.modeling_tab, text="Configuración del Modelo AFT")
        model_frame.pack(fill=tk.X, padx=10, pady=10)

        ttk.Label(model_frame, text="Modelo AFT:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.model_var = StringVar(value="Weibull")
        model_combo = ttk.Combobox(model_frame, textvariable=self.model_var, values=["Weibull", "Log-Normal", "Log-Logistic"], state="readonly")
        model_combo.grid(row=0, column=1, padx=5, pady=5, sticky="ew")

        # --- Variable Selection ---
        vars_frame = ttk.LabelFrame(self.modeling_tab, text="Selección de Variables")
        vars_frame.pack(fill=tk.X, padx=10, pady=10)

        ttk.Label(vars_frame, text="Variable de Duración:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.duration_var = StringVar()
        self.duration_combo = ttk.Combobox(vars_frame, textvariable=self.duration_var, state="readonly")
        self.duration_combo.grid(row=0, column=1, padx=5, pady=5, sticky="ew")

        ttk.Label(vars_frame, text="Variable de Evento (Opcional):").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.event_var = StringVar()
        self.event_combo = ttk.Combobox(vars_frame, textvariable=self.event_var, state="readonly")
        self.event_combo.grid(row=1, column=1, padx=5, pady=5, sticky="ew")

        ttk.Label(vars_frame, text="Covariables:").grid(row=2, column=0, padx=5, pady=5, sticky="w")
        self.covariates_listbox = tk.Listbox(vars_frame, selectmode=tk.MULTIPLE, height=6)
        self.covariates_listbox.grid(row=2, column=1, padx=5, pady=5, sticky="ew")
        
        ttk.Button(vars_frame, text="Configurar Covariables...", command=self.open_variable_config_dialog).grid(row=3, column=1, padx=5, pady=10, sticky="e")

        ttk.Button(self.modeling_tab, text="Ejecutar Modelo", command=self.run_model).pack(pady=10)

    def open_variable_config_dialog(self):
        selected_indices = self.covariates_listbox.curselection()
        if not selected_indices:
            messagebox.showwarning("Sin Selección", "Seleccione una o más covariables para configurar.")
            return
        
        selected_vars = [self.covariates_listbox.get(i) for i in selected_indices]
        VariableConfigDialog(self, self, selected_vars)

    def _create_results_widgets(self):
        self.results_text = tk.Text(self.results_tab, wrap=tk.WORD, height=20)
        self.results_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

    def _create_graphs_widgets(self):
        self.graphs_notebook = ttk.Notebook(self.graphs_tab)
        self.graphs_notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        self.km_plot_tab = ttk.Frame(self.graphs_notebook)
        self.graphs_notebook.add(self.km_plot_tab, text="Curva de Supervivencia")

        self.forest_plot_tab = ttk.Frame(self.graphs_notebook)
        self.graphs_notebook.add(self.forest_plot_tab, text="Forest Plot")

        self.km_fig = plt.figure(figsize=(6, 4))
        self.km_canvas = FigureCanvasTkAgg(self.km_fig, master=self.km_plot_tab)
        self.km_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        self.forest_fig = plt.figure(figsize=(6, 4))
        self.forest_canvas = FigureCanvasTkAgg(self.forest_fig, master=self.forest_plot_tab)
        self.forest_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    def load_data(self):
        filepath = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx *.xls"), ("CSV files", "*.csv")])
        if not filepath:
            return
        try:
            if filepath.endswith('.csv'):
                self.data = pd.read_csv(filepath)
            else:
                self.data = pd.read_excel(filepath)
            
            self.base_data = self.data.copy(deep=True)
            self.file_label.config(text=os.path.basename(filepath))
            if self.filter_component:
                self.filter_component.set_dataframe(self.data)
            self._update_variable_comboboxes()
            self._reset_results_view()
            self.using_shared_dataset = False
            self.shared_metadata = {}
            self.current_shared_filter_summary = []
            messagebox.showinfo("Éxito", "Datos cargados correctamente.")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo cargar el archivo: {e}")
            self.data = None
            self.base_data = None

    def _update_variable_comboboxes(self):
        if self.data is not None:
            columns = self.data.columns.tolist()
            self.duration_combo['values'] = columns
            self.event_combo['values'] = [""] + columns
            self.covariates_listbox.delete(0, tk.END)
            for col in columns:
                self.covariates_listbox.insert(tk.END, col)

    def run_model(self):
        if self.data is None:
            messagebox.showerror("Error", "Cargue los datos primero.")
            return

        filtered_data = self.filter_component.apply_filters()
        if filtered_data is None:
            messagebox.showerror("Error", "No se pudieron aplicar los filtros al dataset actual.")
            return

        duration_col = self.duration_var.get()
        event_col = self.event_var.get() or None

        selected_indices = self.covariates_listbox.curselection()
        covariates = [self.covariates_listbox.get(i) for i in selected_indices]

        if not duration_col or not covariates:
            messagebox.showerror("Error", "Debe seleccionar la duración y al menos una covariable.")
            return

        def quote_identifier(column_name):
            return f"Q({json.dumps(str(column_name))})"

        formula_parts = []
        for cov in covariates:
            config = self.variable_configs.get(cov, {})
            if config.get('spline', False):
                df_value = max(1, int(config.get('spline_df', 4)))
                formula_parts.append(f"bs({quote_identifier(cov)}, df={df_value})")
            elif config.get('type') == 'Cualitativa':
                ref_cat = config.get('ref_cat')
                if ref_cat:
                    formula_parts.append(
                        f"C({quote_identifier(cov)}, Treatment(reference={json.dumps(str(ref_cat))}))"
                    )
                else:
                    formula_parts.append(f"C({quote_identifier(cov)})")
            else:
                formula_parts.append(quote_identifier(cov))

        formula = " + ".join(formula_parts)

        model_type = self.model_var.get()
        if model_type == "Weibull":
            self.fitter = WeibullAFTFitter()
        elif model_type == "Log-Normal":
            self.fitter = LogNormalAFTFitter()
        elif model_type == "Log-Logistic":
            self.fitter = LogLogisticAFTFitter()

        try:
            ancillary = filtered_data.copy()
            duration_series = pd.to_numeric(ancillary[duration_col], errors="coerce")
            if duration_series.isna().any():
                messagebox.showerror(
                    "Duración inválida",
                    f"La columna '{duration_col}' contiene valores no numéricos o vacíos tras la conversión.",
                )
                return

            adjustment_note = None
            min_duration = duration_series.min()
            if pd.notna(min_duration) and min_duration <= 0:
                epsilon = 1e-6
                shift_amount = abs(min_duration) + epsilon
                duration_series = duration_series + shift_amount
                adjustment_note = (
                    f"Se detectaron duraciones ≤ 0 en '{duration_col}'. "
                    f"Se agregó un desplazamiento de {shift_amount:.6g} para hacerlas positivas."
                )

            ancillary[duration_col] = duration_series

            warnings = []

            if event_col:
                event_series = pd.to_numeric(ancillary[event_col], errors="coerce")
                invalid_events = event_series.isna()
                if invalid_events.any():
                    dropped = int(invalid_events.sum())
                    ancillary = ancillary.loc[~invalid_events].copy()
                    event_series = event_series.loc[~invalid_events]
                    warnings.append(
                        f"Se descartaron {dropped} filas por eventos no numéricos o vacíos en '{event_col}'."
                    )
                ancillary[event_col] = event_series

            required_cols = [duration_col] + covariates
            if event_col:
                required_cols.append(event_col)

            missing_mask = ancillary[required_cols].isna().any(axis=1)
            if missing_mask.any():
                dropped = int(missing_mask.sum())
                ancillary = ancillary.loc[~missing_mask].copy()
                warnings.append(
                    f"Se descartaron {dropped} filas por valores faltantes en variables del modelo."
                )

            if ancillary.empty:
                messagebox.showerror(
                    "Datos insuficientes",
                    "No hay filas válidas después de limpiar duraciones, eventos y covariables."
                )
                return

            non_positive_mask = ancillary[duration_col] <= 0
            if non_positive_mask.any():
                raise ValueError(
                    "This model does not allow for non-positive durations. "
                    "Revise los datos de duración."
                )

            self.fitter.fit(
                ancillary,
                duration_col=duration_col,
                event_col=event_col,
                formula=formula,
            )
            self.results = self.fitter.summary

            self.results_text.delete("1.0", tk.END)
            if adjustment_note:
                self.results_text.insert(tk.END, adjustment_note + "\n\n")
            for warn in warnings:
                self.results_text.insert(tk.END, warn + "\n")
            if warnings:
                self.results_text.insert(tk.END, "\n")
            self.results_text.insert(tk.END, self.results.to_string())

            self.plot_survival_curve(ancillary)
            self.plot_forest()

            if adjustment_note:
                messagebox.showwarning("Duraciones ajustadas", adjustment_note)
            for warn in warnings:
                messagebox.showwarning("Filas descartadas", warn)

            self.notebook.select(self.results_tab)
        except Exception as e:
            messagebox.showerror("Error en el Modelo", f"Ocurrió un error al ajustar el modelo: {e}")
            self._reset_results_view()

    def plot_survival_curve(self, data):
        self.km_fig.clear()
        ax = self.km_fig.add_subplot(111)
        
        if self.results is not None:
            try:
                params_index = self.fitter.params_.index
                if isinstance(params_index, pd.MultiIndex):
                    candidate_covs = [c for c in params_index.get_level_values(-1) if c != "Intercept"]
                    covariate = candidate_covs[0] if candidate_covs else params_index.get_level_values(-1)[0]
                else:
                    covariate = params_index[0]

                if covariate not in data.columns:
                    raise KeyError

                values = pd.Series(data[covariate].dropna().unique())
                if values.empty:
                    raise ValueError
                values = values.sort_values()
                if len(values) > 5:
                    values = values.iloc[[0, len(values)//2, -1]]

                self.fitter.plot_partial_effects_on_outcome(covariate, values.tolist(), ax=ax)
                ax.set_title(f"Curva de Supervivencia Parcial ({covariate})")
            except Exception:
                ax.text(0.5, 0.5, "No se pudo generar la curva de supervivencia.", ha="center", va="center")
        
        self.km_canvas.draw()

    def plot_forest(self):
        self.forest_fig.clear()
        ax = self.forest_fig.add_subplot(111)
        
        if self.results is not None:
            self.fitter.plot(ax=ax)
            ax.set_title("Forest Plot de Coeficientes")
        
        self.forest_canvas.draw()

    def _reset_results_view(self):
        self.results = None
        self.fitter = None
        if hasattr(self, 'results_text'):
            self.results_text.delete("1.0", tk.END)
        if hasattr(self, 'km_fig'):
            self.km_fig.clear()
            self.km_canvas.draw()
        if hasattr(self, 'forest_fig'):
            self.forest_fig.clear()
            self.forest_canvas.draw()

    def _describe_shared_source(self, metadata):
        if metadata and metadata.get('source_path'):
            try:
                return os.path.basename(metadata['source_path'])
            except Exception:
                return metadata.get('source_path') or "Archivo compartido"
        return "Archivo compartido"

    def receive_shared_dataset(self, *, dataset, filtered_dataset=None, filter_summary=None, metadata=None, source_widget=None):
        if not self.using_shared_dataset:
            return

        if source_widget is self:
            return

        self.shared_metadata = dict(metadata or {})
        self.current_shared_filter_summary = list(filter_summary or [])

        if dataset is None:
            self.base_data = None
            self.data = None
            self._reset_results_view()
            if self.filter_component:
                try:
                    self.filter_component.set_dataframe(pd.DataFrame())
                except Exception:
                    pass
            self._update_variable_comboboxes()
            self.file_label.config(text="Sin archivo compartido.")
            return

        try:
            base_df = dataset.copy(deep=True)
        except Exception:
            base_df = dataset

        if isinstance(filtered_dataset, pd.DataFrame):
            try:
                active_df = filtered_dataset.copy(deep=True)
            except Exception:
                active_df = filtered_dataset
        else:
            try:
                active_df = base_df.copy(deep=True)
            except Exception:
                active_df = base_df

        self.base_data = base_df
        self.data = active_df

        if self.filter_component:
            try:
                self.filter_component.set_dataframe(self.data)
            except Exception:
                pass

        self._update_variable_comboboxes()
        self._reset_results_view()

        try:
            rows, cols = self.data.shape
            filter_suffix = f" | Filtros: {len(self.current_shared_filter_summary)}" if self.current_shared_filter_summary else ""
            source_name = self._describe_shared_source(self.shared_metadata)
            self.file_label.config(text=f"Compartido: {source_name} ({rows} filas, {cols} cols){filter_suffix}")
        except Exception:
            self.file_label.config(text="Dataset compartido disponible")

class VariableConfigDialog(Toplevel):
    def __init__(self, parent, app_instance, selected_vars):
        super().__init__(parent)
        self.transient(parent)
        self.grab_set()
        self.title("Configuración Detallada de Variables")
        self.app_instance = app_instance
        self.selected_vars = selected_vars
        self.row_configs = {}

        main_frame = ttk.Frame(self, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)

        scrolled_frame = ScrolledFrame(main_frame)
        scrolled_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        self.controls_frame = scrolled_frame.interior

        for var_name in self.selected_vars:
            self.row_configs[var_name] = {}
            
            row_labelframe = ttk.LabelFrame(self.controls_frame, text=var_name, padding="10")
            row_labelframe.pack(fill=tk.X, pady=5, padx=5)

            # Variable Type
            ttk.Label(row_labelframe, text="Tipo:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=2)
            type_var = tk.StringVar(value="Cuantitativa")
            self.row_configs[var_name]['type_var'] = type_var
            
            rb_cuant = ttk.Radiobutton(row_labelframe, text="Cuantitativa", variable=type_var, value="Cuantitativa", command=lambda v=var_name: self._toggle_controls(v))
            rb_cuant.grid(row=0, column=1, sticky=tk.W, padx=2)
            
            rb_cual = ttk.Radiobutton(row_labelframe, text="Cualitativa", variable=type_var, value="Cualitativa", command=lambda v=var_name: self._toggle_controls(v))
            rb_cual.grid(row=0, column=2, sticky=tk.W, padx=2)

            # Reference Category
            ttk.Label(row_labelframe, text="Ref. Cat.:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=2)
            ref_combo = ttk.Combobox(row_labelframe, state="disabled", width=15)
            ref_combo.grid(row=1, column=1, columnspan=2, sticky=tk.EW, padx=5)
            self.row_configs[var_name]['ref_combo'] = ref_combo

            # Spline
            ttk.Label(row_labelframe, text="Spline:").grid(row=2, column=0, sticky=tk.W, padx=5, pady=2)
            spline_var = tk.BooleanVar(value=False)
            self.row_configs[var_name]['spline_var'] = spline_var
            cb_spline = ttk.Checkbutton(row_labelframe, text="Usar", variable=spline_var, command=lambda v=var_name: self._toggle_controls(v))
            cb_spline.grid(row=2, column=1, sticky=tk.W, padx=5)
            
            ttk.Label(row_labelframe, text="Spline DF:").grid(row=3, column=0, sticky=tk.W, padx=15, pady=2)
            spline_df_var = tk.IntVar(value=4)
            self.row_configs[var_name]['spline_df_var'] = spline_df_var
            spline_df_spinbox = ttk.Spinbox(row_labelframe, from_=2, to=10, textvariable=spline_df_var, width=5, state="disabled")
            spline_df_spinbox.grid(row=3, column=1, sticky=tk.W, padx=5)
            self.row_configs[var_name]['spline_df_spinbox'] = spline_df_spinbox

            # Load existing config
            if var_name in self.app_instance.variable_configs:
                config = self.app_instance.variable_configs[var_name]
                type_var.set(config.get('type', 'Cuantitativa'))
                if type_var.get() == 'Cualitativa':
                    if self.app_instance.data is not None:
                        unique_vals = sorted(self.app_instance.data[var_name].astype(str).unique().tolist())
                        ref_combo['values'] = unique_vals
                        ref_combo.set(config.get('ref_cat', unique_vals[0] if unique_vals else ''))
                if config.get('spline', False):
                    spline_var.set(True)
                    spline_df_var.set(config.get('spline_df', 4))
            
            self._toggle_controls(var_name)

        buttons_frame = ttk.Frame(main_frame)
        buttons_frame.pack(fill=tk.X, pady=(10,0))
        ttk.Button(buttons_frame, text="OK/Aplicar", command=self.apply_configurations).pack(side=tk.RIGHT, padx=5)
        ttk.Button(buttons_frame, text="Cancelar", command=self.destroy).pack(side=tk.RIGHT)

    def _toggle_controls(self, var_name):
        config = self.row_configs[var_name]
        var_is_quantitative = config['type_var'].get() == "Cuantitativa"
        
        config['ref_combo'].config(state="readonly" if not var_is_quantitative else "disabled")
        if var_is_quantitative:
            config['ref_combo'].set("")
        else:
            if self.app_instance.data is not None:
                unique_vals = sorted(self.app_instance.data[var_name].astype(str).unique().tolist())
                config['ref_combo']['values'] = unique_vals
                if self.app_instance.variable_configs.get(var_name, {}).get('ref_cat') in unique_vals:
                    config['ref_combo'].set(self.app_instance.variable_configs[var_name]['ref_cat'])
                elif unique_vals:
                    config['ref_combo'].set(unique_vals[0])


        config['spline_df_spinbox'].config(state=tk.NORMAL if var_is_quantitative and config['spline_var'].get() else tk.DISABLED)
        if not var_is_quantitative:
            config['spline_var'].set(False)

    def apply_configurations(self):
        for var_name, config_widgets in self.row_configs.items():
            var_type = config_widgets['type_var'].get()
            self.app_instance.variable_configs[var_name] = {'type': var_type}
            
            if var_type == 'Cualitativa':
                self.app_instance.variable_configs[var_name]['ref_cat'] = config_widgets['ref_combo'].get()
            
            if var_type == 'Cuantitativa' and config_widgets['spline_var'].get():
                self.app_instance.variable_configs[var_name]['spline'] = True
                self.app_instance.variable_configs[var_name]['spline_df'] = config_widgets['spline_df_var'].get()
            else:
                self.app_instance.variable_configs[var_name]['spline'] = False

        self.destroy()